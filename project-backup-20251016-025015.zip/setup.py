#!/usr/bin/env python3
"""
Setup configuration for CodeInsight CLI.
"""

from setuptools import setup, find_packages
import os

# Read README for long description
def read_readme():
    """Read README.md for long description."""
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as f:
            return f.read()
    return "CodeInsight - Local RAG-powered CLI developer assistant"

# Read requirements
def read_requirements():
    """Read requirements.txt for dependencies."""
    requirements_path = os.path.join(os.path.dirname(__file__), "requirements.txt")
    with open(requirements_path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="codeinsight",
    version="1.0.0",
    description="Local RAG-powered CLI developer assistant",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="CodeInsight Team",
    author_email="contact@codeinsight.dev",
    url="https://github.com/pavanlost56/CodeInsight-CLI",
    license="MIT",
    
    # Package configuration
    packages=find_packages(),
    include_package_data=True,
    
    # Python version requirement
    python_requires=">=3.11",
    
    # Dependencies
    install_requires=read_requirements(),
    
    # Entry point for global CLI command
    entry_points={
        "console_scripts": [
            "codeinsight=codeinsight.__main__:main",
        ],
    },
    
    # Classification
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Tools",
        "Topic :: Documentation",
        "Topic :: Utilities",
    ],
    
    # Keywords for PyPI search
    keywords="cli developer assistant documentation rag langchain ollama ai",
    
    # Project URLs
    project_urls={
        "Bug Reports": "https://github.com/pavanlost56/CodeInsight-CLI/issues",
        "Source": "https://github.com/pavanlost56/CodeInsight-CLI",
        "Documentation": "https://github.com/pavanlost56/CodeInsight-CLI#readme",
    },
)