<#
.SYNOPSIS
    Quick Restore Script for CodeInsight Project
    
.DESCRIPTION
    Automatically restores project dependencies and sets up the environment
    after extracting the backup ZIP file.
    
.NOTES
    Usage: .\restore-project.ps1
    Run this script AFTER extracting the backup ZIP to the project directory
#>

$ErrorActionPreference = "Stop"

# Color functions
function Write-Success { param($Message) Write-Host "✅ $Message" -ForegroundColor Green }
function Write-Info { param($Message) Write-Host "ℹ️  $Message" -ForegroundColor Cyan }
function Write-Warning { param($Message) Write-Host "⚠️  $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "❌ $Message" -ForegroundColor Red }

Write-Host "`n╔══════════════════════════════════════════════╗" -ForegroundColor Magenta
Write-Host "║  CodeInsight Project Restore Utility         ║" -ForegroundColor Magenta
Write-Host "╚══════════════════════════════════════════════╝`n" -ForegroundColor Magenta

$ProjectRoot = $PSScriptRoot

# Check if this is a backup extraction
if (Test-Path "$ProjectRoot\README-RESTORE.txt") {
    Write-Info "Detected backup extraction - starting restore process..."
} else {
    Write-Warning "This doesn't appear to be a backup extraction"
    $Continue = Read-Host "Continue anyway? (y/N)"
    if ($Continue -ne 'y') { exit 0 }
}

# ==============================================
# STEP 1: Check Prerequisites
# ==============================================
Write-Info "`n[STEP 1] Checking prerequisites..."

$Prerequisites = @{
    "Python" = "python"
    "Git" = "git"
    "Pip" = "pip"
}

$MissingTools = @()
foreach ($Tool in $Prerequisites.GetEnumerator()) {
    $Cmd = Get-Command $Tool.Value -ErrorAction SilentlyContinue
    if ($Cmd) {
        Write-Host "  ✓ $($Tool.Key) found" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $($Tool.Key) NOT FOUND" -ForegroundColor Red
        $MissingTools += $Tool.Key
    }
}

if ($MissingTools.Count -gt 0) {
    Write-Error "Missing required tools: $($MissingTools -join ', ')"
    Write-Info "Please install missing tools and run this script again"
    Write-Info "See global-tools.txt for the complete list"
    exit 1
}

Write-Success "All prerequisites met"

# ==============================================
# STEP 2: Create Virtual Environment
# ==============================================
Write-Info "`n[STEP 2] Setting up Python virtual environment..."

if (Test-Path "$ProjectRoot\venv") {
    Write-Warning "Virtual environment already exists"
    $Recreate = Read-Host "Recreate it? (y/N)"
    if ($Recreate -eq 'y') {
        Remove-Item "$ProjectRoot\venv" -Recurse -Force
    }
}

if (-not (Test-Path "$ProjectRoot\venv")) {
    try {
        python -m venv venv
        Write-Success "Created virtual environment"
    } catch {
        Write-Error "Failed to create virtual environment: $_"
        exit 1
    }
}

# ==============================================
# STEP 3: Install Python Dependencies
# ==============================================
Write-Info "`n[STEP 3] Installing Python dependencies..."

# Activate virtual environment
$ActivateScript = "$ProjectRoot\venv\Scripts\Activate.ps1"
if (Test-Path $ActivateScript) {
    & $ActivateScript
    Write-Success "Activated virtual environment"
}

# Upgrade pip
try {
    python -m pip install --upgrade pip setuptools wheel
    Write-Success "Upgraded pip, setuptools, and wheel"
} catch {
    Write-Warning "Could not upgrade pip: $_"
}

# Install requirements
if (Test-Path "$ProjectRoot\requirements.txt") {
    try {
        pip install -r requirements.txt
        Write-Success "Installed requirements.txt"
    } catch {
        Write-Error "Failed to install requirements.txt: $_"
        exit 1
    }
} else {
    Write-Warning "requirements.txt not found"
}

# Install dev requirements
if (Test-Path "$ProjectRoot\dev-requirements.txt") {
    try {
        pip install -r dev-requirements.txt
        Write-Success "Installed dev-requirements.txt"
    } catch {
        Write-Warning "Could not install dev-requirements.txt: $_"
    }
}

# ==============================================
# STEP 4: Check Ollama Installation
# ==============================================
Write-Info "`n[STEP 4] Checking Ollama installation..."

$OllamaCmd = Get-Command ollama -ErrorAction SilentlyContinue
if ($OllamaCmd) {
    Write-Success "Ollama is installed"
    
    # Check if Ollama server is running
    try {
        $Response = Invoke-WebRequest -Uri "http://localhost:11434/api/version" -Method Get -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($Response.StatusCode -eq 200) {
            Write-Success "Ollama server is running"
        }
    } catch {
        Write-Warning "Ollama server is not running"
        Write-Info "Start it with: ollama serve"
    }
    
    # Check for default model
    $Models = ollama list 2>&1 | Out-String
    if ($Models -match "mistral:7b-instruct") {
        Write-Success "Default model (mistral:7b-instruct) is installed"
    } else {
        Write-Warning "Default model not found"
        Write-Info "Install it with: ollama pull mistral:7b-instruct"
    }
} else {
    Write-Warning "Ollama is not installed"
    Write-Info "Download from: https://ollama.ai/download"
}

# ==============================================
# STEP 5: Verify Installation
# ==============================================
Write-Info "`n[STEP 5] Verifying installation..."

try {
    python cli.py --help | Out-Null
    Write-Success "CLI is functional"
} catch {
    Write-Error "CLI verification failed: $_"
}

# ==============================================
# Final Summary
# ==============================================
Write-Host "`n╔══════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║      RESTORE COMPLETED SUCCESSFULLY          ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════╝`n" -ForegroundColor Green

Write-Host "✨ Your CodeInsight project is ready!" -ForegroundColor Cyan
Write-Host ""
Write-Host "🚀 Quick Start Commands:" -ForegroundColor Cyan
Write-Host "  1. Activate venv:    .\venv\Scripts\Activate.ps1"
Write-Host "  2. Start Ollama:     ollama serve"
Write-Host "  3. Test CLI:         python cli.py model status"
Write-Host "  4. Run a query:      python cli.py query 'What is React?' --framework react"
Write-Host "  5. Interactive chat: python cli.py chat"
Write-Host ""

Write-Host "📚 Additional Resources:" -ForegroundColor Cyan
Write-Host "  • README.md            - Full project documentation"
Write-Host "  • README-RESTORE.txt   - Detailed restore instructions"
Write-Host "  • global-tools.txt     - List of original dev tools"
Write-Host ""

Write-Success "Happy coding! 🎉`n"
