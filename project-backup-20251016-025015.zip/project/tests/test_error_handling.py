"""
Tests for the error handling system.
"""

import pytest
from unittest.mock import patch, Mock
import requests
from pathlib import Path
import tempfile
import os

from core.error_handling import (
    ErrorHandler, ErrorContext, ErrorCategory, ErrorSeverity,
    safe_operation, CodeInsightError
)


class TestErrorContext:
    """Test ErrorContext dataclass."""
    
    def test_error_context_creation(self):
        """Test error context creation."""
        context = ErrorContext(
            operation="test_operation",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.HIGH,
            user_message="Test error",
            technical_details="Technical details",
            suggestions=["Suggestion 1"],
            recovery_actions=["Action 1"],
            metadata={"key": "value"}
        )
        
        assert context.operation == "test_operation"
        assert context.category == ErrorCategory.NETWORK
        assert context.severity == ErrorSeverity.HIGH
        assert context.user_message == "Test error"
        assert context.technical_details == "Technical details"
        assert context.suggestions == ["Suggestion 1"]
        assert context.recovery_actions == ["Action 1"]
        assert context.metadata == {"key": "value"}


class TestCodeInsightError:
    """Test CodeInsightError exception."""
    
    def test_codeinsight_error_creation(self):
        """Test CodeInsight error creation."""
        context = ErrorContext(
            operation="test",
            category=ErrorCategory.INTERNAL,
            severity=ErrorSeverity.HIGH,
            user_message="Test error",
            technical_details="Technical details",
            suggestions=[],
            recovery_actions=[]
        )
        
        error = CodeInsightError(context)
        assert error.context == context
        assert str(error) == "Test error"
    
    def test_codeinsight_error_with_original(self):
        """Test CodeInsight error with original exception."""
        original = ValueError("Original error")
        context = ErrorContext(
            operation="test",
            category=ErrorCategory.INTERNAL,
            severity=ErrorSeverity.HIGH,
            user_message="Test error",
            technical_details="Technical details",
            suggestions=[],
            recovery_actions=[]
        )
        
        error = CodeInsightError(context, original)
        assert error.context == context
        assert error.original_error == original


class TestErrorHandler:
    """Test ErrorHandler class."""
    
    def setup_method(self):
        """Set up test instance."""
        self.handler = ErrorHandler()
    
    def test_error_handler_initialization(self):
        """Test error handler initialization."""
        assert self.handler.logger is not None
        assert isinstance(self.handler.error_counts, dict)
        assert isinstance(self.handler.recovery_strategies, dict)
    
    def test_handle_error_basic(self):
        """Test basic error handling."""
        error = ValueError("Test error")
        context = ErrorContext(
            operation="test_operation",
            category=ErrorCategory.INTERNAL,
            severity=ErrorSeverity.MEDIUM,
            user_message="Test error occurred",
            technical_details="ValueError in test",
            suggestions=["Try again"],
            recovery_actions=["Restart"]
        )
        
        result = self.handler.handle_error(error, context)
        
        assert isinstance(result, dict)
        assert "error_occurred" in result or "success" in result or "message" in result
    
    def test_track_error(self):
        """Test error tracking."""
        context = ErrorContext(
            operation="test_op",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.LOW,
            user_message="Test",
            technical_details="Test",
            suggestions=[],
            recovery_actions=[]
        )
        
        # Track multiple errors
        self.handler._track_error(context)
        self.handler._track_error(context)
        
        key = f"{context.category.value}:{context.operation}"
        assert self.handler.error_counts[key] == 2
    
    def test_network_error_recovery_timeout(self):
        """Test network error recovery for timeout."""
        error = requests.exceptions.Timeout("Request timed out")
        context = ErrorContext(
            operation="api_call",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.MEDIUM,
            user_message="Request timeout",
            technical_details="Timeout error",
            suggestions=[],
            recovery_actions=[]
        )
        
        result = self.handler._recover_network_error(error, context)
        
        assert result["success"] is False
        assert "timeout" in result["message"].lower()
    
    def test_network_error_recovery_connection(self):
        """Test network error recovery for connection error."""
        error = requests.exceptions.ConnectionError("Connection failed")
        context = ErrorContext(
            operation="web_request",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.MEDIUM,
            user_message="Connection failed",
            technical_details="Connection error",
            suggestions=[],
            recovery_actions=[]
        )
        
        result = self.handler._recover_network_error(error, context)
        
        assert result["success"] is False
        assert "connection" in result["message"].lower()
        assert "suggestions" in result
    
    def test_network_error_recovery_localhost(self):
        """Test network error recovery for localhost (Ollama)."""
        error = requests.exceptions.ConnectionError("Connection to localhost failed")
        context = ErrorContext(
            operation="ollama_request",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.HIGH,
            user_message="Ollama connection failed",
            technical_details="Localhost connection error",
            suggestions=[],
            recovery_actions=[]
        )
        
        result = self.handler._recover_network_error(error, context)
        
        assert result["success"] is False
        assert "local service" in result["message"].lower()
        assert any("ollama" in suggestion.lower() for suggestion in result["suggestions"])
    
    def test_filesystem_error_recovery_permission(self):
        """Test filesystem error recovery for permission error."""
        error = PermissionError("Permission denied")
        context = ErrorContext(
            operation="file_write",
            category=ErrorCategory.FILE_SYSTEM,
            severity=ErrorSeverity.HIGH,
            user_message="Permission denied",
            technical_details="Permission error",
            suggestions=[],
            recovery_actions=[]
        )
        
        result = self.handler._recover_filesystem_error(error, context)
        
        assert result["success"] is False
        assert "permission" in result["message"].lower()
        assert "suggestions" in result
    
    def test_filesystem_error_recovery_file_not_found(self):
        """Test filesystem error recovery for file not found."""
        error = FileNotFoundError("File not found")
        context = ErrorContext(
            operation="file_read",
            category=ErrorCategory.FILE_SYSTEM,
            severity=ErrorSeverity.MEDIUM,
            user_message="File not found",
            technical_details="File not found error",
            suggestions=[],
            recovery_actions=[],
            metadata={"file_path": "/test/path/file.txt"}
        )
        
        with patch('pathlib.Path.mkdir') as mock_mkdir:
            result = self.handler._recover_filesystem_error(error, context)
            
            # Should attempt to create directories
            mock_mkdir.assert_called_once()
    
    def test_attempt_recovery_no_strategy(self):
        """Test recovery attempt when no strategy exists."""
        error = ValueError("Test error")
        context = ErrorContext(
            operation="test",
            category=ErrorCategory.USER_INPUT,  # No recovery strategy for this
            severity=ErrorSeverity.LOW,
            user_message="Test",
            technical_details="Test",
            suggestions=[],
            recovery_actions=[]
        )
        
        result = self.handler._attempt_recovery(error, context)
        assert result["success"] is False
        assert "no recovery strategy" in result["message"].lower()


class TestSafeOperationDecorator:
    """Test safe_operation decorator."""
    
    def test_safe_operation_success(self):
        """Test successful operation."""
        @safe_operation(category=ErrorCategory.INTERNAL, operation="test_operation")
        def test_function(x, y):
            return x + y
        
        result = test_function(2, 3)
        assert result == 5
    
    def test_safe_operation_with_error(self):
        """Test operation with error."""
        @safe_operation(category=ErrorCategory.INTERNAL, operation="test_operation")
        def test_function():
            raise ValueError("Test error")
        
        # Should raise CodeInsightError
        with pytest.raises(CodeInsightError):
            test_function()
    
    def test_safe_operation_preserves_metadata(self):
        """Test that decorator preserves function metadata."""
        @safe_operation(category=ErrorCategory.INTERNAL, operation="test_operation")
        def test_function(x, y):
            """Test function docstring."""
            return x + y
        
        assert test_function.__name__ == "test_function"
        assert test_function.__doc__ == "Test function docstring."


if __name__ == "__main__":
    pytest.main([__file__])