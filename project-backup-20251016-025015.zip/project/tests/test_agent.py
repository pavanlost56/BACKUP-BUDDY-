"""
Tests for the CodeInsight Agent system.
Tests agent task acceptance, tool dispatch, and execution.
"""

import pytest
from unittest.mock import Mock, patch

from core.agent import CodeInsightAgent, AgentState, AgentStep
from core.tools import Tool, ToolRegistry
from core.dummy_tools import EchoTool, CalculatorTool


class TestToolRegistry:
    """Test tool registry functionality."""
    
    def test_register_and_get_tool(self):
        """Test registering and retrieving tools."""
        registry = ToolRegistry()
        echo_tool = EchoTool()
        
        registry.register(echo_tool)
        
        retrieved = registry.get_tool("echo_tool")
        assert retrieved is echo_tool
        assert registry.has_tool("echo_tool")
    
    def test_get_nonexistent_tool_raises_error(self):
        """Test getting non-existent tool raises ValueError."""
        registry = ToolRegistry()
        
        with pytest.raises(ValueError, match="Tool 'nonexistent' not found"):
            registry.get_tool("nonexistent")
    
    def test_list_tools(self):
        """Test listing all registered tools."""
        registry = ToolRegistry()
        echo_tool = EchoTool()
        calc_tool = CalculatorTool()
        
        registry.register(echo_tool)
        registry.register(calc_tool)
        
        tools = registry.list_tools()
        assert len(tools) == 2
        
        tool_names = [tool["name"] for tool in tools]
        assert "echo_tool" in tool_names
        assert "calculator_tool" in tool_names


class TestDummyTools:
    """Test dummy tools functionality."""
    
    def test_echo_tool_execution(self):
        """Test echo tool returns message with timestamp."""
        tool = EchoTool()
        
        result = tool.execute(message="Hello World")
        
        assert result["success"] is True
        assert "Hello World" in result["result"]
        assert "Echo at" in result["result"]
        assert result["metadata"]["original_message"] == "Hello World"
    
    def test_echo_tool_missing_parameter(self):
        """Test echo tool handles missing parameters."""
        tool = EchoTool()
        
        result = tool.execute()
        
        assert result["success"] is False
        assert "Missing required parameter" in result["error"]
    
    def test_calculator_tool_addition(self):
        """Test calculator tool addition."""
        tool = CalculatorTool()
        
        result = tool.execute(operation="add", a="5", b="3")
        
        assert result["success"] is True
        assert result["result"] == 8.0
        assert result["metadata"]["formula"] == "5.0 add 3.0 = 8.0"
    
    def test_calculator_tool_division_by_zero(self):
        """Test calculator tool handles division by zero."""
        tool = CalculatorTool()
        
        result = tool.execute(operation="divide", a="10", b="0")
        
        assert result["success"] is False
        assert "Division by zero" in result["error"]
    
    def test_calculator_tool_invalid_operation(self):
        """Test calculator tool handles invalid operations."""
        tool = CalculatorTool()
        
        result = tool.execute(operation="invalid", a="5", b="3")
        
        assert result["success"] is False
        assert "Unknown operation" in result["error"]


class TestCodeInsightAgent:
    """Test CodeInsight Agent functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.registry = ToolRegistry()
        self.echo_tool = EchoTool()
        self.calc_tool = CalculatorTool()
        
        self.registry.register(self.echo_tool)
        self.registry.register(self.calc_tool)
        
        self.agent = CodeInsightAgent(self.registry)
    
    def test_agent_initialization(self):
        """Test agent initializes in correct state."""
        assert self.agent.state == AgentState.IDLE
        assert self.agent.current_task == ""
        assert self.agent.execution_plan == []
    
    def test_accept_task(self):
        """Test agent accepts tasks and changes state."""
        task = "Test task for agent"
        
        response = self.agent.accept_task(task)
        
        assert self.agent.state == AgentState.PLANNING
        assert self.agent.current_task == task
        assert "Task accepted" in response
        assert task in response
    
    def test_execute_step_with_echo_tool(self):
        """Test executing a step with echo tool."""
        step = AgentStep(
            step_id=1,
            tool_name="echo_tool",
            parameters={"message": "Test message"},
            description="Echo test message"
        )
        
        result = self.agent._execute_step(step)
        
        assert result["success"] is True
        assert "Test message" in result["result"]
        assert step.executed is True
        assert step.result is not None
    
    def test_execute_step_with_nonexistent_tool(self):
        """Test executing step with non-existent tool."""
        step = AgentStep(
            step_id=1,
            tool_name="nonexistent_tool",
            parameters={},
            description="Test non-existent tool"
        )
        
        result = self.agent._execute_step(step)
        
        assert result["success"] is False
        assert "not found" in result["error"]
        assert step.error is not None
    
    def test_get_status(self):
        """Test getting agent status."""
        self.agent.accept_task("Test task")
        
        status = self.agent.get_status()
        
        assert status["state"] == "planning"
        assert status["current_task"] == "Test task"
        assert "task" in status["context_keys"]
    
    @patch('core.agent.call_ollama_generate')
    def test_plan_execution_with_mock_llm(self, mock_llm):
        """Test plan execution with mocked LLM response and fallback."""
        # Test fallback when LLM fails
        mock_llm.side_effect = Exception("Connection error")
        
        self.agent.accept_task("echo test message")
        steps = self.agent.plan_execution()
        
        # Should get fallback plan with at least one step
        assert len(steps) >= 1
        assert steps[0].tool_name == "echo_tool"
        assert "test message" in steps[0].parameters["message"]
    
    def test_format_tools_for_prompt(self):
        """Test formatting tools for LLM prompt."""
        tools_text = self.agent._format_tools_for_prompt()
        
        assert "echo_tool" in tools_text
        assert "calculator_tool" in tools_text
        assert "Echoes back" in tools_text
        assert "arithmetic operations" in tools_text
    
    def test_build_planning_prompt(self):
        """Test building planning prompt for LLM."""
        task = "Complete a test task"
        tools_info = "test tools info"
        
        prompt = self.agent._build_planning_prompt(task, tools_info)
        
        assert "CodeInsight Agent" in prompt
        assert task in prompt
        assert tools_info in prompt
        assert "AVAILABLE TOOLS:" in prompt
        assert "RESPONSE FORMAT:" in prompt
    
    def test_fallback_planning_echo_task(self):
        """Test fallback planning for echo tasks."""
        steps = self.agent._create_fallback_plan("echo hello world")
        
        assert len(steps) == 1
        assert steps[0].tool_name == "echo_tool"
        assert "hello world" in steps[0].parameters["message"]
    
    def test_fallback_planning_calculation_task(self):
        """Test fallback planning for calculation tasks."""
        steps = self.agent._create_fallback_plan("calculate 5 + 3")
        
        assert len(steps) == 1
        assert steps[0].tool_name == "calculator_tool"
        assert steps[0].parameters["operation"] == "add"
    
    def test_fallback_planning_unknown_task(self):
        """Test fallback planning for unknown tasks defaults to RAG query."""
        steps = self.agent._create_fallback_plan("unknown task")

        assert len(steps) == 1
        assert steps[0].tool_name == "rag_query_tool"
        assert steps[0].parameters["query"] == "unknown task"
        assert steps[0].parameters["framework"] == "react"


class TestAgentIntegration:
    """Integration tests for agent with tools."""
    
    def test_full_agent_workflow_simple(self):
        """Test complete agent workflow with simple task."""
        registry = ToolRegistry()
        registry.register(EchoTool())
        
        agent = CodeInsightAgent(registry)
        
        # Accept task
        response = agent.accept_task("Echo hello world")
        assert "Task accepted" in response
        
        # Create simple plan manually (bypassing LLM for test)
        step = AgentStep(
            step_id=1,
            tool_name="echo_tool",
            parameters={"message": "hello world"},
            description="Echo the greeting"
        )
        agent.execution_plan = [step]
        agent.state = AgentState.PLANNING
        
        # Execute plan
        result = agent.execute_plan(confirm_steps=False)
        
        assert result["success"] is True
        assert result["steps_completed"] == 1
        assert result["total_steps"] == 1
        assert agent.state == AgentState.COMPLETED


if __name__ == "__main__":
    pytest.main([__file__, "-v"])