import json
from dataclasses import dataclass

import pytest

from core.conversation import ConversationEngine


@dataclass
class DummyLLMClient:
    responses: list
    status: dict = None

    def get_connection_status(self):
        return self.status or {"connected": True, "model_count": 1}

    def call_ollama_generate(self, prompt: str):
        if not self.responses:
            raise RuntimeError("No responses configured")
        return self.responses.pop(0)


class DummyConfig:
    def get_setting(self, key, default=None):
        return default


def test_heuristic_routing_for_question():
    engine = ConversationEngine(config_manager=DummyConfig(), llm_client=DummyLLMClient([], {"connected": False}))
    directive = engine.interpret("How do React hooks work?")
    assert directive.action == "command"
    assert directive.command[0] == "query"


def test_llm_routing_to_command():
    fake_response = json.dumps(
        {
            "action": "command",
            "command": ["agent", "refactor the caching layer"],
            "reasoning": "Task oriented request",
            "confidence": 0.82,
        }
    )
    engine = ConversationEngine(config_manager=DummyConfig(), llm_client=DummyLLMClient([fake_response]))
    directive = engine.interpret("Could you refactor the caching layer?")
    assert directive.action == "command"
    assert directive.command == ["agent", "refactor the caching layer"]
    assert directive.reasoning == "Task oriented request"


def test_llm_routing_to_response():
    fake_response = json.dumps(
        {
            "action": "respond",
            "response": "You need to pull an Ollama model first with 'ollama pull llama3.2'.",
            "reasoning": "Provide inline assistance",
            "confidence": 0.75,
        }
    )
    engine = ConversationEngine(config_manager=DummyConfig(), llm_client=DummyLLMClient([fake_response]))
    directive = engine.interpret("Why can't I run the agent?")
    assert directive.action == "respond"
    assert "ollama" in directive.response.lower()


def test_unknown_input_fallback():
    engine = ConversationEngine(config_manager=DummyConfig(), llm_client=DummyLLMClient([], {"connected": False}))
    directive = engine.interpret("asdfgh")
    assert directive.action == "respond"
    assert "not sure" in directive.response.lower()
