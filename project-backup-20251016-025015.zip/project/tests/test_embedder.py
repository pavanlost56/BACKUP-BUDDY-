"""
Test suite for embedder module.
"""

from pathlib import Path
import tempfile
import os
import json

from core.embedder import build_embeddings, chunk_text, create_embeddings


def test_chunk_text_splits_correctly():
    """Test that text chunking works with different input sizes."""
    # Short text - should return as single chunk
    short_text = "This is a short text."
    chunks = chunk_text(short_text, max_tokens=100)
    assert len(chunks) == 1
    assert chunks[0] == short_text
    
    # Long text with paragraphs
    long_text = """This is the first paragraph.
It has multiple sentences.

This is the second paragraph.
It also has multiple sentences.

This is the third paragraph.
It has even more content to test the chunking."""
    
    chunks = chunk_text(long_text, max_tokens=10)  # Very small chunks
    assert len(chunks) > 1
    assert all(chunk.strip() for chunk in chunks)  # No empty chunks


def test_create_embeddings_returns_vectorizer_and_matrix():
    """Test that embedding creation returns proper objects."""
    texts = [
        "This is the first document about Python.",
        "This is the second document about machine learning.",
        "The third document discusses data science."
    ]
    
    vectorizer, embeddings = create_embeddings(texts)
    
    # Check vectorizer
    assert hasattr(vectorizer, 'vocabulary_')
    assert hasattr(vectorizer, 'transform')
    
    # Check embeddings shape
    assert embeddings.shape[0] == len(texts)
    assert embeddings.shape[1] > 0


def test_build_embeddings_with_real_doc():
    """Test that build_embeddings processes actual documentation."""
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = Path.cwd()
        temp_path = Path(temp_dir)
        
        try:
            os.chdir(temp_path)
            
            # Create a sample documentation file
            docs_dir = temp_path / "data" / "docs"
            docs_dir.mkdir(parents=True)
            
            sample_doc = docs_dir / "test-framework.md"
            sample_content = """# Test Framework

This is a test framework for unit testing.

## Getting Started

To get started with the framework:

1. Install the package
2. Import the module  
3. Write your tests

## API Reference

The main functions available:

- add(a, b) - Adds two numbers
- subtract(a, b) - Subtracts two numbers
"""
            sample_doc.write_text(sample_content, encoding="utf-8")
            
            # Test the function
            result = build_embeddings("test-framework")
            
            # Verify metadata
            assert result["framework"] == "test-framework"
            assert result["status"] == "embeddings_created"
            assert result["vectors_count"] > 0
            assert "embedding_dim" in result
            assert "source_file" in result
            
            # Verify database files exist
            db_dir = temp_path / "data" / "db" / "test-framework"
            assert db_dir.exists()
            assert (db_dir / "chunks.json").exists()
            assert (db_dir / "vectorizer.pkl").exists()
            assert (db_dir / "embeddings.npy").exists()
            assert (db_dir / "metadata.json").exists()
            
            # Verify chunks file contains data
            with open(db_dir / "chunks.json", "r", encoding="utf-8") as f:
                chunks_data = json.load(f)
            assert len(chunks_data) > 0
            assert all("content" in chunk for chunk in chunks_data)
            assert all("id" in chunk for chunk in chunks_data)
            
        finally:
            os.chdir(original_cwd)


def test_build_embeddings_handles_missing_file():
    """Test that build_embeddings raises error for missing documentation."""
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = Path.cwd()
        temp_path = Path(temp_dir)
        
        try:
            os.chdir(temp_path)
            
            # Try to build embeddings for non-existent file
            try:
                build_embeddings("nonexistent-framework")
                assert False, "Should have raised FileNotFoundError"
            except FileNotFoundError as e:
                assert "not found" in str(e)
                
        finally:
            os.chdir(original_cwd)