"""
Test suite for retriever module.
"""

import tempfile
import os
import json
import numpy as np
import pickle
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer

from core.retriever import retrieve, load_framework_database, compute_query_similarity
from core.embedder import build_embeddings


def test_retrieve_returns_results():
    """Test that retrieve returns context chunks with metadata for existing database."""
    # Test with the httpbin database that should exist from manual testing
    result = retrieve("test query", "httpbin", top_k=3)
    
    # Should return a list (even if empty due to no database)
    assert isinstance(result, list)
    
    if result:  # If database exists
        # Each result should have required fields
        for chunk in result:
            assert "content" in chunk
            assert "source_path" in chunk
            assert "chunk_id" in chunk
            assert "similarity_score" in chunk
            assert isinstance(chunk["similarity_score"], float)


def test_retrieve_with_nonexistent_framework():
    """Test that retrieve handles non-existent framework gracefully."""
    result = retrieve("test query", "nonexistent-framework", top_k=3)
    
    # Should return empty list
    assert isinstance(result, list)
    assert len(result) == 0


def test_load_framework_database_with_real_data():
    """Test loading database with real generated data."""
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = Path.cwd()
        temp_path = Path(temp_dir)
        
        try:
            os.chdir(temp_path)
            
            # Create sample documentation
            docs_dir = temp_path / "data" / "docs"
            docs_dir.mkdir(parents=True)
            
            sample_doc = docs_dir / "test-framework.md"
            sample_content = """# Test Framework Documentation

This is a comprehensive guide to the test framework.

## Getting Started

The test framework helps you write and run tests efficiently.

## API Reference

Key functions:
- assert_equal(a, b) - Check if values are equal
- run_test(func) - Execute a test function
"""
            sample_doc.write_text(sample_content, encoding="utf-8")
            
            # Generate embeddings
            build_embeddings("test-framework")
            
            # Test loading the database
            chunks_data, vectorizer, embeddings, metadata = load_framework_database("test-framework")
            
            # Verify loaded data
            assert len(chunks_data) > 0
            assert hasattr(vectorizer, 'vocabulary_')
            assert isinstance(embeddings, np.ndarray)
            assert embeddings.shape[0] > 0
            assert metadata["framework"] == "test-framework"
            
        finally:
            os.chdir(original_cwd)


def test_compute_query_similarity():
    """Test similarity computation between query and documents."""
    # Create simple test data
    docs = ["Python programming language", "Machine learning algorithms", "Data science methods"]
    vectorizer = TfidfVectorizer()
    doc_embeddings = vectorizer.fit_transform(docs)
    
    # Test query similar to first document
    query = "Python coding"
    similarities = compute_query_similarity(query, vectorizer, doc_embeddings.toarray())
    
    # Should return similarity scores
    assert len(similarities) == len(docs)
    assert all(isinstance(score, (float, np.floating)) for score in similarities)
    assert all(0 <= score <= 1 for score in similarities)
    
    # First document should have highest similarity for Python query
    assert similarities[0] >= similarities[1]


def test_retrieve_with_real_similarity():
    """Test retrieve function with actual similarity search."""
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = Path.cwd()
        temp_path = Path(temp_dir)
        
        try:
            os.chdir(temp_path)
            
            # Create documentation with multiple distinct sections
            docs_dir = temp_path / "data" / "docs"
            docs_dir.mkdir(parents=True)
            
            sample_doc = docs_dir / "test-lib.md"
            sample_content = """# Test Library

## Authentication
Learn how to authenticate users with tokens and passwords.

## Database Operations  
Instructions for connecting to databases and running queries.

## File Processing
Methods for reading, writing, and processing various file formats.
"""
            sample_doc.write_text(sample_content, encoding="utf-8")
            
            # Generate embeddings
            build_embeddings("test-lib")
            
            # Test queries with different topics
            auth_results = retrieve("authentication login", "test-lib", top_k=2)
            db_results = retrieve("database query", "test-lib", top_k=2)
            
            # Should return results
            assert len(auth_results) > 0
            assert len(db_results) > 0
            
            # Results should have similarity scores
            for result in auth_results:
                assert "similarity_score" in result
                assert isinstance(result["similarity_score"], float)
            
        finally:
            os.chdir(original_cwd)