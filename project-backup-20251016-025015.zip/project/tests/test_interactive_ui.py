"""
Tests for interactive UI components.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from io import StringIO
from rich.console import Console

from core.interactive_ui import InteractiveUI, ProgressTracker, StreamingResponse, create_interactive_ui


class TestInteractiveUI:
    """Test InteractiveUI functionality."""
    
    def setup_method(self):
        self.console = Console(file=StringIO(), width=80)
        self.ui = InteractiveUI(self.console)
    
    def test_initialization(self):
        assert self.ui.console == self.console
        assert self.ui.current_operations == {}
        assert self.ui._live_display is None
    
    def test_show_welcome_banner(self):
        # Should not raise any exceptions
        self.ui.show_welcome_banner()
        output = self.console.file.getvalue()
        assert "CodeInsight CLI" in output
        assert "Local RAG" in output
        assert "Web Search" in output
    
    def test_show_agent_planning_approve(self):
        steps = [
            {
                "tool_name": "test_tool",
                "action": "execute",
                "parameters": {"param1": "value1"}
            }
        ]
        
        with patch('rich.prompt.Confirm.ask', return_value=True):
            result = self.ui.show_agent_planning("test task", steps)
            assert result is True
    
    def test_show_agent_planning_reject(self):
        steps = [
            {
                "tool_name": "test_tool", 
                "action": "execute",
                "parameters": {"param1": "value1"}
            }
        ]
        
        with patch('rich.prompt.Confirm.ask', return_value=False):
            result = self.ui.show_agent_planning("test task", steps)
            assert result is False
    
    def test_create_progress_tracker(self):
        tracker = self.ui.create_progress_tracker(5, "Test task")
        assert isinstance(tracker, ProgressTracker)
        assert tracker.total_steps == 5
        assert tracker.description == "Test task"
    
    def test_show_tool_selection_prompt_auto(self):
        tools = ["tool1", "tool2", "tool3"]
        
        with patch('rich.prompt.Prompt.ask', return_value="auto"):
            result = self.ui.show_tool_selection_prompt(tools, "test query")
            assert result is None
    
    def test_show_tool_selection_prompt_specific(self):
        tools = ["tool1", "tool2", "tool3"]
        
        with patch('rich.prompt.Prompt.ask', return_value="2"):
            result = self.ui.show_tool_selection_prompt(tools, "test query")
            assert result == "tool2"
    
    def test_show_error_with_suggestions(self):
        suggestions = ["Try again", "Check connection"]
        self.ui.show_error_with_suggestions("Test error", suggestions)
        
        output = self.console.file.getvalue()
        assert "Test error" in output
        assert "Try again" in output
        assert "Check connection" in output
    
    def test_show_success_with_metadata(self):
        metadata = {"key1": "value1", "key2": "value2"}
        self.ui.show_success_with_metadata("Test success", metadata)
        
        output = self.console.file.getvalue()
        assert "Test success" in output
        assert "Key1" in output  # Formatted
        assert "value1" in output


class TestProgressTracker:
    """Test ProgressTracker functionality."""
    
    def setup_method(self):
        self.console = Console(file=StringIO(), width=80)
    
    def test_initialization(self):
        tracker = ProgressTracker(self.console, 5, "Test task")
        assert tracker.total_steps == 5
        assert tracker.description == "Test task"
        assert tracker.current_step == 0
        assert tracker.step_details == []
    
    def test_context_manager(self):
        with ProgressTracker(self.console, 3, "Test") as tracker:
            assert tracker.progress is not None
            assert tracker.task_id is not None
            tracker.update_step("Step 1")
            assert tracker.current_step == 1
            assert len(tracker.step_details) == 1
            assert tracker.step_details[0]["name"] == "Step 1"
    
    def test_update_step_with_details(self):
        with ProgressTracker(self.console, 2, "Test") as tracker:
            tracker.update_step("Step 1", "Additional details")
            assert tracker.current_step == 1
            assert tracker.step_details[0]["details"] == "Additional details"
    
    def test_complete(self):
        with ProgressTracker(self.console, 2, "Test") as tracker:
            tracker.complete("All done")
            # Should not raise any exceptions


class TestStreamingResponse:
    """Test StreamingResponse functionality."""
    
    def setup_method(self):
        self.console = Console(file=StringIO(), width=80)
        self.streamer = StreamingResponse(self.console)
    
    def test_initialization(self):
        assert self.streamer.console == self.console
        assert self.streamer.current_content == ""
        assert self.streamer.live_display is None
    
    def test_update_content(self):
        self.streamer.current_content = "initial"
        self.streamer.update_content("updated")
        assert self.streamer.current_content == "updated"
    
    @patch('rich.live.Live')
    def test_start_streaming(self, mock_live):
        mock_instance = MagicMock()
        mock_live.return_value = mock_instance
        
        self.streamer.start_streaming("Test Title")
        assert self.streamer.live_display == mock_instance
        mock_instance.start.assert_called_once()
    
    @patch('rich.live.Live')
    def test_finish_streaming(self, mock_live):
        mock_instance = MagicMock()
        mock_live.return_value = mock_instance
        self.streamer.live_display = mock_instance
        
        self.streamer.finish_streaming()
        mock_instance.stop.assert_called_once()


class TestInteractiveUIFactories:
    """Test factory functions."""
    
    def test_create_interactive_ui(self):
        console = Console()
        ui = create_interactive_ui(console)
        assert isinstance(ui, InteractiveUI)
        assert ui.console == console


class TestInteractiveUIIntegration:
    """Integration tests for interactive UI components."""
    
    def setup_method(self):
        self.console = Console(file=StringIO(), width=80)
        self.ui = InteractiveUI(self.console)
    
    def test_error_then_success_workflow(self):
        # Simulate error -> success workflow
        self.ui.show_error_with_suggestions("Initial error", ["Try again"])
        self.ui.show_success_with_metadata("Fixed!", {"attempts": 2})
        
        output = self.console.file.getvalue()
        assert "Initial error" in output
        assert "Fixed!" in output
        assert "Attempts" in output
    
    def test_planning_and_execution_workflow(self):
        # Simulate full planning -> execution workflow
        steps = [
            {"tool_name": "test_tool", "action": "execute", "parameters": {"test": "value"}}
        ]
        
        with patch('rich.prompt.Confirm.ask', return_value=True):
            approved = self.ui.show_agent_planning("test task", steps)
            assert approved is True
        
        # Then show success
        self.ui.show_success_with_metadata("Task completed", {"steps": 1})
        
        output = self.console.file.getvalue()
        assert "test task" in output
        assert "test_tool" in output
        assert "Task completed" in output
    
    def test_tool_selection_workflow(self):
        tools = ["rag_query_tool", "web_search_tool", "github_tool"]
        
        with patch('rich.prompt.Prompt.ask', return_value="2"):
            selected = self.ui.show_tool_selection_prompt(tools, "test query")
            assert selected == "web_search_tool"
        
        output = self.console.file.getvalue()
        assert "test query" in output
        assert "rag_query_tool" in output
        assert "web_search_tool" in output
        assert "github_tool" in output


class TestProgressTrackerEdgeCases:
    """Test edge cases for ProgressTracker."""
    
    def test_zero_steps(self):
        console = Console(file=StringIO())
        with ProgressTracker(console, 0, "Empty task") as tracker:
            tracker.complete()
            assert tracker.current_step == 0
    
    def test_multiple_updates(self):
        console = Console(file=StringIO())
        with ProgressTracker(console, 5, "Multi-step") as tracker:
            for i in range(3):
                tracker.update_step(f"Step {i+1}")
            assert tracker.current_step == 3
            assert len(tracker.step_details) == 3
    
    def test_update_beyond_total(self):
        console = Console(file=StringIO())
        with ProgressTracker(console, 2, "Overflow test") as tracker:
            tracker.update_step("Step 1")
            tracker.update_step("Step 2")
            tracker.update_step("Step 3")  # Beyond total
            assert tracker.current_step == 3  # Should still work