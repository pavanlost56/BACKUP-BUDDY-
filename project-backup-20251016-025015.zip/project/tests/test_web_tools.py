"""
Tests for web tools integration with the agent system.
"""

import pytest
from unittest.mock import patch, MagicMock, Mock
import requests
import json

from core.web_tools import WebSearchTool, URLFetchTool, GitHubTool


class TestWebSearchTool:
    """Test web search tool functionality."""
    
    def setup_method(self):
        self.tool = WebSearchTool()
    
    def test_tool_name(self):
        assert self.tool.name == "web_search_tool"
    
    def test_tool_description(self):
        assert "search the web" in self.tool.description.lower()
        assert "current information" in self.tool.description.lower()
    
    def test_parameters(self):
        params = self.tool.parameters
        assert "query" in params
        assert "max_results" in params
        assert "search_engine" in params
    
    def test_execute_missing_query(self):
        result = self.tool.execute()
        assert result["success"] is False
        assert "missing required parameter: query" in result["error"].lower()
    
    def test_execute_with_mock_results(self):
        # This will use mock results since real DuckDuckGo likely fails in test
        result = self.tool.execute(query="React hooks", max_results="3")
        
        assert result["success"] is True
        assert "result" in result
        assert "React hooks" in result["result"]
        assert "metadata" in result
        assert result["metadata"]["query"] == "React hooks"
    
    def test_get_mock_search_results(self):
        mock_results = self.tool._get_mock_search_results("test query", 2)
        
        assert len(mock_results) == 2
        assert all("title" in result for result in mock_results)
        assert all("url" in result for result in mock_results)
        assert all("snippet" in result for result in mock_results)
    
    @patch('requests.get')
    def test_duckduckgo_search_success(self, mock_get):
        # Mock successful DuckDuckGo response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = b'''
        <div class="result">
            <a class="result__a" href="https://example.com">Test Result</a>
            <a class="result__snippet">Test snippet description</a>
        </div>
        '''
        mock_get.return_value = mock_response
        
        results = self.tool._search_duckduckgo("test query", 5)
        
        # Should return mock results if parsing fails
        assert isinstance(results, list)
    
    @patch('requests.get')
    def test_duckduckgo_search_failure(self, mock_get):
        # Mock request failure
        mock_get.side_effect = requests.RequestException("Network error")
        
        results = self.tool._search_duckduckgo("test query", 3)
        
        # Should return mock results as fallback
        assert len(results) == 3
        assert all("title" in result for result in results)


class TestURLFetchTool:
    """Test URL fetching tool functionality."""
    
    def setup_method(self):
        self.tool = URLFetchTool()
    
    def test_tool_name(self):
        assert self.tool.name == "url_fetch_tool"
    
    def test_tool_description(self):
        assert "fetch content" in self.tool.description.lower()
        assert "url" in self.tool.description.lower()
    
    def test_parameters(self):
        params = self.tool.parameters
        assert "url" in params
        assert "extract_type" in params
        assert "max_length" in params
    
    def test_execute_missing_url(self):
        result = self.tool.execute()
        assert result["success"] is False
        assert "missing required parameter: url" in result["error"].lower()
    
    def test_execute_invalid_url(self):
        result = self.tool.execute(url="not-a-url")
        assert result["success"] is False
        assert "invalid url format" in result["error"].lower()
    
    @patch('requests.get')
    def test_execute_html_content(self, mock_get):
        # Mock HTML response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html"}
        mock_response.content = b'''
        <html>
            <head><title>Test Page</title></head>
            <body>
                <main>
                    <h1>Main Content</h1>
                    <p>This is the main content of the page.</p>
                </main>
                <script>console.log("remove me");</script>
            </body>
        </html>
        '''
        mock_get.return_value = mock_response
        
        result = self.tool.execute(url="https://example.com", extract_type="text")
        
        assert result["success"] is True
        assert "Main Content" in result["result"]
        assert "This is the main content" in result["result"]
        assert "console.log" not in result["result"]  # Script should be removed
    
    @patch('requests.get')
    def test_execute_json_content(self, mock_get):
        # Mock JSON response
        test_data = {"message": "Hello World", "status": "success"}
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.content = json.dumps(test_data).encode()
        mock_get.return_value = mock_response
        
        result = self.tool.execute(url="https://api.example.com/data")
        
        assert result["success"] is True
        assert "Hello World" in result["result"]
        assert "success" in result["result"]
    
    @patch('requests.get')
    def test_execute_request_failure(self, mock_get):
        mock_get.side_effect = requests.RequestException("Network error")
        
        result = self.tool.execute(url="https://example.com")
        
        assert result["success"] is False
        assert "failed to fetch url" in result["error"].lower()
    
    def test_extract_html_content_text(self):
        html_content = b'''
        <html>
            <body>
                <nav>Navigation</nav>
                <main>
                    <h1>Title</h1>
                    <p>Content paragraph.</p>
                </main>
                <script>remove me</script>
            </body>
        </html>
        '''
        
        content = self.tool._extract_html_content(html_content, "text")
        
        assert "Title" in content
        assert "Content paragraph" in content
        assert "Navigation" not in content  # nav should be removed
        assert "remove me" not in content  # script should be removed
    
    def test_extract_json_content(self):
        json_data = b'{"test": "value", "number": 42}'
        
        content = self.tool._extract_json_content(json_data)
        
        assert "test" in content
        assert "value" in content
        assert "42" in content


class TestGitHubTool:
    """Test GitHub API tool functionality."""
    
    def setup_method(self):
        self.tool = GitHubTool()
    
    def test_tool_name(self):
        assert self.tool.name == "github_tool"
    
    def test_tool_description(self):
        assert "github" in self.tool.description.lower()
        assert "repository" in self.tool.description.lower()
    
    def test_parameters(self):
        params = self.tool.parameters
        assert "action" in params
        assert "query" in params
        assert "repo" in params
        assert "language" in params
        assert "limit" in params
    
    def test_execute_missing_action(self):
        result = self.tool.execute()
        assert result["success"] is False
        assert "missing required parameter: action" in result["error"].lower()
    
    def test_execute_unsupported_action(self):
        result = self.tool.execute(action="invalid_action")
        assert result["success"] is False
        assert "unsupported action" in result["error"].lower()
    
    def test_execute_search_repos_missing_query(self):
        result = self.tool.execute(action="search_repos")
        assert result["success"] is False
        assert "missing required parameter: query" in result["error"].lower()
    
    def test_execute_get_repo_missing_repo(self):
        result = self.tool.execute(action="get_repo")
        assert result["success"] is False
        assert "missing required parameter: repo" in result["error"].lower()
    
    @patch('requests.get')
    def test_search_repositories_success(self, mock_get):
        # Mock GitHub API response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_count": 1000,
            "items": [
                {
                    "full_name": "facebook/react",
                    "description": "A declarative, efficient, and flexible JavaScript library",
                    "stargazers_count": 200000,
                    "language": "JavaScript",
                    "html_url": "https://github.com/facebook/react"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.tool.execute(action="search_repos", query="react")
        
        assert result["success"] is True
        assert "facebook/react" in result["result"]
        assert "200,000 stars" in result["result"]
        assert "JavaScript" in result["result"]
    
    @patch('requests.get')
    def test_get_repository_info_success(self, mock_get):
        # Mock GitHub API response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "full_name": "facebook/react",
            "description": "A declarative JavaScript library",
            "stargazers_count": 200000,
            "forks_count": 40000,
            "language": "JavaScript",
            "created_at": "2013-05-24T16:15:54Z",
            "updated_at": "2024-01-15T10:30:00Z",
            "html_url": "https://github.com/facebook/react",
            "topics": ["javascript", "react", "frontend"]
        }
        mock_get.return_value = mock_response
        
        result = self.tool.execute(action="get_repo", repo="facebook/react")
        
        assert result["success"] is True
        assert "facebook/react" in result["result"]
        assert "200,000" in result["result"]
        assert "40,000" in result["result"]
        assert "javascript" in result["result"].lower()
    
    @patch('requests.get')
    def test_get_trending_repositories(self, mock_get):
        # Mock GitHub search API response (used for trending)
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {
                    "full_name": "trending/repo1",
                    "description": "Trending repository 1",
                    "stargazers_count": 5000,
                    "language": "Python"
                },
                {
                    "full_name": "trending/repo2", 
                    "description": "Trending repository 2",
                    "stargazers_count": 3000,
                    "language": "Python"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.tool.execute(action="trending", language="python", limit="2")
        
        assert result["success"] is True
        assert "trending/repo1" in result["result"]
        assert "trending/repo2" in result["result"]
        assert "5,000 stars" in result["result"]
    
    @patch('requests.get')
    def test_get_repository_releases(self, mock_get):
        # Mock GitHub releases API response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {
                "name": "v1.2.0",
                "tag_name": "v1.2.0",
                "published_at": "2024-01-15T10:30:00Z",
                "body": "Bug fixes and performance improvements",
                "html_url": "https://github.com/example/repo/releases/tag/v1.2.0"
            }
        ]
        mock_get.return_value = mock_response
        
        result = self.tool.execute(action="releases", repo="example/repo")
        
        assert result["success"] is True
        assert "v1.2.0" in result["result"]
        assert "2024-01-15" in result["result"]
        assert "Bug fixes" in result["result"]
    
    @patch('requests.get')
    def test_github_api_request_failure(self, mock_get):
        mock_get.side_effect = requests.RequestException("API error")
        
        result = self.tool.execute(action="search_repos", query="test")
        
        assert result["success"] is False
        assert "github search failed" in result["error"].lower()


class TestWebToolsIntegration:
    """Test web tools integration with agent system."""
    
    def test_all_tools_implement_tool_interface(self):
        """Verify all web tools properly implement the Tool interface."""
        from core.tools import Tool
        
        tools = [WebSearchTool(), URLFetchTool(), GitHubTool()]
        
        for tool in tools:
            assert isinstance(tool, Tool)
            assert hasattr(tool, 'name')
            assert hasattr(tool, 'description')
            assert hasattr(tool, 'parameters')
            assert hasattr(tool, 'execute')
            assert callable(tool.execute)
    
    def test_tools_can_be_registered(self):
        """Test that web tools can be registered with ToolRegistry."""
        from core.tools import ToolRegistry
        
        registry = ToolRegistry()
        tools = [WebSearchTool(), URLFetchTool(), GitHubTool()]
        
        for tool in tools:
            registry.register(tool)
            retrieved_tool = registry.get_tool(tool.name)
            assert retrieved_tool is not None
            assert retrieved_tool.name == tool.name
    
    def test_agent_planning_with_web_tools(self):
        """Test that agent planning correctly chooses web tools for appropriate tasks."""
        from core.agent import CodeInsightAgent
        from core.tools import ToolRegistry
        
        # Create registry with web tools
        registry = ToolRegistry()
        registry.register(WebSearchTool())
        registry.register(GitHubTool())
        
        agent = CodeInsightAgent(registry)
        
        # Test web search planning
        web_steps = agent._create_fallback_plan("find latest React trends")
        assert len(web_steps) == 1
        assert web_steps[0].tool_name == "web_search_tool"
        
        # Test GitHub planning
        github_steps = agent._create_fallback_plan("trending javascript repositories")
        assert len(github_steps) == 1
        assert github_steps[0].tool_name == "github_tool"
        assert github_steps[0].parameters["action"] == "trending"
        assert github_steps[0].parameters["language"] == "javascript"