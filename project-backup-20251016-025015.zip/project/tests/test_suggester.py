"""
Tests for the suggester module.
"""

import pytest
from unittest.mock import patch, Mock
from rich.panel import Panel

from core.suggester import (
    validate_citation_metadata,
    extract_code_blocks,
    parse_response_sections,
    format_response_with_rich,
    suggest_follow_up_actions,
    create_fallback_response
)


class TestValidateCitationMetadata:
    """Test citation metadata validation."""
    
    def test_valid_metadata(self):
        """Test validation with complete metadata."""
        chunks = [
            {"source_path": "react.md", "chunk_id": "1", "content": "React basics"},
            {"source_path": "vue.md", "chunk_id": "2", "content": "Vue components"}
        ]
        assert validate_citation_metadata(chunks) is True
    
    def test_missing_source_path(self):
        """Test validation with missing source_path."""
        chunks = [
            {"chunk_id": "1", "content": "React basics"}
        ]
        assert validate_citation_metadata(chunks) is False
    
    def test_missing_chunk_id(self):
        """Test validation with missing chunk_id."""
        chunks = [
            {"source_path": "react.md", "content": "React basics"}
        ]
        assert validate_citation_metadata(chunks) is False
    
    def test_missing_content(self):
        """Test validation with missing content."""
        chunks = [
            {"source_path": "react.md", "chunk_id": "1"}
        ]
        assert validate_citation_metadata(chunks) is False
    
    def test_empty_chunks(self):
        """Test validation with empty chunks list."""
        assert validate_citation_metadata([]) is True


class TestExtractCodeBlocks:
    """Test code block extraction."""
    
    def test_extract_javascript_block(self):
        """Test extracting JavaScript code block."""
        response = """Here's an example:

```javascript
function hello() {
  return "Hello World";
}
```

That's the basic syntax."""
        
        blocks = extract_code_blocks(response)
        assert len(blocks) == 1
        assert blocks[0]["language"] == "javascript"
        assert "function hello()" in blocks[0]["code"]
    
    def test_extract_multiple_blocks(self):
        """Test extracting multiple code blocks."""
        response = """First example:

```python
print("Hello")
```

Second example:

```bash
npm install react
```"""
        
        blocks = extract_code_blocks(response)
        assert len(blocks) == 2
        assert blocks[0]["language"] == "python"
        assert blocks[1]["language"] == "bash"
    
    def test_extract_block_without_language(self):
        """Test extracting code block without language specification."""
        response = """Example:

```
const x = 5;
```"""
        
        blocks = extract_code_blocks(response)
        assert len(blocks) == 1
        assert blocks[0]["language"] == "text"
    
    def test_no_code_blocks(self):
        """Test response without code blocks."""
        response = "This is just plain text without any code."
        blocks = extract_code_blocks(response)
        assert len(blocks) == 0


class TestParseResponseSections:
    """Test response section parsing."""
    
    def test_parse_complete_response(self):
        """Test parsing response with all sections."""
        response = """## Summary
React is a JavaScript library.

## Steps
1. Install React
2. Create component

```javascript
function App() {
  return <div>Hello</div>;
}
```

## Sources
- react.md#1
- react.md#2"""
        
        sections = parse_response_sections(response)
        assert "React is a JavaScript library" in sections["summary"]
        assert "Install React" in sections["steps"]
        assert "react.md#1" in sections["sources"]
    
    def test_parse_partial_response(self):
        """Test parsing response with missing sections."""
        response = """## Summary
Just a summary here."""
        
        sections = parse_response_sections(response)
        assert "Just a summary" in sections["summary"]
        assert sections["steps"] == ""
        assert sections["sources"] == ""
    
    def test_alternative_section_names(self):
        """Test parsing with alternative section names."""
        response = """# Summary
Brief overview

# Code
Some code examples

# Sources
Source references"""
        
        sections = parse_response_sections(response)
        assert "Brief overview" in sections["summary"]
        assert "Some code examples" in sections["steps"]
        assert "Source references" in sections["sources"]


class TestSuggestFollowUpActions:
    """Test follow-up action suggestions."""
    
    def test_installation_suggestions(self):
        """Test suggestions for installation queries."""
        suggestions = suggest_follow_up_actions("how to install react", "react", [])
        
        assert any("installation guide" in s for s in suggestions)
        assert any("Check official react installation docs" in s for s in suggestions)
        assert len(suggestions) <= 4
    
    def test_component_suggestions(self):
        """Test suggestions for component queries."""
        suggestions = suggest_follow_up_actions("create a component", "vue", [])
        
        assert any("component example" in s for s in suggestions)
        assert any("component patterns" in s for s in suggestions)
    
    def test_error_suggestions(self):
        """Test suggestions for error queries."""
        suggestions = suggest_follow_up_actions("getting an error", "react", [])
        
        assert any("troubleshooting" in s for s in suggestions)
        assert any("browser/console" in s for s in suggestions)
    
    def test_general_suggestions(self):
        """Test general suggestions are always included."""
        suggestions = suggest_follow_up_actions("random query", "vue", [])
        
        assert any("update" in s for s in suggestions)
        assert any("Explore related topics" in s for s in suggestions)


class TestFormatResponseWithRich:
    """Test Rich panel formatting."""
    
    def test_format_complete_response(self):
        """Test formatting a complete response."""
        response = """## Summary
React is a library.

## Steps
1. Install React

```javascript
function App() {}
```

## Sources
- react.md#1"""
        
        context_chunks = [
            {"source_path": "react.md", "chunk_id": "1", "content": "React basics"}
        ]
        
        panel = format_response_with_rich(response, context_chunks, "test query", "react")
        
        assert isinstance(panel, Panel)
        assert "test query" in panel.title
        assert "react" in panel.title
    
    def test_format_response_with_fallback_sources(self):
        """Test formatting response with fallback sources."""
        response = """## Summary
Basic info without sources section."""
        
        context_chunks = [
            {"source_path": "react.md", "chunk_id": "1", "content": "React basics", "similarity_score": 0.95}
        ]
        
        panel = format_response_with_rich(response, context_chunks, "test", "react")
        
        # Should generate fallback sources
        assert isinstance(panel, Panel)


class TestCreateFallbackResponse:
    """Test fallback response creation."""
    
    def test_create_fallback_with_error(self):
        """Test fallback response with error message."""
        context_chunks = [
            {"source_path": "react.md", "chunk_id": "1", "content": "React content", "similarity_score": 0.8}
        ]
        
        panel = create_fallback_response(
            "test query", "react", context_chunks, "Connection error"
        )
        
        assert isinstance(panel, Panel)
        assert "test query" in panel.title
        assert "react" in panel.title
    
    def test_create_fallback_without_error(self):
        """Test fallback response without error message."""
        context_chunks = [
            {"source_path": "vue.md", "chunk_id": "2", "content": "Vue content"}
        ]
        
        panel = create_fallback_response("vue query", "vue", context_chunks)
        
        assert isinstance(panel, Panel)
        assert "vue query" in panel.title
    
    def test_create_fallback_with_suggestions(self):
        """Test fallback response includes suggestions."""
        context_chunks = [
            {"source_path": "react.md", "chunk_id": "1", "content": "React content"}
        ]
        
        panel = create_fallback_response("install react", "react", context_chunks)
        
        # Should include suggestions for installation queries
        assert isinstance(panel, Panel)


if __name__ == "__main__":
    pytest.main([__file__])