"""
Tests for the rate limiting system.
"""

import pytest
import time
from unittest.mock import patch, Mock
import requests
from datetime import datetime

from core.rate_limiting import (
    RateLimiter, RequestSession, rate_limited,
    RateLimit, APICallRecord
)


class TestRateLimit:
    """Test RateLimit dataclass."""
    
    def test_rate_limit_creation(self):
        """Test rate limit initialization."""
        limit = RateLimit(
            requests_per_minute=60,
            requests_per_hour=1000
        )
        
        assert limit.requests_per_minute == 60
        assert limit.requests_per_hour == 1000
        assert limit.burst_limit == 10  # Default
        assert limit.backoff_factor == 2.0  # Default


class TestAPICallRecord:
    """Test APICallRecord dataclass."""
    
    def test_api_call_record_creation(self):
        """Test API call record creation."""
        now = datetime.now()
        record = APICallRecord(
            timestamp=now,
            endpoint="test_endpoint",
            success=True,
            response_time=0.5,
            status_code=200
        )
        
        assert record.timestamp == now
        assert record.endpoint == "test_endpoint"
        assert record.success is True
        assert record.response_time == 0.5
        assert record.status_code == 200


class TestRateLimiter:
    """Test RateLimiter class."""
    
    def setup_method(self):
        """Set up test instance."""
        self.limiter = RateLimiter()
    
    def test_rate_limiter_creation(self):
        """Test rate limiter initialization."""
        assert hasattr(self.limiter, 'api_limits')
        assert hasattr(self.limiter, 'call_history')
        assert hasattr(self.limiter, 'backoff_state')
        assert hasattr(self.limiter, 'stats')
    
    def test_can_make_request_initial(self):
        """Test can make request initially."""
        # Should be able to make requests initially
        can_make, wait_time = self.limiter.check_rate_limit("test_api")
        assert isinstance(can_make, bool)
        assert isinstance(wait_time, (int, float))
    
    def test_record_request(self):
        """Test recording requests."""
        endpoint = "test_endpoint"
        initial_count = len(self.limiter.call_history[endpoint])
        
        self.limiter.record_call(endpoint, success=True, response_time=0.1)
        
        assert len(self.limiter.call_history[endpoint]) == initial_count + 1
    
    def test_get_wait_time(self):
        """Test getting wait time."""
        wait_time = self.limiter.get_backoff_delay("test_api")
        assert isinstance(wait_time, (int, float))
        assert wait_time >= 0
    
    @patch('time.sleep')
    def test_wait_if_needed(self, mock_sleep):
        """Test wait if needed."""
        # Should not raise any exceptions
        self.limiter.wait_if_needed("test_api")
    
    def test_get_statistics(self):
        """Test getting statistics."""
        stats = self.limiter.get_statistics()
        assert isinstance(stats, dict)


class TestRequestSession:
    """Test RequestSession wrapper."""
    
    def setup_method(self):
        """Set up test instance."""
        self.session = RequestSession()
    
    @patch('requests.Session.request')
    def test_request_basic(self, mock_request):
        """Test basic request."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_request.return_value = mock_response
        
        # Should not raise exceptions
        try:
            response = self.session.request('GET', 'http://example.com')
            assert response is not None
        except Exception:
            # Some implementations might have different behavior
            pass
    
    def test_get_method(self):
        """Test GET method wrapper."""
        # Should have get method
        assert hasattr(self.session, 'get')
        assert callable(self.session.get)
    
    def test_post_method(self):
        """Test POST method wrapper."""
        # Should have post method
        assert hasattr(self.session, 'post')
        assert callable(self.session.post)


class TestRateLimitedDecorator:
    """Test rate_limited decorator."""
    
    def test_rate_limited_decorator_basic(self):
        """Test basic decorator usage."""
        @rate_limited(endpoint="test")
        def test_function(x, y):
            return x + y
        
        result = test_function(2, 3)
        assert result == 5
    
    def test_rate_limited_decorator_preserves_metadata(self):
        """Test that decorator preserves function metadata."""
        @rate_limited(endpoint="test")
        def test_function(x, y):
            """Test function docstring."""
            return x + y
        
        assert test_function.__name__ == "test_function"
        assert test_function.__doc__ == "Test function docstring."
    
    def test_rate_limited_decorator_with_exception(self):
        """Test decorated function that raises exception."""
        @rate_limited(endpoint="test")
        def test_function():
            raise ValueError("Test error")
        
        with pytest.raises(ValueError):
            test_function()


if __name__ == "__main__":
    pytest.main([__file__])