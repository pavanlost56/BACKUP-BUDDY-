"""
Tests for logging system.
"""

import pytest
import tempfile
import json
import logging
import logging.handlers
import time
import threading
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

from core.logging_system import (
    LoggingManager,
    PerformanceLogger,
    LogLevel,
    LogFormat,
    StructuredFormatter,
    HumanReadableFormatter,
    CompactFormatter,
    LoggingContext,
    get_logging_manager,
    get_logger,
    get_performance_logger,
    log_context
)


class TestLoggingManager:
    """Test logging manager functionality."""
    
    def setup_method(self):
        """Setup test environment."""
        self.temp_dir = tempfile.mkdtemp()
        self.logging_manager = LoggingManager(self.temp_dir)
    
    def teardown_method(self):
        """Cleanup test environment."""
        self.logging_manager.shutdown()
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_initialization(self):
        """Test logging manager initialization."""
        assert self.logging_manager.log_dir.exists()
        assert isinstance(self.logging_manager.config, dict)
        assert "level" in self.logging_manager.config
        assert "format" in self.logging_manager.config
    
    def test_logger_creation(self):
        """Test logger creation and retrieval."""
        logger1 = self.logging_manager.get_logger("test")
        logger2 = self.logging_manager.get_logger("test")
        
        # Should return same instance
        assert logger1 is logger2
        assert logger1.name == "codeinsight.test"
        
        # Should have trace method
        assert hasattr(logger1, 'trace')
    
    def test_performance_logger_creation(self):
        """Test performance logger creation."""
        perf_logger = self.logging_manager.get_performance_logger("test")
        assert isinstance(perf_logger, PerformanceLogger)
        assert isinstance(perf_logger.logger, logging.Logger)
    
    def test_log_level_setting(self):
        """Test setting log levels."""
        # Test string level
        self.logging_manager.set_level("DEBUG")
        root_logger = logging.getLogger()
        assert root_logger.level == logging.DEBUG
        
        # Test integer level
        self.logging_manager.set_level(logging.WARNING)
        assert root_logger.level == logging.WARNING
    
    def test_context_manager_creation(self):
        """Test context manager creation."""
        context = self.logging_manager.create_context_manager("test_operation")
        assert isinstance(context, LoggingContext)
        assert context.operation == "test_operation"
    
    def test_log_file_creation(self):
        """Test that log files are created."""
        logger = self.logging_manager.get_logger("test")
        logger.info("Test message")
        
        # Flush handlers to ensure write
        self.logging_manager.flush_all()
        
        # Check if log files exist
        log_file = self.logging_manager.log_dir / "codeinsight.log"
        structured_file = self.logging_manager.log_dir / "codeinsight-structured.jsonl"
        
        # Files should exist after logging
        assert log_file.exists()
        assert structured_file.exists()
    
    def test_system_info_logging(self):
        """Test system information logging."""
        # This should not raise an exception
        self.logging_manager.log_system_info()
        
        # Check that a log entry was created
        log_file = self.logging_manager.log_dir / "codeinsight.log"
        if log_file.exists():
            content = log_file.read_text()
            assert "System information logged" in content


class TestPerformanceLogger:
    """Test performance logging functionality."""
    
    def setup_method(self):
        """Setup test environment."""
        self.logger = logging.getLogger("test_performance")
        self.perf_logger = PerformanceLogger(self.logger)
    
    def test_timer_operations(self):
        """Test timer start and end operations."""
        timer_id = self.perf_logger.start_timer("test_operation")
        assert timer_id.startswith("test_operation_")
        assert timer_id in self.perf_logger._timers
        
        # Simulate some work
        time.sleep(0.01)
        
        # End timer
        self.perf_logger.end_timer(timer_id, success=True)
        assert timer_id not in self.perf_logger._timers
    
    def test_timer_with_context(self):
        """Test timer with context data."""
        context = {"user": "test", "operation_type": "read"}
        timer_id = self.perf_logger.start_timer("test_with_context", context)
        
        timer_info = self.perf_logger._timers[timer_id]
        assert timer_info["context"] == context
        
        self.perf_logger.end_timer(timer_id)
    
    def test_timer_decorator(self):
        """Test performance timing decorator."""
        @self.perf_logger.time_operation("decorated_function")
        def test_function(x, y):
            time.sleep(0.01)
            return x + y
        
        result = test_function(1, 2)
        assert result == 3
    
    def test_timer_decorator_with_exception(self):
        """Test performance timing decorator with exception."""
        @self.perf_logger.time_operation("failing_function")
        def failing_function():
            raise ValueError("Test error")
        
        with pytest.raises(ValueError):
            failing_function()
    
    def test_timer_thread_safety(self):
        """Test timer thread safety."""
        results = []
        
        def worker():
            timer_id = self.perf_logger.start_timer("threaded_operation")
            time.sleep(0.01)
            self.perf_logger.end_timer(timer_id)
            results.append(timer_id)
        
        threads = [threading.Thread(target=worker) for _ in range(5)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        assert len(results) == 5
        assert len(set(results)) == 5  # All unique timer IDs


class TestFormatters:
    """Test log formatters."""
    
    def create_test_record(self):
        """Create a test log record."""
        record = logging.LogRecord(
            name="test.logger",
            level=logging.INFO,
            pathname="/test/path.py",
            lineno=42,
            msg="Test message with %s",
            args=("parameter",),
            exc_info=None
        )
        record.extra_data = {"key1": "value1", "key2": 123}
        record.performance_metrics = {"duration_ms": 42.5, "success": True}
        return record
    
    def test_structured_formatter(self):
        """Test structured JSON formatter."""
        formatter = StructuredFormatter()
        record = self.create_test_record()
        
        formatted = formatter.format(record)
        parsed = json.loads(formatted)
        
        assert parsed["level"] == "INFO"
        assert parsed["message"] == "Test message with parameter"
        assert parsed["extra"]["key1"] == "value1"
        assert parsed["performance_metrics"]["duration_ms"] == 42.5
        assert "timestamp" in parsed
        assert "thread_id" in parsed
    
    def test_human_readable_formatter(self):
        """Test human-readable formatter."""
        formatter = HumanReadableFormatter(use_colors=False)
        record = self.create_test_record()
        
        formatted = formatter.format(record)
        
        assert "INFO" in formatted
        assert "Test message with parameter" in formatted
        assert "key1=value1" in formatted
        assert "42.50ms" in formatted
    
    def test_compact_formatter(self):
        """Test compact formatter."""
        formatter = CompactFormatter()
        record = self.create_test_record()
        
        formatted = formatter.format(record)
        
        assert "|I|" in formatted  # Level abbreviation
        assert "Test message with parameter" in formatted
        assert "42.5ms" in formatted
    
    def test_structured_formatter_with_exception(self):
        """Test structured formatter with exception info."""
        formatter = StructuredFormatter()
        record = self.create_test_record()
        
        try:
            raise ValueError("Test exception")
        except ValueError:
            record.exc_info = sys.exc_info()
        
        formatted = formatter.format(record)
        parsed = json.loads(formatted)
        
        assert parsed["exception_info"] is not None
        assert parsed["exception_info"]["type"] == "ValueError"
        assert parsed["exception_info"]["message"] == "Test exception"
        assert "traceback" in parsed["exception_info"]


class TestLoggingContext:
    """Test logging context manager."""
    
    def setup_method(self):
        """Setup test environment."""
        self.logger = logging.getLogger("test_context")
        self.handler = logging.handlers.MemoryHandler(capacity=100)
        self.logger.addHandler(self.handler)
        self.logger.setLevel(logging.DEBUG)
    
    def test_successful_context(self):
        """Test successful operation context."""
        with LoggingContext(self.logger, "test_operation") as ctx:
            ctx.add_context(user="test_user", data_size=1024)
            time.sleep(0.01)
        
        # Check log records
        records = self.handler.buffer
        assert len(records) >= 2  # Start and completion messages
        
        # Find completion record
        completion_record = next(
            (r for r in records if "Completed test_operation" in r.getMessage()),
            None
        )
        assert completion_record is not None
        assert hasattr(completion_record, 'performance_metrics')
        assert completion_record.performance_metrics['success'] is True
    
    def test_failed_context(self):
        """Test failed operation context."""
        with pytest.raises(ValueError):
            with LoggingContext(self.logger, "failing_operation") as ctx:
                ctx.add_context(attempt=1)
                raise ValueError("Test failure")
        
        # Check log records
        records = self.handler.buffer
        error_record = next(
            (r for r in records if "Failed failing_operation" in r.getMessage()),
            None
        )
        assert error_record is not None
        assert hasattr(error_record, 'performance_metrics')
        assert error_record.performance_metrics['success'] is False


class TestGlobalFunctions:
    """Test global logging functions."""
    
    def test_get_logging_manager_singleton(self):
        """Test global logging manager singleton."""
        manager1 = get_logging_manager()
        manager2 = get_logging_manager()
        assert manager1 is manager2
    
    def test_get_logger(self):
        """Test global get_logger function."""
        logger = get_logger("global_test")
        assert isinstance(logger, logging.Logger)
        assert logger.name == "codeinsight.global_test"
    
    def test_get_performance_logger(self):
        """Test global get_performance_logger function."""
        perf_logger = get_performance_logger("global_perf")
        assert isinstance(perf_logger, PerformanceLogger)
    
    def test_log_context(self):
        """Test global log_context function."""
        context = log_context("global_operation")
        assert isinstance(context, LoggingContext)
        assert context.operation == "global_operation"


class TestLogLevels:
    """Test custom log levels."""
    
    def test_trace_level(self):
        """Test TRACE log level."""
        assert LogLevel.TRACE.value == 5
        assert logging.getLevelName(LogLevel.TRACE.value) == 'TRACE'
    
    def test_trace_logging(self):
        """Test trace logging functionality."""
        logger = get_logger("trace_test")
        
        # Should have trace method
        assert hasattr(logger, 'trace')
        
        # Set level to allow trace
        logger.setLevel(LogLevel.TRACE.value)
        
        # This should not raise an exception
        logger.trace("Trace message")


class TestLoggingConfiguration:
    """Test logging configuration handling."""
    
    def test_default_configuration(self):
        """Test default logging configuration."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = LoggingManager(temp_dir)
            
            config = manager.config
            assert config["level"] == "INFO"
            assert config["format"] in ["human", "structured", "compact"]
            assert config["console_enabled"] is True
            assert config["file_enabled"] is True
            assert "file_rotation" in config
    
    @patch('core.logging_system.get_config_manager')
    def test_configuration_loading(self, mock_config_manager):
        """Test loading configuration from config manager."""
        mock_manager = MagicMock()
        mock_manager.load_config.return_value = {
            "settings": {
                "logging": {
                    "level": "DEBUG",
                    "format": "structured",
                    "console_enabled": False
                }
            }
        }
        mock_config_manager.return_value = mock_manager
        
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = LoggingManager(temp_dir)
            
            assert manager.config["level"] == "DEBUG"
            assert manager.config["format"] == "structured"
            assert manager.config["console_enabled"] is False


class TestLogRotation:
    """Test log file rotation."""
    
    def test_log_rotation_configuration(self):
        """Test that log rotation is properly configured."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = LoggingManager(temp_dir)
            
            # Get file handlers
            file_handlers = [
                h for h in logging.getLogger().handlers
                if isinstance(h, logging.handlers.RotatingFileHandler)
            ]
            
            assert len(file_handlers) >= 1
            
            for handler in file_handlers:
                assert handler.maxBytes > 0
                assert handler.backupCount > 0


class TestConcurrentLogging:
    """Test concurrent logging scenarios."""
    
    def test_concurrent_logging(self):
        """Test logging from multiple threads."""
        logger = get_logger("concurrent_test")
        messages = []
        
        def worker(worker_id):
            for i in range(10):
                message = f"Worker {worker_id} message {i}"
                logger.info(message)
                messages.append(message)
                time.sleep(0.001)
        
        threads = [threading.Thread(target=worker, args=(i,)) for i in range(3)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        assert len(messages) == 30
    
    def test_concurrent_performance_logging(self):
        """Test concurrent performance logging."""
        perf_logger = get_performance_logger("concurrent_perf")
        results = []
        
        def performance_worker():
            @perf_logger.time_operation("concurrent_operation")
            def timed_operation():
                time.sleep(0.01)
                return "done"
            
            result = timed_operation()
            results.append(result)
        
        threads = [threading.Thread(target=performance_worker) for _ in range(5)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        assert len(results) == 5
        assert all(r == "done" for r in results)


if __name__ == "__main__":
    pytest.main([__file__])