"""
Tests for configuration management system.
"""

import pytest
import tempfile
import yaml
import json
from pathlib import Path
from datetime import datetime
from unittest.mock import patch, MagicMock

from core.configuration import (
    ConfigurationManager, 
    ConfigurationError,
    ConfigurationSchema,
    get_config_manager
)


class TestConfigurationManager:
    """Test configuration management functionality."""
    
    def setup_method(self):
        """Setup test environment."""
        self.temp_dir = tempfile.mkdtemp()
        self.config_manager = ConfigurationManager(self.temp_dir)
    
    def teardown_method(self):
        """Cleanup test environment."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_initialization(self):
        """Test configuration manager initialization."""
        assert self.config_manager.config_dir.exists()
        assert self.config_manager.current_version == "1.1.0"
        assert len(self.config_manager.schemas) == 2
        assert "1.0.0" in self.config_manager.schemas
        assert "1.1.0" in self.config_manager.schemas
    
    def test_schema_setup(self):
        """Test configuration schema setup."""
        schema_1_0 = self.config_manager.schemas["1.0.0"]
        assert schema_1_0.version == "1.0.0"
        assert "frameworks" in schema_1_0.required_fields
        
        schema_1_1 = self.config_manager.schemas["1.1.0"]
        assert schema_1_1.version == "1.1.0"
        assert "frameworks" in schema_1_1.required_fields
        assert "metadata" in schema_1_1.required_fields
        assert "settings" in schema_1_1.optional_fields
    
    def test_create_default_config(self):
        """Test default configuration creation."""
        # Test with non-existent config file
        config = self.config_manager.load_config("docs_sources")
        
        assert "metadata" in config
        assert "frameworks" in config
        assert "settings" in config
        assert config["metadata"]["version"] == "1.1.0"
        assert "react" in config["frameworks"]
    
    def test_load_and_save_config(self):
        """Test configuration loading and saving."""
        # Create test configuration
        test_config = {
            "metadata": {
                "version": "1.1.0",
                "created_at": datetime.now().isoformat(),
                "description": "Test config"
            },
            "frameworks": {
                "vue": {
                    "url": "https://vuejs.org/",
                    "description": "Vue.js framework"
                }
            },
            "settings": {
                "default_framework": "vue",
                "max_cache_size_mb": 50
            }
        }
        
        # Save configuration
        success = self.config_manager.save_config(test_config, "test_config")
        assert success
        
        # Load configuration
        loaded_config = self.config_manager.load_config("test_config")
        assert loaded_config["frameworks"]["vue"]["url"] == "https://vuejs.org/"
        assert loaded_config["settings"]["max_cache_size_mb"] == 50
    
    def test_config_validation(self):
        """Test configuration validation."""
        # Valid configuration
        valid_config = {
            "metadata": {
                "version": "1.1.0",
                "created_at": datetime.now().isoformat()
            },
            "frameworks": {
                "angular": {
                    "url": "https://angular.io/",
                    "description": "Angular framework"
                }
            }
        }
        
        validated = self.config_manager._validate_config(valid_config)
        assert "settings" in validated  # Should add default settings
        
        # Invalid configuration - missing required field
        invalid_config = {
            "metadata": {
                "version": "1.1.0"
            }
            # Missing frameworks
        }
        
        with pytest.raises(ConfigurationError) as exc_info:
            self.config_manager._validate_config(invalid_config)
        assert "Missing required field: frameworks" in str(exc_info.value)
    
    def test_framework_validation(self):
        """Test framework configuration validation."""
        from core.input_validation import ValidationResult
        
        # Valid frameworks
        valid_frameworks = {
            "react": {
                "url": "https://react.dev/",
                "description": "React framework"
            },
            "vue": {
                "url": "https://vuejs.org/",
                "description": "Vue.js framework"
            }
        }
        
        result = self.config_manager._validate_frameworks_v1_1(valid_frameworks)
        assert result.is_valid
        assert len(result.cleaned_value) == 2
        
        # Invalid frameworks - missing URL
        invalid_frameworks = {
            "svelte": {
                "description": "Svelte framework"
                # Missing URL
            }
        }
        
        result = self.config_manager._validate_frameworks_v1_1(invalid_frameworks)
        assert not result.is_valid
        assert any("missing required 'url' field" in error for error in result.errors)
    
    def test_metadata_validation(self):
        """Test metadata validation."""
        # Valid metadata
        valid_metadata = {
            "version": "1.1.0",
            "created_at": datetime.now().isoformat(),
            "description": "Test metadata"
        }
        
        result = self.config_manager._validate_metadata(valid_metadata)
        assert result.is_valid
        assert "last_updated" in result.cleaned_value  # Should be added
        
        # Invalid metadata - invalid timestamp
        invalid_metadata = {
            "version": "1.1.0",
            "created_at": "invalid-timestamp"
        }
        
        result = self.config_manager._validate_metadata(invalid_metadata)
        assert not result.is_valid
    
    def test_settings_validation(self):
        """Test settings validation."""
        # Valid settings
        valid_settings = {
            "default_framework": "react",
            "max_cache_size_mb": 100,
            "rate_limits": {
                "github": {
                    "requests_per_minute": 60,
                    "requests_per_hour": 5000
                }
            }
        }
        
        result = self.config_manager._validate_settings(valid_settings)
        assert result.is_valid
        
        # Invalid settings - negative cache size
        invalid_settings = {
            "max_cache_size_mb": -10
        }
        
        # Should not fail validation (just warning for small values)
        result = self.config_manager._validate_settings(invalid_settings)
        assert result.is_valid  # Small values generate warnings, not errors
    
    def test_version_detection(self):
        """Test configuration version detection."""
        # Version 1.1.0 with explicit metadata
        config_1_1 = {
            "metadata": {"version": "1.1.0"},
            "frameworks": {}
        }
        assert self.config_manager._detect_version(config_1_1) == "1.1.0"
        
        # Version 1.1.0 with metadata but no explicit version
        config_1_1_implicit = {
            "metadata": {"description": "Test"},
            "frameworks": {}
        }
        assert self.config_manager._detect_version(config_1_1_implicit) == "1.1.0"
        
        # Version 1.0.0 (old format)
        config_1_0 = {
            "frameworks": {
                "react": {"url": "https://react.dev/"}
            }
        }
        assert self.config_manager._detect_version(config_1_0) == "1.0.0"
        
        # Empty config defaults to 1.0.0
        empty_config = {}
        assert self.config_manager._detect_version(empty_config) == "1.0.0"
    
    def test_migration_1_0_to_1_1(self):
        """Test migration from version 1.0.0 to 1.1.0."""
        old_config = {
            "frameworks": {
                "react": {
                    "url": "https://react.dev/",
                    "description": "React framework"
                }
            }
        }
        
        migrated = self.config_manager._migrate_1_0_to_1_1(old_config)
        
        assert "metadata" in migrated
        assert migrated["metadata"]["version"] == "1.1.0"
        assert "created_at" in migrated["metadata"]
        assert "settings" in migrated
        assert migrated["frameworks"] == old_config["frameworks"]
    
    def test_configuration_caching(self):
        """Test configuration caching mechanism."""
        # First load should read from file
        config1 = self.config_manager.load_config("docs_sources")
        assert "docs_sources" in self.config_manager._config_cache
        
        # Second load should use cache
        config2 = self.config_manager.load_config("docs_sources")
        assert config1 == config2
        
        # Force reload should bypass cache
        config3 = self.config_manager.load_config("docs_sources", force_reload=True)
        assert config1 == config3
    
    def test_backup_creation(self):
        """Test backup file creation during saves."""
        # Create initial config
        config = {
            "metadata": {"version": "1.1.0"},
            "frameworks": {"test": {"url": "https://test.com"}}
        }
        
        self.config_manager.save_config(config, "test_backup")
        
        # Modify and save again
        config["frameworks"]["test2"] = {"url": "https://test2.com"}
        self.config_manager.save_config(config, "test_backup")
        
        # Check for backup files
        backup_files = list(Path(self.temp_dir).glob("test_backup.yaml.backup.*"))
        assert len(backup_files) == 1
    
    def test_backup_cleanup(self):
        """Test backup file cleanup."""
        config_path = Path(self.temp_dir) / "test_cleanup.yaml"
        
        # Create multiple backup files
        for i in range(10):
            backup_path = config_path.with_suffix(f'.yaml.backup.{i}')
            backup_path.touch()
        
        # Trigger cleanup
        self.config_manager._cleanup_backups(config_path, max_backups=5)
        
        # Check remaining backups
        remaining_backups = list(config_path.parent.glob("test_cleanup.yaml.backup.*"))
        assert len(remaining_backups) == 5
    
    def test_framework_management(self):
        """Test framework addition and removal."""
        # Add framework
        success = self.config_manager.add_framework(
            "svelte", 
            "https://svelte.dev/", 
            "Svelte framework"
        )
        assert success
        
        # Verify addition
        framework_config = self.config_manager.get_framework_config("svelte")
        assert framework_config is not None
        assert framework_config["url"] == "https://svelte.dev/"
        
        # Remove framework
        success = self.config_manager.remove_framework("svelte")
        assert success
        
        # Verify removal
        framework_config = self.config_manager.get_framework_config("svelte")
        assert framework_config is None
    
    def test_invalid_framework_addition(self):
        """Test validation during framework addition."""
        # Invalid URL
        with pytest.raises(ConfigurationError):
            self.config_manager.add_framework("test", "invalid-url")
        
        # Invalid name
        with pytest.raises(ConfigurationError):
            self.config_manager.add_framework("test/invalid", "https://test.com")
    
    def test_configuration_info(self):
        """Test configuration information retrieval."""
        info = self.config_manager.get_configuration_info()
        
        assert "version" in info
        assert "framework_count" in info
        assert "config_file" in info
        assert "cache_status" in info
        assert info["version"] == "1.1.0"
        assert info["framework_count"] >= 1  # At least the default react
    
    def test_yaml_parsing_error(self):
        """Test handling of invalid YAML files."""
        # Create invalid YAML file
        config_path = Path(self.temp_dir) / "invalid.yaml"
        with open(config_path, 'w') as f:
            f.write("invalid: yaml: content: [")
        
        with pytest.raises(ConfigurationError) as exc_info:
            self.config_manager.load_config("invalid")
        assert "Invalid YAML" in str(exc_info.value)
    
    def test_file_permission_error(self):
        """Test handling of file permission errors."""
        with patch('builtins.open', side_effect=PermissionError("Permission denied")):
            with pytest.raises(ConfigurationError) as exc_info:
                self.config_manager.load_config("test")
            assert "Failed to load configuration" in str(exc_info.value)
    
    def test_concurrent_access(self):
        """Test thread safety of configuration manager."""
        import threading
        import time
        
        results = []
        errors = []
        
        def load_config_worker():
            try:
                config = self.config_manager.load_config("docs_sources")
                results.append(config)
            except Exception as e:
                errors.append(e)
        
        # Start multiple threads
        threads = []
        for _ in range(5):
            thread = threading.Thread(target=load_config_worker)
            threads.append(thread)
            thread.start()
        
        # Wait for completion
        for thread in threads:
            thread.join()
        
        # Verify results
        assert len(errors) == 0
        assert len(results) == 5
        
        # All results should be identical
        first_result = results[0]
        for result in results[1:]:
            assert result == first_result


class TestGlobalConfigManager:
    """Test global configuration manager functionality."""
    
    def test_singleton_behavior(self):
        """Test that get_config_manager returns singleton."""
        manager1 = get_config_manager()
        manager2 = get_config_manager()
        
        assert manager1 is manager2
    
    def test_global_manager_functionality(self):
        """Test basic functionality of global manager."""
        manager = get_config_manager()
        
        # Should be able to load config
        config = manager.load_config("docs_sources")
        assert isinstance(config, dict)
        
        # Should have basic structure
        assert "frameworks" in config or "metadata" in config


class TestConfigurationSchema:
    """Test configuration schema functionality."""
    
    def test_schema_creation(self):
        """Test configuration schema creation."""
        schema = ConfigurationSchema(
            version="1.0.0",
            required_fields=["test_field"],
            optional_fields={"optional": "value"},
            field_types={"test_field": str},
            field_validators={}
        )
        
        assert schema.version == "1.0.0"
        assert "test_field" in schema.required_fields
        assert "optional" in schema.optional_fields
        assert schema.field_types["test_field"] == str


class TestConfigurationErrorHandling:
    """Test configuration error handling."""
    
    def test_configuration_error_inheritance(self):
        """Test that ConfigurationError inherits from Exception."""
        error = ConfigurationError("Test error")
        assert isinstance(error, Exception)
        assert str(error) == "Test error"


if __name__ == "__main__":
    pytest.main([__file__])