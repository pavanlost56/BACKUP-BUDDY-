"""
Test suite for CodeInsight CLI functionality.
"""

import subprocess
import sys
from pathlib import Path


def test_cli_help():
    """Test that CLI shows help and exits with code 0."""
    result = subprocess.run([
        sys.executable, "cli.py", "--help"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert "CodeInsight" in result.stdout
    assert "query" in result.stdout
    assert "update" in result.stdout


def test_cli_query_command():
    """Test that query command executes without error."""
    result = subprocess.run([
        sys.executable, "cli.py", "query", "test query"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0


def test_cli_update_dry_run():
    """Test that update command dry-run executes without error."""
    result = subprocess.run([
        sys.executable, "cli.py", "update", "test-framework", "--dry-run"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert "DRY RUN" in result.stdout


def test_cli_update_creates_file():
    """Test that update command creates documentation file."""
    # Clean up any existing file
    test_file = Path("data/docs/httpbin.md")
    if test_file.exists():
        test_file.unlink()
    
    result = subprocess.run([
        sys.executable, "cli.py", "update", "httpbin"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert test_file.exists()
    
    # Verify file has actual scraped content
    content = test_file.read_text()
    assert "httpbin" in content.lower()
    assert "Source:" in content