"""
Integration tests for the update workflow.
"""

import subprocess
import sys
import tempfile
import shutil
from pathlib import Path


def test_update_list_frameworks():
    """Test that listing frameworks works."""
    result = subprocess.run([
        sys.executable, "cli.py", "update", "--list-frameworks"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert "Available Frameworks" in result.stdout
    assert "react" in result.stdout
    assert "vue" in result.stdout


def test_update_dry_run():
    """Test that dry-run shows what would be updated."""
    result = subprocess.run([
        sys.executable, "cli.py", "update", "httpbin", "--dry-run"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert "DRY RUN" in result.stdout
    assert "httpbin" in result.stdout
    assert "https://httpbin.org/html" in result.stdout


def test_update_workflow_integration():
    """Test the complete update workflow."""
    # Clean up any existing httpbin files first
    docs_file = Path("data/docs/httpbin.md")
    db_dir = Path("data/db/httpbin")
    
    # Test update command
    result = subprocess.run([
        sys.executable, "cli.py", "update", "httpbin"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert "Update Complete" in result.stdout
    assert docs_file.exists()
    assert db_dir.exists()
    
    # Verify database files exist
    assert (db_dir / "chunks.json").exists()
    assert (db_dir / "embeddings.npy").exists()
    assert (db_dir / "metadata.json").exists()
    assert (db_dir / "vectorizer.pkl").exists()
    
    # Test query after update
    query_result = subprocess.run([
        sys.executable, "cli.py", "query", "test query", "--framework", "httpbin"
    ], capture_output=True, text=True, cwd=".")
    
    assert query_result.returncode == 0
    assert "CodeInsight Answer" in query_result.stdout
    assert "Sources" in query_result.stdout


def test_update_nonexistent_framework():
    """Test updating a framework not in configuration."""
    result = subprocess.run([
        sys.executable, "cli.py", "update", "nonexistent-framework"
    ], capture_output=True, text=True, cwd=".")
    
    # Should still attempt to update but may fail due to invalid URL
    # The important thing is it doesn't crash on unknown frameworks
    assert "nonexistent-framework" in result.stdout.lower() or "nonexistent-framework" in result.stderr.lower()


def test_update_help():
    """Test that update command help works."""
    result = subprocess.run([
        sys.executable, "cli.py", "update", "--help"
    ], capture_output=True, text=True, cwd=".")
    
    assert result.returncode == 0
    assert "Update documentation for a framework" in result.stdout
    assert "--force" in result.stdout
    assert "--dry-run" in result.stdout
    assert "--list-frameworks" in result.stdout