"""
Tests for the input validation system.
"""

import pytest
import tempfile
import json
from pathlib import Path
from unittest.mock import patch

from core.input_validation import (
    ValidationResult, ValidationRule, RegexRule, LengthRule, TypeRule,
    ChoiceRule, PathRule, URLRule, JSONRule, Validator,
    validate_input, sanitize_user_input, safe_path, validate_url
)


class TestValidationResult:
    """Test ValidationResult dataclass."""
    
    def test_validation_result_success(self):
        """Test successful validation result."""
        result = ValidationResult(is_valid=True, cleaned_value="test")
        
        assert result.is_valid is True
        assert result.cleaned_value == "test"
        assert result.errors == []
        assert result.warnings == []
    
    def test_validation_result_failure(self):
        """Test failed validation result."""
        result = ValidationResult(
            is_valid=False,
            errors=["Error 1", "Error 2"],
            warnings=["Warning 1"]
        )
        
        assert result.is_valid is False
        assert result.errors == ["Error 1", "Error 2"]
        assert result.warnings == ["Warning 1"]


class TestRegexRule:
    """Test RegexRule validation."""
    
    def test_regex_rule_match(self):
        """Test regex rule matching."""
        rule = RegexRule(r'^[a-z]+$', "lowercase_only")
        result = rule.validate("hello")
        
        assert result.is_valid is True
        assert result.cleaned_value == "hello"
    
    def test_regex_rule_no_match(self):
        """Test regex rule not matching."""
        rule = RegexRule(r'^[a-z]+$', "lowercase_only", "Must be lowercase letters only")
        result = rule.validate("Hello123")
        
        assert result.is_valid is False
        assert "Must be lowercase letters only" in result.errors
    
    def test_regex_rule_case_insensitive(self):
        """Test regex rule with case insensitive flag."""
        import re
        rule = RegexRule(r'^hello$', "hello_match", flags=re.IGNORECASE)
        result = rule.validate("HELLO")
        
        assert result.is_valid is True


class TestLengthRule:
    """Test LengthRule validation."""
    
    def test_length_rule_valid(self):
        """Test valid length."""
        rule = LengthRule(min_length=2, max_length=10)
        result = rule.validate("hello")
        
        assert result.is_valid is True
        assert result.cleaned_value == "hello"
    
    def test_length_rule_too_short(self):
        """Test string too short."""
        rule = LengthRule(min_length=5, max_length=10)
        result = rule.validate("hi")
        
        assert result.is_valid is False
        assert "Too short" in result.errors[0]
    
    def test_length_rule_too_long(self):
        """Test string too long."""
        rule = LengthRule(min_length=2, max_length=5)
        result = rule.validate("hello world")
        
        assert result.is_valid is False
        assert "Too long" in result.errors[0]
    
    def test_length_rule_list(self):
        """Test length rule with list."""
        rule = LengthRule(min_length=2, max_length=5)
        result = rule.validate([1, 2, 3])
        
        assert result.is_valid is True
    
    def test_length_rule_min_only(self):
        """Test length rule with minimum only."""
        rule = LengthRule(min_length=3)
        result = rule.validate("hello")
        
        assert result.is_valid is True
    
    def test_length_rule_max_only(self):
        """Test length rule with maximum only."""
        rule = LengthRule(max_length=5)
        result = rule.validate("hi")
        
        assert result.is_valid is True


class TestTypeRule:
    """Test TypeRule validation."""
    
    def test_type_rule_correct_type(self):
        """Test correct type validation."""
        rule = TypeRule(int)
        result = rule.validate(42)
        
        assert result.is_valid is True
        assert result.cleaned_value == 42
    
    def test_type_rule_string_to_int(self):
        """Test string to int conversion."""
        rule = TypeRule(int)
        result = rule.validate("42")
        
        assert result.is_valid is True
        assert result.cleaned_value == 42
    
    def test_type_rule_string_to_float(self):
        """Test string to float conversion."""
        rule = TypeRule(float)
        result = rule.validate("3.14")
        
        assert result.is_valid is True
        assert result.cleaned_value == 3.14
    
    def test_type_rule_to_bool_true(self):
        """Test conversion to boolean true."""
        rule = TypeRule(bool)
        
        for value in ["true", "1", "yes", "on", True]:
            result = rule.validate(value)
            assert result.is_valid is True
            assert result.cleaned_value is True
    
    def test_type_rule_to_bool_false(self):
        """Test conversion to boolean false."""
        rule = TypeRule(bool)
        
        for value in ["false", "0", "no", "off", False]:
            result = rule.validate(value)
            assert result.is_valid is True
            assert result.cleaned_value is False
    
    def test_type_rule_invalid_conversion(self):
        """Test invalid type conversion."""
        rule = TypeRule(int)
        result = rule.validate("not_a_number")
        
        assert result.is_valid is False
        assert "Expected type int" in result.errors[0]


class TestChoiceRule:
    """Test ChoiceRule validation."""
    
    def test_choice_rule_valid(self):
        """Test valid choice."""
        rule = ChoiceRule(["option1", "option2", "option3"])
        result = rule.validate("option2")
        
        assert result.is_valid is True
        assert result.cleaned_value == "option2"
    
    def test_choice_rule_invalid(self):
        """Test invalid choice."""
        rule = ChoiceRule(["option1", "option2"])
        result = rule.validate("option3")
        
        assert result.is_valid is False
        assert "Must be one of" in result.errors[0]
    
    def test_choice_rule_case_insensitive(self):
        """Test case insensitive choice."""
        rule = ChoiceRule(["Option1", "Option2"], case_sensitive=False)
        result = rule.validate("option1")
        
        assert result.is_valid is True
        assert result.cleaned_value == "Option1"  # Returns original case
    
    def test_choice_rule_case_sensitive(self):
        """Test case sensitive choice."""
        rule = ChoiceRule(["Option1", "Option2"], case_sensitive=True)
        result = rule.validate("option1")
        
        assert result.is_valid is False


class TestPathRule:
    """Test PathRule validation."""
    
    def setup_method(self):
        """Set up test with temporary directory."""
        self.temp_dir = tempfile.mkdtemp()
        self.temp_path = Path(self.temp_dir)
        self.test_file = self.temp_path / "test.txt"
        self.test_file.write_text("test content")
    
    def teardown_method(self):
        """Clean up temporary directory."""
        import shutil
        if self.temp_path.exists():
            shutil.rmtree(self.temp_path)
    
    def test_path_rule_basic(self):
        """Test basic path validation."""
        rule = PathRule()
        result = rule.validate("/some/path")
        
        assert result.is_valid is True
        assert Path(result.cleaned_value).is_absolute()
    
    def test_path_rule_existing_file(self):
        """Test existing file validation."""
        rule = PathRule(must_exist=True, must_be_file=True)
        result = rule.validate(str(self.test_file))
        
        assert result.is_valid is True
    
    def test_path_rule_existing_directory(self):
        """Test existing directory validation."""
        rule = PathRule(must_exist=True, must_be_dir=True)
        result = rule.validate(str(self.temp_path))
        
        assert result.is_valid is True
    
    def test_path_rule_nonexistent_must_exist(self):
        """Test nonexistent path when must exist."""
        rule = PathRule(must_exist=True)
        result = rule.validate("/nonexistent/path")
        
        assert result.is_valid is False
        assert "does not exist" in result.errors[0]
    
    def test_path_rule_file_as_directory(self):
        """Test file when directory required."""
        rule = PathRule(must_exist=True, must_be_dir=True)
        result = rule.validate(str(self.test_file))
        
        assert result.is_valid is False
        assert "must be a directory" in result.errors[0]
    
    def test_path_rule_directory_as_file(self):
        """Test directory when file required."""
        rule = PathRule(must_exist=True, must_be_file=True)
        result = rule.validate(str(self.temp_path))
        
        assert result.is_valid is False
        assert "must be a file" in result.errors[0]
    
    def test_path_rule_allowed_extensions(self):
        """Test allowed file extensions."""
        rule = PathRule(allowed_extensions={".txt", ".md"})
        
        # Valid extension
        result = rule.validate("test.txt")
        assert result.is_valid is True
        
        # Invalid extension
        result = rule.validate("test.exe")
        assert result.is_valid is False
        assert "File extension must be one of" in result.errors[0]
    
    def test_path_rule_create_directories(self):
        """Test directory creation."""
        new_path = self.temp_path / "new" / "directory" / "file.txt"
        rule = PathRule(create_dirs=True)
        
        result = rule.validate(str(new_path))
        
        assert result.is_valid is True
        assert new_path.parent.exists()
        assert "Created directory" in result.warnings[0]


class TestURLRule:
    """Test URLRule validation."""
    
    def test_url_rule_valid_http(self):
        """Test valid HTTP URL."""
        rule = URLRule()
        result = rule.validate("http://example.com")
        
        assert result.is_valid is True
        assert result.cleaned_value == "http://example.com"
    
    def test_url_rule_valid_https(self):
        """Test valid HTTPS URL."""
        rule = URLRule()
        result = rule.validate("https://example.com/path?query=value")
        
        assert result.is_valid is True
    
    def test_url_rule_invalid_scheme(self):
        """Test invalid URL scheme."""
        rule = URLRule()
        result = rule.validate("ftp://example.com")
        
        assert result.is_valid is False
        assert "URL scheme must be one of" in result.errors[0]
    
    def test_url_rule_no_domain(self):
        """Test URL without domain."""
        rule = URLRule()
        result = rule.validate("http://")
        
        assert result.is_valid is False
        assert "must have a valid domain" in result.errors[0]
    
    def test_url_rule_custom_schemes(self):
        """Test custom allowed schemes."""
        rule = URLRule(allowed_schemes={"ftp", "sftp"})
        result = rule.validate("ftp://example.com")
        
        assert result.is_valid is True
    
    def test_url_rule_no_netloc_required(self):
        """Test URL without netloc requirement."""
        rule = URLRule(require_netloc=False)
        result = rule.validate("file:///path/to/file")
        
        assert result.is_valid is True


class TestJSONRule:
    """Test JSONRule validation."""
    
    def test_json_rule_valid_string(self):
        """Test valid JSON string."""
        rule = JSONRule()
        json_string = '{"key": "value", "number": 42}'
        result = rule.validate(json_string)
        
        assert result.is_valid is True
        assert result.cleaned_value == {"key": "value", "number": 42}
    
    def test_json_rule_valid_dict(self):
        """Test already parsed dictionary."""
        rule = JSONRule()
        data = {"key": "value"}
        result = rule.validate(data)
        
        assert result.is_valid is True
        assert result.cleaned_value == data
    
    def test_json_rule_valid_list(self):
        """Test already parsed list."""
        rule = JSONRule()
        data = [1, 2, 3]
        result = rule.validate(data)
        
        assert result.is_valid is True
        assert result.cleaned_value == data
    
    def test_json_rule_invalid_json(self):
        """Test invalid JSON string."""
        rule = JSONRule()
        result = rule.validate('{"key": value}')  # Missing quotes around value
        
        assert result.is_valid is False
        assert "Invalid JSON" in result.errors[0]


class TestValidator:
    """Test Validator class."""
    
    def setup_method(self):
        """Set up test instance."""
        self.validator = Validator()
    
    def test_validate_input_success(self):
        """Test successful input validation."""
        rules = [LengthRule(min_length=3), TypeRule(str)]
        result = self.validator.validate_input("hello", rules)
        
        assert result.is_valid is True
        assert result.cleaned_value == "hello"
    
    def test_validate_input_failure(self):
        """Test failed input validation."""
        rules = [LengthRule(min_length=10)]
        result = self.validator.validate_input("hi", rules)
        
        assert result.is_valid is False
        assert len(result.errors) > 0
    
    def test_validate_by_type_filename(self):
        """Test filename validation."""
        result = self.validator.validate_by_type("test_file.txt", "filename")
        assert result.is_valid is True
        
        result = self.validator.validate_by_type("invalid|filename", "filename")
        assert result.is_valid is False
    
    def test_validate_by_type_command_name(self):
        """Test command name validation."""
        result = self.validator.validate_by_type("valid_command", "command_name")
        assert result.is_valid is True
        
        result = self.validator.validate_by_type("123invalid", "command_name")
        assert result.is_valid is False
    
    def test_validate_by_type_url(self):
        """Test URL validation."""
        result = self.validator.validate_by_type("https://example.com", "url")
        assert result.is_valid is True
        
        result = self.validator.validate_by_type("not_a_url", "url")
        assert result.is_valid is False
    
    def test_validate_by_type_unknown(self):
        """Test unknown validation type."""
        result = self.validator.validate_by_type("test", "unknown_type")
        assert result.is_valid is False
        assert "Unknown validation type" in result.errors[0]
    
    def test_sanitize_string(self):
        """Test string sanitization."""
        input_str = "Hello\nWorld\x00\x01Test"
        sanitized = self.validator.sanitize_string(input_str)
        
        assert "\x00" not in sanitized
        assert "\x01" not in sanitized
        assert "Hello" in sanitized
        assert "World" in sanitized
    
    def test_sanitize_string_max_length(self):
        """Test string sanitization with max length."""
        input_str = "a" * 1000
        sanitized = self.validator.sanitize_string(input_str, max_length=100)
        
        assert len(sanitized) == 100
    
    def test_sanitize_string_allowed_chars(self):
        """Test string sanitization with allowed characters."""
        input_str = "Hello123!@#"
        sanitized = self.validator.sanitize_string(
            input_str, 
            allowed_chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        )
        
        assert sanitized == "Hello123"
    
    def test_sanitize_filename(self):
        """Test filename sanitization."""
        dangerous_filename = "test<>file|name*.txt"
        sanitized = self.validator.sanitize_filename(dangerous_filename)
        
        assert "<" not in sanitized
        assert ">" not in sanitized
        assert "|" not in sanitized
        assert "*" not in sanitized
        assert "test" in sanitized
        assert "file" in sanitized
    
    def test_sanitize_filename_empty(self):
        """Test sanitization of empty filename."""
        sanitized = self.validator.sanitize_filename("")
        assert sanitized == "unnamed_file"
    
    def test_validate_config_data_valid(self):
        """Test valid configuration data."""
        config = {
            "valid_key": "value",
            "number_key": 42,
            "boolean_key": True
        }
        
        result = self.validator.validate_config_data(config)
        assert result.is_valid is True
        assert result.cleaned_value == config
    
    def test_validate_config_data_invalid_structure(self):
        """Test invalid configuration structure."""
        result = self.validator.validate_config_data("not_a_dict")
        assert result.is_valid is False
        assert "must be a dictionary" in result.errors[0]
    
    def test_validate_config_data_invalid_key(self):
        """Test invalid configuration key."""
        config = {"123invalid_key": "value"}
        result = self.validator.validate_config_data(config)
        
        assert result.is_valid is False
        assert any("Config key" in error for error in result.errors)
    
    def test_validate_command_args(self):
        """Test command arguments validation."""
        args = ["valid_arg", "another-arg", "arg_with_123"]
        result = self.validator.validate_command_args(args)
        
        assert result.is_valid is True
        assert result.cleaned_value == args
    
    def test_validate_command_args_suspicious(self):
        """Test command arguments with suspicious content."""
        args = ["normal_arg", "arg_with_;rm -rf /"]
        result = self.validator.validate_command_args(args)
        
        assert result.is_valid is True  # Still valid but with warnings
        assert len(result.warnings) > 0
        assert any("suspicious pattern" in warning for warning in result.warnings)


class TestConvenienceFunctions:
    """Test convenience functions."""
    
    def test_validate_input_function(self):
        """Test validate_input convenience function."""
        result = validate_input("test_file.txt", "filename")
        assert result.is_valid is True
    
    def test_sanitize_user_input_function(self):
        """Test sanitize_user_input convenience function."""
        input_str = "Hello\x00World"
        sanitized = sanitize_user_input(input_str)
        assert "\x00" not in sanitized
        assert "Hello" in sanitized
    
    def test_safe_path_function(self):
        """Test safe_path convenience function."""
        result = safe_path("/some/path")
        assert result.is_valid is True
    
    def test_validate_url_function(self):
        """Test validate_url convenience function."""
        result = validate_url("https://example.com")
        assert result.is_valid is True
        
        result = validate_url("invalid_url")
        assert result.is_valid is False
    
    def test_validate_url_custom_schemes(self):
        """Test validate_url with custom schemes."""
        result = validate_url("ftp://example.com", allowed_schemes={"ftp"})
        assert result.is_valid is True


if __name__ == "__main__":
    pytest.main([__file__])