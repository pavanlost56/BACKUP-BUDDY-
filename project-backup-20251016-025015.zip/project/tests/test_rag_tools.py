"""
Tests for RAG tools integration with the agent system.
Updated to match current tool interface (execute returns dict, uses **kwargs).
"""

import pytest
from unittest.mock import patch, MagicMock, Mock, mock_open
import tempfile
import os

from core.rag_tools import RAGQueryTool, DocumentationScrapeTool, FrameworkListTool


class TestRAGQueryTool:
    """Test RAG query tool functionality."""
    
    def setup_method(self):
        self.tool = RAGQueryTool()
    
    def test_tool_name(self):
        assert self.tool.name == "rag_query_tool"
    
    def test_tool_description(self):
        assert "rag" in self.tool.description.lower()
        assert "query" in self.tool.description.lower()
    
    def test_parameters(self):
        params = self.tool.parameters
        assert "query" in params
        assert "framework" in params
        assert "top_k" in params
    
    @patch('core.rag_tools.answer_query')
    @patch('core.rag_tools.retrieve')
    def test_execute_success(self, mock_retrieve, mock_answer):
        # Setup mocks
        mock_retrieve.return_value = [
            {"content": "React hooks are functions that let you use state", "metadata": {"source": "react.md"}}
        ]
        mock_answer.return_value = "React hooks allow you to use state in functional components."
        
        # Execute
        result = self.tool.execute(query="What are React hooks?", framework="react", top_k="3")
        
        assert result["success"] is True
        assert "React hooks allow you to use state" in result["result"]
        mock_retrieve.assert_called_once()
        mock_answer.assert_called_once()
    
    @patch('core.rag_tools.retrieve')
    def test_execute_retriever_error(self, mock_retrieve):
        mock_retrieve.side_effect = Exception("Retrieval failed")
        
        result = self.tool.execute(query="test query")
        
        assert result["success"] is False
        assert "retrieval failed" in result["error"].lower()
    
    def test_execute_missing_required_param(self):
        result = self.tool.execute()
        assert result["success"] is False
        assert "missing required parameter: query" in result["error"].lower()
    
    def test_execute_invalid_top_k(self):
        result = self.tool.execute(query="test", top_k="invalid")
        assert result["success"] is False
        assert "invalid top_k parameter" in result["error"].lower()


class TestDocumentationScrapeTool:
    """Test documentation scraping tool functionality."""
    
    def setup_method(self):
        self.tool = DocumentationScrapeTool()
    
    def test_tool_name(self):
        assert self.tool.name == "doc_scrape_tool"
    
    def test_tool_description(self):
        assert "scrape" in self.tool.description.lower()
        assert "documentation" in self.tool.description.lower()
    
    def test_parameters(self):
        params = self.tool.parameters
        assert "framework" in params
        assert "force_update" in params
    
    @patch('core.rag_tools.build_embeddings')
    def test_execute_success(self, mock_build):
        # Setup mocks
        mock_build.return_value = {
            "chunks_count": 42,
            "db_path": "data/db/react"
        }
        
        # Execute
        result = self.tool.execute(framework="react", force_update="false")
        
        assert result["success"] is True
        assert "react" in result["result"].lower()
        assert "42" in result["result"]
        mock_build.assert_called_once_with("react")
    
    @patch('core.rag_tools.build_embeddings')
    def test_execute_scraper_error(self, mock_build):
        mock_build.side_effect = Exception("Scraping failed")
        
        result = self.tool.execute(framework="react")
        
        assert result["success"] is False
        assert "scraping failed" in result["error"].lower()
    
    def test_execute_missing_framework(self):
        result = self.tool.execute()
        assert result["success"] is False
        assert "missing required parameter: framework" in result["error"].lower()


class TestFrameworkListTool:
    """Test framework listing tool functionality."""
    
    def setup_method(self):
        self.tool = FrameworkListTool()
    
    def test_tool_name(self):
        assert self.tool.name == "framework_list_tool"
    
    def test_tool_description(self):
        assert "list" in self.tool.description.lower()
        assert "framework" in self.tool.description.lower()
    
    def test_parameters(self):
        params = self.tool.parameters
        assert "format" in params
    
    def test_execute_success_with_config_file(self):
        # Create temporary config file
        config_data = {
            "frameworks": [
                {"name": "react", "url": "https://react.dev"},
                {"name": "vue", "url": "https://vuejs.org"}
            ]
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            import yaml
            yaml.dump(config_data, f)
            config_path = f.name

        try:
            # Mock the config path
            with patch('core.rag_tools.os.path.exists', return_value=True), \
                 patch('builtins.open', mock_open()), \
                 patch('core.rag_tools.yaml.safe_load', return_value=config_data):

                result = self.tool.execute()
                
                assert result["success"] is True
                assert "react" in result["result"]
                assert "vue" in result["result"]
        finally:
            os.unlink(config_path)
    
    def test_execute_no_config_file(self):
        with patch('core.rag_tools.os.path.exists', return_value=False):
            result = self.tool.execute()
            
            assert result["success"] is True
            assert "react" in result["result"].lower()  # Default frameworks should be listed
    
    def test_execute_json_format(self):
        with patch('core.rag_tools.os.path.exists', return_value=False):
            result = self.tool.execute(format="json")
            
            assert result["success"] is True
            import json
            # Should be valid JSON
            json.loads(result["result"])
    
    def test_execute_config_load_error(self):
        with patch('core.rag_tools.os.path.exists', return_value=True), \
             patch('builtins.open', side_effect=Exception("File error")):

            result = self.tool.execute()
            
            assert result["success"] is True  # Falls back to default frameworks
            assert "react" in result["result"].lower()


class TestRAGToolsIntegration:
    """Test RAG tools integration with agent system."""
    
    def test_all_tools_implement_tool_interface(self):
        """Verify all RAG tools properly implement the Tool interface."""
        from core.tools import Tool
        
        tools = [RAGQueryTool(), DocumentationScrapeTool(), FrameworkListTool()]
        
        for tool in tools:
            assert isinstance(tool, Tool)
            assert hasattr(tool, 'name')
            assert hasattr(tool, 'description')
            assert hasattr(tool, 'parameters')
            assert hasattr(tool, 'execute')
            assert callable(tool.execute)
    
    def test_tools_can_be_registered(self):
        """Test that RAG tools can be registered with ToolRegistry."""
        from core.tools import ToolRegistry
        
        registry = ToolRegistry()
        tools = [RAGQueryTool(), DocumentationScrapeTool(), FrameworkListTool()]
        
        for tool in tools:
            registry.register(tool)
            retrieved_tool = registry.get_tool(tool.name)
            assert retrieved_tool is not None
            assert retrieved_tool.name == tool.name