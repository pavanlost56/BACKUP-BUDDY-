"""
Tests for the caching system.
"""

import pytest
import time
import tempfile
import shutil
from pathlib import Path
from datetime import datetime, timedelta
from unittest.mock import patch, Mock

from core.caching import (
    IntelligentCache, CacheStrategy, CacheEntry,
    cached, get_cache
)


class TestCacheEntry:
    """Test CacheEntry dataclass."""
    
    def test_cache_entry_creation(self):
        """Test cache entry creation."""
        now = datetime.now()
        entry = CacheEntry(
            key="test_key",
            data="test_data",
            created_at=now,
            last_accessed=now,
            access_count=1,
            size_bytes=100
        )
        
        assert entry.key == "test_key"
        assert entry.data == "test_data"
        assert entry.created_at == now
        assert entry.last_accessed == now
        assert entry.access_count == 1
        assert entry.size_bytes == 100
        assert entry.expires_at is None
        assert entry.metadata is None


class TestCacheStrategy:
    """Test CacheStrategy configuration."""
    
    def test_cache_strategy_defaults(self):
        """Test default cache strategy."""
        strategy = CacheStrategy()
        
        assert strategy.max_size_mb == 100
        assert strategy.default_ttl_hours == 24
        assert strategy.max_entries == 1000
        assert strategy.eviction_policy == "lru"
        assert strategy.compression is True
    
    def test_cache_strategy_custom(self):
        """Test custom cache strategy."""
        strategy = CacheStrategy(
            max_size_mb=50,
            default_ttl_hours=12,
            max_entries=500,
            eviction_policy="lfu",
            compression=False
        )
        
        assert strategy.max_size_mb == 50
        assert strategy.default_ttl_hours == 12
        assert strategy.max_entries == 500
        assert strategy.eviction_policy == "lfu"
        assert strategy.compression is False


class TestIntelligentCache:
    """Test IntelligentCache class."""
    
    def setup_method(self):
        """Set up test instance with temporary directory."""
        self.temp_dir = tempfile.mkdtemp()
        self.cache_dir = Path(self.temp_dir) / "cache"
        self.strategy = CacheStrategy(max_size_mb=10, max_entries=5)
        self.cache = IntelligentCache(str(self.cache_dir), self.strategy)
    
    def teardown_method(self):
        """Clean up temporary directory."""
        if Path(self.temp_dir).exists():
            shutil.rmtree(self.temp_dir)
    
    def test_cache_initialization(self):
        """Test cache initialization."""
        assert self.cache.cache_dir == self.cache_dir
        assert self.cache.strategy == self.strategy
        assert len(self.cache.memory_cache) == 0
        assert "hits" in self.cache.stats
        assert "misses" in self.cache.stats
    
    def test_generate_key(self):
        """Test cache key generation."""
        key1 = self.cache._generate_key("test_string")
        key2 = self.cache._generate_key("test_string")
        key3 = self.cache._generate_key("different_string")
        
        assert key1 == key2  # Same input should generate same key
        assert key1 != key3  # Different input should generate different key
        assert len(key1) == 32  # SHA256 truncated to 32 chars
    
    def test_generate_key_dict(self):
        """Test cache key generation for dictionary."""
        data1 = {"key": "value", "number": 42}
        data2 = {"number": 42, "key": "value"}  # Different order
        
        key1 = self.cache._generate_key(data1)
        key2 = self.cache._generate_key(data2)
        
        assert key1 == key2  # Should be same due to sorting
    
    def test_serialize_deserialize_data(self):
        """Test data serialization and deserialization."""
        test_data = {"key": "value", "numbers": [1, 2, 3]}
        
        serialized = self.cache._serialize_data(test_data)
        deserialized = self.cache._deserialize_data(serialized)
        
        assert deserialized == test_data
    
    def test_serialize_compression(self):
        """Test data compression during serialization."""
        # Large data that should trigger compression
        large_data = "x" * 2000
        
        serialized = self.cache._serialize_data(large_data)
        deserialized = self.cache._deserialize_data(serialized)
        
        assert deserialized == large_data
    
    def test_get_cache_file_path(self):
        """Test cache file path generation."""
        key = "abcd1234567890"
        path = self.cache._get_cache_file_path(key)
        
        expected_path = self.cache_dir / "ab" / f"{key}.cache"
        assert path == expected_path
    
    def test_calculate_size(self):
        """Test size calculation."""
        test_data = "test_string"
        size = self.cache._calculate_size(test_data)
        
        assert size > 0
        assert isinstance(size, int)
    
    def test_set_and_get_memory_cache(self):
        """Test setting and getting from memory cache."""
        key = "test_key"
        data = "test_data"
        
        # Set data
        result = self.cache.set(key, data)
        assert result is True
        
        # Get data
        retrieved = self.cache.get(key)
        assert retrieved == data
        
        # Check statistics
        stats = self.cache.get_statistics()
        assert stats["hits"] == 1
        assert stats["misses"] == 0
    
    def test_get_nonexistent_key(self):
        """Test getting nonexistent key."""
        retrieved = self.cache.get("nonexistent_key")
        assert retrieved is None
        
        # Check statistics
        stats = self.cache.get_statistics()
        assert stats["misses"] == 1
    
    def test_set_with_ttl(self):
        """Test setting data with TTL."""
        key = "test_key"
        data = "test_data"
        
        # Set with very short TTL
        result = self.cache.set(key, data, ttl_hours=0.0001)  # ~0.36 seconds
        assert result is True
        
        # Should be available immediately
        retrieved = self.cache.get(key)
        assert retrieved == data
        
        # Wait for expiration
        time.sleep(0.5)
        
        # Should be expired
        retrieved = self.cache.get(key)
        assert retrieved is None
    
    def test_delete_entry(self):
        """Test deleting cache entry."""
        key = "test_key"
        data = "test_data"
        
        # Set data
        self.cache.set(key, data)
        assert self.cache.get(key) == data
        
        # Delete data
        result = self.cache.delete(key)
        assert result is True
        
        # Should be gone
        assert self.cache.get(key) is None
    
    def test_delete_nonexistent_entry(self):
        """Test deleting nonexistent entry."""
        result = self.cache.delete("nonexistent_key")
        assert result is False
    
    def test_clear_cache(self):
        """Test clearing cache."""
        # Set some data
        for i in range(3):
            self.cache.set(f"key_{i}", f"data_{i}")
        
        # Verify data exists
        assert self.cache.get("key_0") == "data_0"
        
        # Clear cache
        self.cache.clear()
        
        # Verify data is gone
        assert self.cache.get("key_0") is None
        assert len(self.cache.memory_cache) == 0
    
    def test_clear_cache_pattern(self):
        """Test clearing cache with pattern."""
        # Set some data
        self.cache.set("user_1", "user_data_1")
        self.cache.set("user_2", "user_data_2")
        self.cache.set("config_1", "config_data_1")
        
        # Clear only user keys
        self.cache.clear(pattern="user")
        
        # User keys should be gone, config should remain
        assert self.cache.get("user_1") is None
        assert self.cache.get("user_2") is None
        assert self.cache.get("config_1") == "config_data_1"
    
    def test_eviction_by_count(self):
        """Test eviction when max entries exceeded."""
        # Fill cache to limit
        for i in range(self.strategy.max_entries):
            self.cache.set(f"key_{i}", f"data_{i}")
        
        # Add one more to trigger eviction
        self.cache.set("extra_key", "extra_data")
        
        # Check that we don't exceed the limit
        assert len(self.cache.memory_cache) <= self.strategy.max_entries
        
        # Newest item should still be there
        assert self.cache.get("extra_key") == "extra_data"
    
    def test_access_count_tracking(self):
        """Test access count tracking."""
        key = "test_key"
        data = "test_data"
        
        # Set data
        self.cache.set(key, data)
        
        # Access multiple times
        for _ in range(3):
            self.cache.get(key)
        
        # Check access count in memory cache
        entry = self.cache.memory_cache[key]
        assert entry.access_count >= 3  # Set counts as 1, plus 3 gets
    
    def test_disk_persistence(self):
        """Test disk persistence."""
        key = "test_key"
        data = "test_data"
        
        # Set data (should persist to disk)
        self.cache.set(key, data)
        
        # Clear memory cache to force disk read
        self.cache.memory_cache.clear()
        
        # Should still be retrievable from disk
        retrieved = self.cache.get(key)
        assert retrieved == data
    
    def test_get_statistics(self):
        """Test cache statistics."""
        # Add some data and access it
        self.cache.set("key1", "data1")
        self.cache.set("key2", "data2")
        self.cache.get("key1")  # Hit
        self.cache.get("nonexistent")  # Miss
        
        stats = self.cache.get_statistics()
        
        assert stats["hits"] >= 1
        assert stats["misses"] >= 1
        assert stats["total_requests"] >= 2
        assert "hit_rate" in stats
        assert "memory_entries" in stats
        assert "disk_entries" in stats


class TestCachedDecorator:
    """Test cached decorator."""
    
    def setup_method(self):
        """Set up test."""
        # Clear any existing cache instances
        from core.caching import _cache_instances
        _cache_instances.clear()
    
    def test_cached_decorator_basic(self):
        """Test basic cached decorator."""
        call_count = 0
        
        @cached(ttl_hours=1)
        def test_function(x, y):
            nonlocal call_count
            call_count += 1
            return x + y
        
        # First call should execute function
        result1 = test_function(2, 3)
        assert result1 == 5
        assert call_count == 1
        
        # Second call should use cache
        result2 = test_function(2, 3)
        assert result2 == 5
        assert call_count == 1  # Should not increment
    
    def test_cached_decorator_different_args(self):
        """Test cached decorator with different arguments."""
        call_count = 0
        
        # Use a custom key_func to guarantee distinct cache keys per arg pair
        @cached(ttl_hours=1, key_func=lambda x, y: f"pair_{x}_{y}")
        def test_function(x, y):
            nonlocal call_count
            call_count += 1
            return x + y
        
        # Different arguments should trigger new execution
        result1 = test_function(2, 3)
        result2 = test_function(4, 5)
        
        assert result1 == 5
        assert result2 == 9
        assert call_count == 2
    
    def test_cached_decorator_custom_key_func(self):
        """Test cached decorator with custom key function."""
        call_count = 0
        
        def key_func(name, age):
            return f"person_{name}"
        
        @cached(key_func=key_func, ttl_hours=1)
        def get_person_info(name, age):
            nonlocal call_count
            call_count += 1
            return f"{name} is {age} years old"
        
        # Same name should use cache even with different age
        result1 = get_person_info("Alice", 25)
        result2 = get_person_info("Alice", 30)
        
        assert result1 == "Alice is 25 years old"
        assert result2 == "Alice is 25 years old"  # Should be cached
        assert call_count == 1
    
    def test_cached_decorator_preserves_metadata(self):
        """Test that decorator preserves function metadata."""
        @cached(ttl_hours=1)
        def test_function(x, y):
            """Test function docstring."""
            return x + y
        
        assert test_function.__name__ == "test_function"
        assert test_function.__doc__ == "Test function docstring."
    
    def test_cached_decorator_with_exception(self):
        """Test cached decorator with function that raises exception."""
        call_count = 0
        
        @cached(ttl_hours=1)
        def test_function():
            nonlocal call_count
            call_count += 1
            raise ValueError("Test error")
        
        # Exception should not be cached
        with pytest.raises(ValueError):
            test_function()
        
        with pytest.raises(ValueError):
            test_function()
        
        assert call_count == 2  # Should execute both times


class TestGetCache:
    """Test get_cache function."""
    
    def setup_method(self):
        """Set up test."""
        # Clear any existing cache instances
        from core.caching import _cache_instances
        _cache_instances.clear()
    
    def test_get_cache_default(self):
        """Test getting default cache."""
        cache = get_cache()
        assert isinstance(cache, IntelligentCache)
    
    def test_get_cache_specific_type(self):
        """Test getting specific cache type."""
        cache = get_cache("web_requests")
        assert isinstance(cache, IntelligentCache)
    
    def test_get_cache_same_instance(self):
        """Test that same cache type returns same instance."""
        cache1 = get_cache("test_type")
        cache2 = get_cache("test_type")
        assert cache1 is cache2
    
    def test_get_cache_different_instances(self):
        """Test that different cache types return different instances."""
        cache1 = get_cache("type1")
        cache2 = get_cache("type2")
        assert cache1 is not cache2
    
    def test_get_cache_predefined_strategies(self):
        """Test predefined cache strategies."""
        web_cache = get_cache("web_requests")
        embeddings_cache = get_cache("embeddings")
        api_cache = get_cache("api_responses")
        
        # Should have different strategies
        assert web_cache.strategy.default_ttl_hours == 6
        assert embeddings_cache.strategy.default_ttl_hours == 168  # 1 week
        assert api_cache.strategy.default_ttl_hours == 2


if __name__ == "__main__":
    pytest.main([__file__])