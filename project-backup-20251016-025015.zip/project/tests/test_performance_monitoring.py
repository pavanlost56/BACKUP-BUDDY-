"""
Tests for performance monitoring system.
"""

import pytest
import time
import threading
import tempfile
import json
from unittest.mock import patch, MagicMock

from core.performance_monitoring import (
    PerformanceCollector,
    PerformanceProfiler,
    PerformanceOptimizer,
    MetricType,
    PerformanceLevel,
    MetricData,
    PerformanceSummary,
    timed_operation,
    get_performance_monitor,
    profile_operation,
    get_optimizer
)


class TestPerformanceCollector:
    """Test performance collector functionality."""
    
    def setup_method(self):
        """Setup test environment."""
        self.collector = PerformanceCollector(max_metrics=100)
    
    def teardown_method(self):
        """Cleanup test environment."""
        self.collector.monitoring_enabled = False
    
    def test_initialization(self):
        """Test performance collector initialization."""
        assert self.collector.max_metrics == 100
        assert len(self.collector.metrics) == 0
        assert len(self.collector.operation_stats) == 0
        assert self.collector.monitoring_enabled is True
    
    def test_record_metric(self):
        """Test metric recording."""
        self.collector.record_metric(
            operation="test_operation",
            duration_ms=150.5,
            metric_type=MetricType.DURATION,
            context={"user": "test"},
            tags=["important"],
            success=True
        )
        
        assert len(self.collector.metrics) == 1
        assert "test_operation" in self.collector.operation_stats
        assert len(self.collector.operation_stats["test_operation"]) == 1
        
        metric = self.collector.metrics[0]
        assert metric.operation == "test_operation"
        assert metric.value == 150.5
        assert metric.metric_type == MetricType.DURATION
        assert metric.context == {"user": "test"}
        assert metric.tags == ["important"]
    
    def test_operation_summary(self):
        """Test operation summary generation."""
        # Record multiple metrics
        durations = [100, 150, 200, 300, 500]
        for duration in durations:
            self.collector.record_metric("test_op", duration, success=True)
        
        # Add one failure
        self.collector.record_metric("test_op", 1000, success=False)
        
        summary = self.collector.get_operation_summary("test_op")
        
        assert summary is not None
        assert summary.operation == "test_op"
        assert summary.total_calls == 6
        assert summary.avg_duration_ms == sum(durations + [1000]) / 6
        assert summary.min_duration_ms == 100
        assert summary.max_duration_ms == 1000
        assert summary.success_rate == 5/6  # 5 successes out of 6
        assert summary.error_count == 1
    
    def test_performance_classification(self):
        """Test performance level classification."""
        # Test different performance levels
        assert self.collector._classify_performance(50) == PerformanceLevel.EXCELLENT
        assert self.collector._classify_performance(250) == PerformanceLevel.GOOD
        assert self.collector._classify_performance(1000) == PerformanceLevel.ACCEPTABLE
        assert self.collector._classify_performance(5000) == PerformanceLevel.SLOW
        assert self.collector._classify_performance(15000) == PerformanceLevel.CRITICAL
    
    def test_trend_calculation(self):
        """Test performance trend calculation."""
        # Improving trend (recent measurements faster)
        improving = [1000] * 10 + [500] * 10
        assert self.collector._calculate_trend(improving) == "improving"
        
        # Degrading trend (recent measurements slower)
        degrading = [500] * 10 + [1000] * 10
        assert self.collector._calculate_trend(degrading) == "degrading"
        
        # Stable trend
        stable = [500] * 20
        assert self.collector._calculate_trend(stable) == "stable"
        
        # Insufficient data
        insufficient = [100] * 5
        assert self.collector._calculate_trend(insufficient) == "insufficient_data"
    
    def test_get_all_summaries(self):
        """Test getting all operation summaries."""
        # Record metrics for multiple operations
        operations = ["op1", "op2", "op3"]
        for op in operations:
            self.collector.record_metric(op, 100)
        
        summaries = self.collector.get_all_summaries()
        
        assert len(summaries) == 3
        operation_names = [s.operation for s in summaries]
        for op in operations:
            assert op in operation_names
    
    @patch('psutil.cpu_percent')
    @patch('psutil.virtual_memory')
    @patch('psutil.disk_usage')
    @patch('psutil.net_io_counters')
    @patch('psutil.Process')
    def test_system_metrics(self, mock_process, mock_net, mock_disk, mock_memory, mock_cpu):
        """Test system metrics collection."""
        # Mock system data
        mock_cpu.return_value = 25.5
        mock_memory.return_value = MagicMock(
            total=8*1024**3, available=4*1024**3, percent=50.0
        )
        mock_disk.return_value = MagicMock(
            total=1000*1024**3, free=500*1024**3, used=500*1024**3
        )
        mock_net.return_value = MagicMock(
            bytes_sent=1024**2, bytes_recv=2*1024**2
        )
        mock_process.return_value.memory_info.return_value = MagicMock(
            rss=100*1024**2, vms=200*1024**2
        )
        
        metrics = self.collector.get_system_metrics()
        
        assert 'cpu_percent' in metrics
        assert 'memory_total_gb' in metrics
        assert 'disk_free_gb' in metrics
        assert 'process_memory_mb' in metrics
        assert metrics['cpu_percent'] == 25.5
        assert metrics['memory_total_gb'] == 8.0
    
    def test_export_metrics(self):
        """Test metrics export functionality."""
        # Record some test metrics
        self.collector.record_metric("test_export", 100)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            filepath = f.name
        
        try:
            self.collector.export_metrics(filepath, format="json")
            
            with open(filepath, 'r') as f:
                data = json.load(f)
            
            assert 'performance_summaries' in data
            assert 'system_metrics' in data
            assert 'export_timestamp' in data
            assert len(data['performance_summaries']) == 1
        
        finally:
            import os
            os.unlink(filepath)
    
    def test_clear_metrics(self):
        """Test metrics clearing functionality."""
        # Record metrics with different timestamps
        current_time = time.time()
        old_time = current_time - (25 * 3600)  # 25 hours ago
        
        # Mock timestamps
        with patch('time.time', return_value=old_time):
            self.collector.record_metric("old_operation", 100)
        
        with patch('time.time', return_value=current_time):
            self.collector.record_metric("new_operation", 200)
        
        assert len(self.collector.operation_stats) == 2
        
        # Clear metrics older than 24 hours
        self.collector.clear_metrics(older_than_hours=24)
        
        # Should only have the new operation
        assert len(self.collector.operation_stats) == 1
        assert "new_operation" in self.collector.operation_stats


class TestPerformanceProfiler:
    """Test performance profiler functionality."""
    
    def setup_method(self):
        """Setup test environment."""
        self.collector = PerformanceCollector()
    
    def test_profiler_context_manager(self):
        """Test profiler as context manager."""
        with PerformanceProfiler("test_context", self.collector) as profiler:
            profiler.add_context(data_size=1024)
            profiler.add_tag("test_tag")
            time.sleep(0.01)  # Simulate work
        
        # Check that metric was recorded
        assert len(self.collector.metrics) == 1
        metric = self.collector.metrics[0]
        assert metric.operation == "test_context"
        assert metric.value > 0  # Should have some duration
        assert "data_size" in metric.context
        assert "test_tag" in metric.tags
    
    def test_profiler_with_exception(self):
        """Test profiler behavior with exceptions."""
        with pytest.raises(ValueError):
            with PerformanceProfiler("failing_operation", self.collector):
                raise ValueError("Test error")
        
        # Should still record the metric
        assert len(self.collector.metrics) == 1
        metric = self.collector.metrics[0]
        assert metric.operation == "failing_operation"
        assert "error_type" in metric.context
        assert metric.context["error_type"] == "ValueError"
    
    @patch('psutil.Process')
    def test_profiler_resource_tracking(self, mock_process):
        """Test profiler resource usage tracking."""
        # Mock process for memory tracking
        mock_proc = MagicMock()
        mock_proc.memory_info.return_value = MagicMock(rss=100*1024**2)
        mock_proc.cpu_times.return_value = MagicMock(user=1.0, system=0.5)
        mock_process.return_value = mock_proc
        
        with PerformanceProfiler("resource_test", self.collector):
            # Simulate memory change
            mock_proc.memory_info.return_value = MagicMock(rss=110*1024**2)
            mock_proc.cpu_times.return_value = MagicMock(user=1.1, system=0.6)
            time.sleep(0.01)
        
        metric = self.collector.metrics[0]
        # Should have resource usage context
        assert "memory_delta_mb" in metric.context or len(metric.context) == 0  # Might fail if psutil not available


class TestTimedOperationDecorator:
    """Test timed operation decorator."""
    
    def setup_method(self):
        """Setup test environment."""
        self.collector = PerformanceCollector()
    
    def test_timed_operation_decorator(self):
        """Test the timed operation decorator."""
        @timed_operation("decorated_function", self.collector)
        def test_function(x, y):
            time.sleep(0.01)
            return x + y
        
        result = test_function(2, 3)
        
        assert result == 5
        assert len(self.collector.metrics) == 1
        
        metric = self.collector.metrics[0]
        assert metric.operation == "decorated_function"
        assert metric.value > 0
        assert "function_name" in metric.context
        assert metric.context["function_name"] == "test_function"
    
    def test_timed_operation_with_exception(self):
        """Test timed operation decorator with exception."""
        @timed_operation("failing_decorated", self.collector)
        def failing_function():
            raise RuntimeError("Decorator test error")
        
        with pytest.raises(RuntimeError):
            failing_function()
        
        # Should still record metrics
        assert len(self.collector.metrics) == 1
        metric = self.collector.metrics[0]
        assert metric.operation == "failing_decorated"
        assert "error_type" in metric.context


class TestPerformanceOptimizer:
    """Test performance optimizer functionality."""
    
    def setup_method(self):
        """Setup test environment."""
        self.collector = PerformanceCollector()
        self.optimizer = PerformanceOptimizer(self.collector)
    
    def test_bottleneck_analysis(self):
        """Test bottleneck analysis."""
        # Record slow operation
        for _ in range(10):
            self.collector.record_metric("slow_web_api", 5000, success=True)
        
        # Record fast operation
        for _ in range(10):
            self.collector.record_metric("fast_operation", 50, success=True)
        
        # Record operation with errors
        for _ in range(8):
            self.collector.record_metric("error_prone", 200, success=True)
        for _ in range(2):
            self.collector.record_metric("error_prone", 200, success=False)
        
        bottlenecks = self.optimizer.analyze_bottlenecks()
        
        # Should identify the slow operation
        slow_bottleneck = next(
            (b for b in bottlenecks if b['operation'] == 'slow_web_api'),
            None
        )
        assert slow_bottleneck is not None
        assert any(issue['type'] == 'slow_operation' for issue in slow_bottleneck['issues'])
        
        # Should identify error-prone operation
        error_bottleneck = next(
            (b for b in bottlenecks if b['operation'] == 'error_prone'),
            None
        )
        assert error_bottleneck is not None
        assert any(issue['type'] == 'high_error_rate' for issue in error_bottleneck['issues'])
    
    def test_optimization_recommendations(self):
        """Test optimization recommendations."""
        # Record web operation that's slow
        for _ in range(5):
            self.collector.record_metric("web_api_call", 3000, success=True)
        
        recommendations = self.optimizer.get_optimization_recommendations()
        
        # Should recommend caching for web operations
        web_rec = next(
            (r for r in recommendations if r['operation'] == 'web_api_call'),
            None
        )
        assert web_rec is not None
        assert web_rec['type'] == 'caching'
    
    @patch('core.performance_monitoring.statistics.mean')
    def test_system_recommendations(self, mock_mean):
        """Test system-level recommendations."""
        # Mock high CPU usage
        mock_mean.side_effect = [85.0, 50.0]  # High CPU, normal memory
        
        # Create mock system metrics
        system_metrics = [
            {'cpu_percent': 85.0, 'memory_used_percent': 50.0, 'timestamp': time.time()}
        ]
        
        with patch.object(self.collector, 'get_recent_system_metrics', return_value=system_metrics):
            recommendations = self.optimizer.get_optimization_recommendations()
        
        # Should recommend CPU optimization
        cpu_rec = next(
            (r for r in recommendations if r['type'] == 'cpu_optimization'),
            None
        )
        assert cpu_rec is not None
        assert 'High CPU usage' in cpu_rec['description']


class TestGlobalFunctions:
    """Test global performance monitoring functions."""
    
    def test_get_performance_monitor_singleton(self):
        """Test global performance monitor singleton."""
        monitor1 = get_performance_monitor()
        monitor2 = get_performance_monitor()
        assert monitor1 is monitor2
    
    def test_profile_operation(self):
        """Test global profile_operation function."""
        profiler = profile_operation("global_test")
        assert isinstance(profiler, PerformanceProfiler)
        assert profiler.operation == "global_test"
    
    def test_get_optimizer(self):
        """Test global get_optimizer function."""
        optimizer = get_optimizer()
        assert isinstance(optimizer, PerformanceOptimizer)


class TestConcurrentPerformance:
    """Test performance monitoring under concurrent load."""
    
    def setup_method(self):
        """Setup test environment."""
        self.collector = PerformanceCollector()
    
    def test_concurrent_metric_recording(self):
        """Test concurrent metric recording."""
        def worker(worker_id):
            for i in range(10):
                self.collector.record_metric(
                    f"worker_{worker_id}_operation",
                    100 + i,
                    success=True
                )
                time.sleep(0.001)
        
        threads = [threading.Thread(target=worker, args=(i,)) for i in range(3)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        # Should have recorded metrics from all workers
        assert len(self.collector.operation_stats) == 3
        for i in range(3):
            assert f"worker_{i}_operation" in self.collector.operation_stats
            assert len(self.collector.operation_stats[f"worker_{i}_operation"]) == 10
    
    def test_concurrent_profiling(self):
        """Test concurrent profiling operations."""
        results = []
        
        def profiled_worker(worker_id):
            with PerformanceProfiler(f"concurrent_op_{worker_id}", self.collector) as profiler:
                profiler.add_context(worker_id=worker_id)
                time.sleep(0.01)
                results.append(f"worker_{worker_id}_done")
        
        threads = [threading.Thread(target=profiled_worker, args=(i,)) for i in range(5)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        assert len(results) == 5
        assert len(self.collector.metrics) == 5


if __name__ == "__main__":
    pytest.main([__file__])