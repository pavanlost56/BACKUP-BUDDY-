"""
Test suite for scraper module.
"""

from pathlib import Path
import tempfile
import shutil
from unittest.mock import patch, Mock
from bs4 import BeautifulSoup

from core.scraper import fetch_and_save, check_robots_txt, extract_main_content


def test_check_robots_txt_allows_by_default():
    """Test that robots.txt check returns True when robots.txt is not accessible."""
    # This should return True for most URLs since we default to allowing
    result = check_robots_txt("https://httpbin.org/html")
    assert isinstance(result, bool)


def test_extract_main_content_from_fixture():
    """Test content extraction using the HTML fixture."""
    fixture_path = Path("tests/fixtures/sample_doc.html")
    
    with open(fixture_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    content = extract_main_content(soup)
    
    # Verify extracted content
    assert "# Test Framework" in content
    assert "## Getting Started" in content
    assert "### Installation" in content
    assert "pip install test-framework" in content
    assert "import test_framework" in content
    assert "add(a, b)" in content
    
    # Verify navigation and scripts are removed
    assert "Introduction" not in content  # from nav
    assert "console.log" not in content   # from script
    assert "© 2025" not in content        # from footer


@patch('core.scraper.requests.get')
@patch('core.scraper.check_robots_txt')
def test_fetch_and_save_with_mock(mock_robots, mock_get):
    """Test fetch_and_save with mocked HTTP request."""
    # Setup mocks
    mock_robots.return_value = True
    
    # Read fixture content
    fixture_path = Path("tests/fixtures/sample_doc.html")
    with open(fixture_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
    
    mock_response = Mock()
    mock_response.content = html_content.encode('utf-8')
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response
    
    # Use temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        original_cwd = Path.cwd()
        temp_path = Path(temp_dir)
        
        try:
            import os
            os.chdir(temp_path)
            
            # Test the function
            result = fetch_and_save("https://example.com/docs", "test-framework")
            
            # Verify metadata
            assert result["title"] == "Test Framework Documentation"
            assert result["url"] == "https://example.com/docs"
            assert "fetch_time" in result
            assert "file_path" in result
            assert "content_length" in result
            assert result["content_length"] > 0
            
            # Verify file exists and has content
            output_file = Path(result["file_path"])
            assert output_file.exists()
            
            content = output_file.read_text(encoding='utf-8')
            assert "Test Framework Documentation" in content
            assert "https://example.com/docs" in content
            assert "# Test Framework" in content
            assert "## Getting Started" in content
            
            # Verify mocks were called
            mock_robots.assert_called_once_with("https://example.com/docs")
            mock_get.assert_called_once()
            
        finally:
            os.chdir(original_cwd)


def test_fetch_and_save_respects_robots_txt():
    """Test that fetch_and_save raises error when robots.txt disallows."""
    with patch('core.scraper.check_robots_txt') as mock_robots:
        mock_robots.return_value = False
        
        try:
            fetch_and_save("https://example.com/disallowed", "test")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "disallowed by robots.txt" in str(e)