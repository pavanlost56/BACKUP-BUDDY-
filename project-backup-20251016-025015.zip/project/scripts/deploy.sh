#!/bin/bash
"""
Production deployment script for CodeInsight
Supports various deployment modes: local, docker, kubernetes
"""

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
DEPLOYMENT_MODE="local"
ENVIRONMENT="production"
OLLAMA_MODEL="llama3.2"
BACKUP_DATA=true
VERIFY_INSTALLATION=true

usage() {
    echo -e "${BLUE}CodeInsight Deployment Script${NC}"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -m, --mode MODE         Deployment mode: local, docker, k8s (default: local)"
    echo "  -e, --env ENV          Environment: dev, staging, production (default: production)"
    echo "  -M, --model MODEL      Ollama model to install (default: llama3.2)"
    echo "  --no-backup           Skip data backup"
    echo "  --no-verify           Skip installation verification"
    echo "  -h, --help            Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --mode docker --env production"
    echo "  $0 --mode local --model llama2"
    echo "  $0 --mode k8s --env staging"
}

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

check_dependencies() {
    log "Checking deployment dependencies..."
    
    case $DEPLOYMENT_MODE in
        "local")
            command -v python3 >/dev/null 2>&1 || error "Python 3 is required"
            command -v pip >/dev/null 2>&1 || error "pip is required"
            ;;
        "docker")
            command -v docker >/dev/null 2>&1 || error "Docker is required"
            command -v docker-compose >/dev/null 2>&1 || error "Docker Compose is required"
            ;;
        "k8s")
            command -v kubectl >/dev/null 2>&1 || error "kubectl is required"
            command -v helm >/dev/null 2>&1 || error "Helm is required"
            ;;
    esac
    
    log "Dependencies check passed"
}

backup_existing_data() {
    if [ "$BACKUP_DATA" = true ] && [ -d "data" ]; then
        log "Creating backup of existing data..."
        
        backup_dir="backup-$(date +%Y%m%d-%H%M%S)"
        mkdir -p "$backup_dir"
        
        if [ -d "data" ]; then
            cp -r data "$backup_dir/"
        fi
        
        if [ -d "logs" ]; then
            cp -r logs "$backup_dir/"
        fi
        
        if [ -d "configs" ]; then
            cp -r configs "$backup_dir/"
        fi
        
        log "Backup created at: $backup_dir"
    fi
}

deploy_local() {
    log "Starting local deployment..."
    
    # Install dependencies
    log "Installing Python dependencies..."
    pip install -r requirements.txt
    
    # Run installation script
    log "Running installation script..."
    python install.py
    
    # Setup Ollama if not running
    if ! curl -s http://localhost:11434/api/tags >/dev/null 2>&1; then
        warn "Ollama not detected. Please install from https://ollama.ai/"
    else
        log "Installing Ollama model: $OLLAMA_MODEL"
        ollama pull "$OLLAMA_MODEL" || warn "Failed to pull model $OLLAMA_MODEL"
    fi
    
    log "Local deployment completed"
}

deploy_docker() {
    log "Starting Docker deployment..."
    
    # Build and start containers
    log "Building Docker image..."
    docker-compose build
    
    log "Starting services..."
    docker-compose up -d
    
    # Wait for Ollama to be ready
    log "Waiting for Ollama to be ready..."
    for i in {1..30}; do
        if curl -s http://localhost:11434/api/tags >/dev/null 2>&1; then
            break
        fi
        sleep 2
    done
    
    # Install model in Ollama container
    log "Installing Ollama model: $OLLAMA_MODEL"
    docker-compose exec ollama ollama pull "$OLLAMA_MODEL" || warn "Failed to pull model $OLLAMA_MODEL"
    
    log "Docker deployment completed"
    log "Services available at:"
    log "  - CodeInsight: http://localhost:8080"
    log "  - Ollama: http://localhost:11434"
}

deploy_kubernetes() {
    log "Starting Kubernetes deployment..."
    
    # Create namespace
    kubectl create namespace codeinsight --dry-run=client -o yaml | kubectl apply -f -
    
    # Deploy using Helm chart (you would need to create this)
    if [ -d "helm/codeinsight" ]; then
        helm upgrade --install codeinsight helm/codeinsight \
            --namespace codeinsight \
            --set environment="$ENVIRONMENT" \
            --set ollamaModel="$OLLAMA_MODEL"
    else
        warn "Helm chart not found. Creating basic Kubernetes manifests..."
        # Create basic deployment manifests
        create_k8s_manifests
    fi
    
    log "Kubernetes deployment completed"
}

create_k8s_manifests() {
    log "Creating Kubernetes manifests..."
    
    mkdir -p k8s
    
    # Create deployment manifest
    cat > k8s/deployment.yaml << EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: codeinsight
  namespace: codeinsight
spec:
  replicas: 1
  selector:
    matchLabels:
      app: codeinsight
  template:
    metadata:
      labels:
        app: codeinsight
    spec:
      containers:
      - name: codeinsight
        image: codeinsight:latest
        ports:
        - containerPort: 8080
        env:
        - name: CODEINSIGHT_LOG_LEVEL
          value: "INFO"
        - name: OLLAMA_BASE_URL
          value: "http://ollama:11434"
EOF
    
    # Apply manifests
    kubectl apply -f k8s/
}

verify_deployment() {
    if [ "$VERIFY_INSTALLATION" = true ]; then
        log "Verifying deployment..."
        
        case $DEPLOYMENT_MODE in
            "local")
                python cli.py --help >/dev/null || error "CLI not working"
                python cli.py perf system-metrics >/dev/null || error "Performance monitoring not working"
                ;;
            "docker")
                docker-compose exec codeinsight python cli.py --help >/dev/null || error "Docker CLI not working"
                ;;
            "k8s")
                kubectl exec -n codeinsight deployment/codeinsight -- python cli.py --help >/dev/null || error "K8s CLI not working"
                ;;
        esac
        
        log "Deployment verification passed"
    fi
}

main() {
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -m|--mode)
                DEPLOYMENT_MODE="$2"
                shift 2
                ;;
            -e|--env)
                ENVIRONMENT="$2"
                shift 2
                ;;
            -M|--model)
                OLLAMA_MODEL="$2"
                shift 2
                ;;
            --no-backup)
                BACKUP_DATA=false
                shift
                ;;
            --no-verify)
                VERIFY_INSTALLATION=false
                shift
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                error "Unknown option: $1"
                ;;
        esac
    done
    
    log "Starting CodeInsight deployment..."
    log "Mode: $DEPLOYMENT_MODE"
    log "Environment: $ENVIRONMENT"
    log "Ollama Model: $OLLAMA_MODEL"
    
    check_dependencies
    backup_existing_data
    
    case $DEPLOYMENT_MODE in
        "local")
            deploy_local
            ;;
        "docker")
            deploy_docker
            ;;
        "k8s")
            deploy_kubernetes
            ;;
        *)
            error "Unknown deployment mode: $DEPLOYMENT_MODE"
            ;;
    esac
    
    verify_deployment
    
    log "Deployment completed successfully!"
    log "Next steps:"
    log "  1. Update documentation: python cli.py update react"
    log "  2. Query documentation: python cli.py query 'How to create components?'"
    log "  3. Monitor performance: python cli.py perf stats"
}

main "$@"