#!/usr/bin/env python3
"""
CodeInsight - AI Developer Assistant
Main entry point with Gemini-CLI-style interactive experience
"""

import sys
import time
import subprocess
import threading
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text
from rich.live import Live
from rich.markdown import Markdown
from rich.syntax import Syntax

# Import necessary components from the core library
from core.interactive_ui import InteractiveUI, create_interactive_ui
from core.configuration import get_config_manager
from core.llm_client import get_llm_client
from core.performance_monitoring import get_performance_monitor
from core.caching import get_cache_manager
from core.conversation import ConversationEngine

# Import the original CLI from the project root
sys.path.insert(0, str(Path(__file__).parent.parent))
from cli import cli as original_cli

console = Console()

class CodeInsightUI:
    """Gemini-CLI-style UI manager for CodeInsight"""
    
    def __init__(self):
        self.ollama_available = False
        self.ollama_models = []
        self.startup_complete = False
        self.conversation_engine: Optional[ConversationEngine] = None
        self.ui: Optional[InteractiveUI] = None
        
    def show_banner(self):
        """Display startup banner"""
        banner_text = """
[bold cyan]🧠 CodeInsight[/bold cyan] [dim]v1.0.0[/dim]
[italic]Local RAG-powered AI Developer Assistant[/italic]

✨ Interactive agent mode with tool orchestration
📚 Multi-framework documentation search  
🤖 Local LLM integration via Ollama
🛡️ Privacy-first with local data storage
        """
        
        panel = Panel(
            banner_text.strip(),
            border_style="bright_blue",
            padding=(1, 2),
            title="[bold white]Welcome[/bold white]",
            title_align="center"
        )
        console.print(panel)
        console.print()

    def startup_animation(self):
        """Gemini-CLI style startup sequence"""
        tasks = [
            ("🔧 Initializing core systems", 0.8),
            ("📁 Loading cache and configuration", 0.6), 
            ("🗃️ Connecting to vector database", 0.7),
            ("📚 Loading documentation embeddings", 0.9),
            ("🤖 Checking Ollama connectivity", 1.2),
            ("⚡ Optimizing performance systems", 0.5),
        ]
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        ) as progress:
            
            for task_name, duration in tasks:
                task = progress.add_task(task_name, total=100)
                
                # Simulate work with progress updates
                for i in range(100):
                    time.sleep(duration / 100)
                    progress.update(task, advance=1)
                
                # Brief pause between tasks
                time.sleep(0.1)
        
        console.print("[green]✅ System initialization complete![/green]\n")

    def check_ollama_connectivity(self):
        """Check Ollama availability and models"""
        try:
            # Check if ollama command exists
            result = subprocess.run(
                ["ollama", "list"], 
                capture_output=True, 
                text=True, 
                timeout=10
            )
            
            if result.returncode == 0:
                self.ollama_available = True
                # Parse model list
                lines = result.stdout.strip().split('\n')[1:]  # Skip header
                self.ollama_models = [line.split()[0] for line in lines if line.strip()]
                
                console.print("[green]✅ Ollama connected successfully[/green]")
                
                if self.ollama_models:
                    console.print(f"[cyan]📦 Available models: {', '.join(self.ollama_models[:3])}[/cyan]")
                    if len(self.ollama_models) > 3:
                        console.print(f"[dim]   ... and {len(self.ollama_models) - 3} more[/dim]")
                else:
                    console.print("[yellow]⚠️  No models installed. Run: ollama pull llama3.2[/yellow]")
                    
            else:
                console.print("[yellow]⚠️  Ollama service not running[/yellow]")
                
        except subprocess.TimeoutExpired:
            console.print("[yellow]⚠️  Ollama connection timeout[/yellow]")
        except FileNotFoundError:
            console.print("[red]❌ Ollama not installed or not in PATH[/red]")
            console.print("[dim]Install from: https://ollama.ai/[/dim]")
        except Exception as e:
            console.print(f"[red]❌ Ollama check failed: {e}[/red]")

    def show_system_status(self):
        """Display system status table"""
        table = Table(title="System Status", border_style="blue")
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Details", style="dim")
        
        # Core system
        table.add_row("Core Systems", "✅ Ready", "CLI, Agent, RAG pipeline")
        
        # Performance monitoring
        table.add_row("Performance Monitor", "✅ Active", "Real-time metrics enabled")
        
        # Cache system
        table.add_row("Cache System", "✅ Ready", "Multi-level caching active")
        
        # Ollama status
        if self.ollama_available:
            status = "✅ Connected"
            details = f"{len(self.ollama_models)} models available"
        else:
            status = "⚠️  Unavailable"
            details = "Fallback mode enabled"
        table.add_row("Ollama LLM", status, details)
        
        console.print(table)
        console.print()

    def enter_interactive_mode(self):
        """Enter Gemini-CLI style interactive REPL"""
        ui = create_interactive_ui(console)
        self.ui = ui
        self.conversation_engine = ConversationEngine()
        
        # Get system status
        config_manager = get_config_manager()
        llm_client = get_llm_client()
        perf_monitor = get_performance_monitor()
        cache_manager = get_cache_manager()

        status = {
            "performance_monitor": {"active": True, "status": "Active"},
            "cache": {"active": True, "status": "Ready", "size_mb": cache_manager.get_cache_size_mb()},
            "ollama": llm_client.get_connection_status()
        }
        
        ui.show_gemini_style_banner(version="1.1.0", status=status)
        
        while True:
            try:
                # Get user input with styled prompt
                prompt_text = ui.get_gemini_style_prompt()
                user_input = console.input(prompt_text).strip()
                
                if not user_input:
                    continue
                    
                # Handle exit commands
                if user_input.lower() in ['exit', 'quit', 'bye']:
                    console.print("\n[cyan]👋 Goodbye! Thanks for using CodeInsight[/cyan]")
                    break
                
                # Handle help
                if user_input.lower() in ['help', '?']:
                    self.show_help()
                    continue
                
                # Handle clear screen
                if user_input.lower() in ['clear', 'cls']:
                    console.clear()
                    continue
                
                # Handle status check
                if user_input.lower() in ['status', 'info']:
                    status = {
                        "performance_monitor": {"active": True, "status": "Active"},
                        "cache": {"active": True, "status": "Ready", "size_mb": cache_manager.get_cache_size_mb()},
                        "ollama": llm_client.get_connection_status()
                    }
                    ui.show_system_status(status)
                    continue
                
                if self.ui:
                    self.ui.render_user_message(user_input)

                handled = self.process_command(user_input)
                if not handled:
                    self.handle_conversational_input(user_input)
                
            except KeyboardInterrupt:
                console.print("\n[yellow]Interrupted. Type 'exit' to quit.[/yellow]")
            except EOFError:
                console.print("\n[cyan]👋 Goodbye![/cyan]")
                break

    def show_help(self):
        """Display interactive mode help"""
        help_text = """
[bold cyan]Interactive Mode Commands:[/bold cyan]

[bold]Core Commands:[/bold]
• [green]agent [prompt][/green]     - Run AI agent with task planning
• [green]query [question][/green]   - Search documentation  
• [green]update [framework][/green] - Update documentation

[bold]Model Commands:[/bold]
• [green]model list[/green]         - List available models
• [green]model set-default [name][/green] - Set default model
• [green]model test [prompt][/green] - Test model with prompt
• [green]model status[/green]       - Check Ollama server status

[bold]System Commands:[/bold]
• [green]perf stats[/green]         - Show performance metrics
• [green]cache --show-stats[/green] - View cache statistics
• [green]config info[/green]        - Show configuration
• [green]history[/green]            - View command history

[bold]Interactive Commands:[/bold]
• [green]help[/green]               - Show this help
• [green]status[/green]             - System status
• [green]clear[/green]              - Clear screen
• [green]exit[/green]               - Quit interactive mode
• [green]Just ask![/green]          - Type natural language and let CodeInsight route it

[bold]Examples:[/bold]
[dim]• agent "Create a React component with hooks"
• query "How to handle state in Vue?"
• update react
• model set-default mistral
• model test "Hello, how are you?"
• perf stats --detailed[/dim]
        """
        console.print(Panel(help_text.strip(), border_style="blue", title="Help"))

    def process_command(self, command: str) -> bool:
        """Process a command in interactive mode"""
        try:
            parts = command.split()
            if not parts:
                return True

            primary = parts[0]
            primary_lower = primary.lower()
            parts[0] = primary_lower

            # Recognized CLI commands
            known_commands = set(original_cli.commands.keys())
            if primary_lower not in known_commands:
                return False

            if primary_lower == 'agent' and len(parts) > 1:
                prompt = ' '.join(parts[1:])
                message = f"Running agent with task: {prompt}"
                if self.ui:
                    self.ui.render_assistant_message(message)
                else:
                    console.print(f"\n[bold cyan]🤖 {message}[/bold cyan]")
                with console.status("[bold green]Agent is thinking..."):
                    time.sleep(0.5)
                self.execute_cli_command(['agent', prompt])
                return True

            if primary_lower == 'query' and len(parts) > 1:
                query = ' '.join(parts[1:])
                message = f"Searching documentation for: {query}"
                if self.ui:
                    self.ui.render_assistant_message(message)
                else:
                    console.print(f"\n[bold cyan]🔍 {message}[/bold cyan]")
                self.execute_cli_command(['query', query])
                return True

            # Delegate other known commands to Click
            self.execute_cli_command(parts)
            return True

        except Exception as e:
            error_message = f"❌ Error: {e}"
            if self.ui:
                self.ui.render_assistant_message(error_message)
            else:
                console.print(f"[red]{error_message}[/red]")
            return True

        return False

    def handle_conversational_input(self, message: str):
        """Route natural language input through the conversation engine."""
        if not self.conversation_engine:
            self.conversation_engine = ConversationEngine()

        directive = self.conversation_engine.interpret(message)

        if directive.action == "respond":
            if self.ui:
                self.ui.render_assistant_message(directive.response)
            else:
                console.print(Panel(directive.response, border_style="cyan"))
            return

        if directive.action == "command" and directive.command:
            if self.ui:
                self.ui.render_routing(directive.command, directive.reasoning)
            else:
                console.print(
                    Panel(
                        f"[cyan]→ {directive.command[0]}[/cyan] {directive.reasoning or ''}",
                        title="Routing",
                        border_style="cyan",
                    )
                )
            self.execute_cli_command(directive.command)
            return

        fallback_message = "I’m unsure how to help with that. Try 'help' for available commands."
        if self.ui:
            self.ui.render_assistant_message(fallback_message)
        else:
            console.print(Panel(fallback_message, border_style="yellow"))

    def execute_cli_command(self, args):
        """Execute a CLI command using the original CLI"""
        try:
            # Save original sys.argv
            original_argv = sys.argv.copy()
            
            # Set up arguments for click
            sys.argv = ['codeinsight'] + args
            
            # Execute the command
            original_cli.main(standalone_mode=False)
            
        except SystemExit:
            # Click normally exits, this is expected
            pass
        except Exception as e:
            console.print(f"[red]❌ Command failed: {e}[/red]")
        finally:
            # Restore original sys.argv
            sys.argv = original_argv

    def query_ollama(self, prompt: str, model: str = None) -> Optional[str]:
        """Query Ollama with a prompt"""
        if not self.ollama_available:
            return None
        
        try:
            # Use first available model if none specified
            if not model and self.ollama_models:
                model = self.ollama_models[0]
            elif not model:
                model = "llama3.2"  # Default fallback
            
            result = subprocess.run(
                ["ollama", "run", model, prompt],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                return result.stdout.strip()
            else:
                console.print(f"[red]Ollama error: {result.stderr}[/red]")
                return None
                
        except subprocess.TimeoutExpired:
            console.print("[yellow]⚠️  Ollama query timeout[/yellow]")
            return None
        except Exception as e:
            console.print(f"[red]Ollama query failed: {e}[/red]")
            return None


def startup_sequence():
    """Complete startup sequence"""
    ui = CodeInsightUI()
    
    # Show banner
    ui.show_banner()
    
    # Run startup animation
    ui.startup_animation()
    
    # Check Ollama connectivity
    ui.check_ollama_connectivity()
    
    # Show system status
    ui.show_system_status()
    
    return ui


@click.group(invoke_without_command=True)
@click.pass_context
@click.option('--no-banner', is_flag=True, help='Skip startup banner and animation')
@click.option('--interactive', '-i', is_flag=True, help='Force interactive mode')
def main(ctx, no_banner, interactive):
    """
    CodeInsight - Local RAG-powered AI Developer Assistant
    
    Run without arguments to enter interactive mode.
    """
    
    # If subcommand provided, delegate to original CLI
    if ctx.invoked_subcommand is not None:
        # Execute the original CLI command
        try:
            # Filter out our custom options that the original CLI doesn't understand
            filtered_args = [arg for arg in sys.argv[1:] if arg not in ['--no-banner', '--interactive', '-i']]
            original_cli.main(filtered_args, standalone_mode=False)
        except SystemExit:
            pass
        return
    
    # No subcommand - enter interactive mode
    ui = CodeInsightUI()
    
    # Enter interactive mode
    ui.enter_interactive_mode()


# Add all the original CLI commands as subcommands
@main.command()
@click.argument('task')
@click.option('--confirm-steps', is_flag=True, help='Confirm each step before execution')
@click.option('--show-plan', is_flag=True, help='Show execution plan before starting')  
@click.option('--interactive', is_flag=True, help='Run in interactive mode')
def agent(task, confirm_steps, show_plan, interactive):
    """Run CodeInsight Agent to complete development tasks."""
    # Import and execute the original agent command
    from cli import agent as original_agent_cmd
    original_agent_cmd.callback(task, confirm_steps, show_plan, interactive)


@main.command() 
@click.argument('query')
@click.option('--framework', default='react', help='Framework to search')
@click.option('--top-k', default=5, help='Number of results to return')
def query(query, framework, top_k):
    """Query the documentation for answers."""
    # Import and execute the original query command
    from cli import query as original_query_cmd
    original_query_cmd.callback(query, framework, top_k)


@main.command()
@click.argument('framework')
def update(framework):
    """Update documentation for a framework."""
    # Import and execute the original update command
    from cli import update as original_update_cmd
    original_update_cmd.callback(framework)


# Add performance monitoring commands
@main.group()
def perf():
    """Performance monitoring and optimization commands."""
    pass

# Add model management commands  
@main.group()
def model():
    """Model management commands for Ollama integration."""
    pass

# Import original perf and model commands
from cli import perf as original_perf_group, model as original_model_group

# Add all original perf subcommands
for cmd_name, cmd in original_perf_group.commands.items():
    perf.add_command(cmd, name=cmd_name)

# Add all original model subcommands
for cmd_name, cmd in original_model_group.commands.items():
    model.add_command(cmd, name=cmd_name)


@perf.command()
def stats():
    """Show performance statistics."""
    ctx = click.get_current_context()
    ctx.parent.parent.invoke(original_cli, ['perf', 'stats'])


if __name__ == '__main__':
    main()