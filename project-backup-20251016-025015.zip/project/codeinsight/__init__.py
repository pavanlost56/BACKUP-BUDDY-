"""
CodeInsight package initialization.
"""

__version__ = "1.0.0"
__author__ = "CodeInsight Team"
__description__ = "Local RAG-powered AI developer assistant"