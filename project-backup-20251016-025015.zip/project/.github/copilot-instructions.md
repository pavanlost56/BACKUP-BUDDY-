# CodeInsight Project Instructions

This is CodeInsight - a local RAG-powered CLI developer assistant that scrapes official documentation, embeds it into a local vector database, and provides answers via local LLM (Ollama).

## Project Structure
- **Language**: Python 3.11+
- **CLI Framework**: click
- **Output**: rich
- **Scraping**: requests + BeautifulSoup4
- **Vector DB**: chromadb (local)
- **RAG**: langchain
- **LLM**: Ollama (local inference)
- **Testing**: pytest

## Architecture
- `cli.py` - Main CLI entry point
- `core/` - Core functionality modules
- `data/docs/` - Scraped documentation storage
- `data/db/` - ChromaDB persistence
- `tests/` - Test suite

## Development Rules
- No paid APIs - only local inference
- Privacy-first - all data stored locally
- Minimal testable increments
- Respect robots.txt
- Include tests for all new features