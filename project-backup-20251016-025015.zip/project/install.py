#!/usr/bin/env python3
"""
CodeInsight Deployment and Installation Script
Prepares the system for production deployment.
"""

import os
import sys
import subprocess
import platform
import shutil
from pathlib import Path
import json

def print_banner():
    """Print installation banner."""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          CodeInsight Installation                           ║
║                    Local RAG-Powered Developer Assistant                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")

def check_python_version():
    """Check if Python version is compatible."""
    print("🔍 Checking Python version...")
    
    if sys.version_info < (3, 11):
        print("❌ Error: Python 3.11 or higher is required.")
        print(f"   Current version: {sys.version}")
        return False
    
    print(f"✅ Python {sys.version} - Compatible")
    return True

def check_system_requirements():
    """Check system requirements."""
    print("\n🔍 Checking system requirements...")
    
    # Check available memory
    try:
        if platform.system() == "Windows":
            import psutil
            memory_gb = psutil.virtual_memory().total / (1024**3)
            if memory_gb < 4:
                print(f"⚠️  Warning: Low memory detected ({memory_gb:.1f}GB). 8GB+ recommended.")
            else:
                print(f"✅ Memory: {memory_gb:.1f}GB - Sufficient")
        else:
            print("✅ Memory check skipped on non-Windows platforms")
    except ImportError:
        print("⚠️  Memory check skipped - psutil not available")
    
    # Check disk space
    try:
        free_space = shutil.disk_usage(".").free / (1024**3)
        if free_space < 2:
            print(f"❌ Error: Insufficient disk space ({free_space:.1f}GB). 2GB+ required.")
            return False
        else:
            print(f"✅ Disk space: {free_space:.1f}GB - Sufficient")
    except Exception as e:
        print(f"⚠️  Disk space check failed: {e}")
    
    return True

def install_dependencies():
    """Install Python dependencies."""
    print("\n📦 Installing dependencies...")
    
    try:
        # Check if pip is available
        subprocess.run([sys.executable, "-m", "pip", "--version"], 
                      check=True, capture_output=True)
        
        # Install requirements
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
                      check=True)
        
        print("✅ Dependencies installed successfully")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing dependencies: {e}")
        return False
    except FileNotFoundError:
        print("❌ Error: pip not found. Please install pip.")
        return False

def create_directories():
    """Create necessary directories."""
    print("\n📁 Creating directories...")
    
    directories = [
        "data/docs",
        "data/db", 
        "data/cache",
        "data/performance",
        "logs",
        "configs"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"   ✓ {directory}")
    
    print("✅ Directories created")

def create_default_config():
    """Create default configuration files."""
    print("\n⚙️  Creating default configuration...")
    
    # Default docs sources config
    docs_config = {
        "sources": {
            "react": {
                "name": "React",
                "url": "https://react.dev/",
                "description": "React official documentation"
            },
            "vue": {
                "name": "Vue.js",
                "url": "https://vuejs.org/",
                "description": "Vue.js official documentation"
            },
            "httpbin": {
                "name": "HTTPBin",
                "url": "https://httpbin.org/",
                "description": "HTTP testing service documentation"
            }
        }
    }
    
    config_file = Path("configs/docs_sources.yaml")
    if not config_file.exists():
        import yaml
        with open(config_file, 'w') as f:
            yaml.dump(docs_config, f, default_flow_style=False, indent=2)
        print("   ✓ configs/docs_sources.yaml")
    
    print("✅ Configuration created")

def check_ollama():
    """Check if Ollama is available."""
    print("\n🤖 Checking Ollama availability...")
    
    try:
        import requests
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        if response.status_code == 200:
            models = response.json().get("models", [])
            if models:
                print(f"✅ Ollama running with {len(models)} models")
                for model in models[:3]:  # Show first 3 models
                    print(f"   • {model['name']}")
                return True
            else:
                print("⚠️  Ollama running but no models installed")
                print("   Run: ollama pull llama3.2")
                return False
        else:
            print("⚠️  Ollama server not responding")
            return False
            
    except Exception as e:
        print("⚠️  Ollama not available - install from https://ollama.ai/")
        print("   This is optional but recommended for full functionality")
        return False

def run_basic_tests():
    """Run basic functionality tests."""
    print("\n🧪 Running basic tests...")
    
    try:
        # Test imports
        from core.embedder import chunk_text
        from core.retriever import load_framework_database
        from core.llm_client import check_ollama_server
        from core.performance_monitoring import get_performance_monitor
        
        print("   ✓ Core modules import successfully")
        
        # Test performance monitoring
        pm = get_performance_monitor()
        print("   ✓ Performance monitoring initialized")
        
        # Test text processing
        chunks = chunk_text("This is a test document for chunking.")
        if chunks:
            print("   ✓ Text chunking works")
        
        print("✅ Basic tests passed")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def update_windows_path():
    """Add user scripts directory to PATH on Windows."""
    if platform.system() != "Windows":
        return

    print("\n⚙️  Updating PATH on Windows...")

    try:
        # Get user scripts path
        result = subprocess.run(
            [sys.executable, "-m", "site", "--user-site"],
            capture_output=True, text=True, check=True
        )
        user_site = Path(result.stdout.strip())
        scripts_path = user_site.parent / "Scripts"

        if not scripts_path.exists():
            print(f"⚠️  Scripts directory not found: {scripts_path}")
            return

        # Get current user PATH
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_ALL_ACCESS)
        current_path, _ = winreg.QueryValueEx(key, "Path")

        # Add path if not already present
        if str(scripts_path) not in current_path:
            new_path = f"{current_path};{scripts_path}"
            winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, new_path)
            winreg.CloseKey(key)
            print(f"✅ Added '{scripts_path}' to user PATH")
            print("   Please restart your terminal for changes to take effect")
        else:
            print(f"✅ '{scripts_path}' is already in user PATH")

    except Exception as e:
        print(f"❌ Error updating PATH: {e}")
        print("   You may need to add it manually:")
        print(f"   1. Open 'Environment Variables'")
        print(f"   2. Edit 'Path' under 'User variables'")
        print(f"   3. Add the scripts directory (usually ends in 'Python\\PythonXX\\Scripts')")


def show_next_steps():
    """Show next steps after installation."""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                              Installation Complete!                         ║
╚══════════════════════════════════════════════════════════════════════════════╝

🎉 CodeInsight is ready to use!

📚 Next Steps:

1. **Restart your terminal** to apply PATH changes

2. Update documentation for a framework:
   codeinsight update react

3. Query the documentation:
   codeinsight query "How do I create a component?" --framework react

4. Use interactive agent mode:
   codeinsight

5. Monitor performance:
   codeinsight perf stats

6. (Optional) Install Ollama for enhanced functionality:
   • Download from https://ollama.ai/
   • Run: ollama pull llama3.2

📖 Documentation: See README.md for detailed usage instructions
🐛 Issues: Report bugs on GitHub
💡 Tips: Use 'codeinsight --help' to explore all commands

Happy coding! 🚀
""")

def main():
    """Main installation routine."""
    print_banner()
    
    success = True
    
    # Run all checks and setup steps
    if not check_python_version():
        sys.exit(1)
    
    if not check_system_requirements():
        sys.exit(1)
    
    if not install_dependencies():
        success = False
    
    create_directories()
    create_default_config()
    
    # Update PATH on Windows
    update_windows_path()
    
    ollama_available = check_ollama()
    
    if not run_basic_tests():
        success = False
    
    if success:
        show_next_steps()
        if not ollama_available:
            print("\n⚠️  Note: Ollama not detected. Some features may be limited.")
    else:
        print("\n❌ Installation completed with errors. Check the messages above.")
        sys.exit(1)

if __name__ == "__main__":
    main()