# 🧠 CodeInsight CLI

> **Local RAG-powered CLI developer assistant** — Get up-to-date, context-aware documentation, command suggestions, and code snippets by dynamically scraping official docs, embedding them into a local vector database, and answering queries via local LLM (Ollama).

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://python.org)
[![CLI](https://img.shields.io/badge/CLI-Click-green)](https://click.palletsprojects.com)
[![LLM](https://img.shields.io/badge/LLM-Ollama-orange)](https://ollama.ai)
[![License](https://img.shields.io/badge/License-MIT-purple)](LICENSE)

## ✨ Features

- 🔍 **Smart Documentation Search** - Vector similarity search across scraped framework docs
- 🤖 **Local AI Assistance** - Powered by Ollama (no API keys required)
- 📚 **Auto-Updates** - Keeps documentation current with configurable sources
- 🎨 **Rich Interface** - Beautiful CLI output with syntax highlighting
- 🛡️ **Privacy-First** - All data stored locally, no external API calls
- ⚡ **Context-Aware** - Suggests relevant follow-up actions based on query type

## 🚀 Quick Start

### Prerequisites

1. **Python 3.10+** installed
2. **Ollama** running locally:

```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Start Ollama server
ollama serve

# Pull a model (recommended)
ollama pull llama2
```

### Installation

#### Option A: Install from GitHub (Recommended)

```bash
pip install git+https://github.com/your-username/CodeInsight-CLI.git
```

#### Option B: Development Install

```bash
git clone https://github.com/your-username/CodeInsight-CLI.git
cd CodeInsight-CLI
pip install -e .
```

### Verify Installation

```bash
codeinsight --help
```

## 🛠️ Usage

### 1. Update Documentation

```bash
# Update React documentation
codeinsight update react

# Update multiple frameworks
codeinsight update vue
codeinsight update angular

# See available frameworks
codeinsight update --list-frameworks

# Dry run (preview what would be updated)
codeinsight update react --dry-run
```

### 2. Query Documentation

```bash
# Basic query
codeinsight query "how to create a component"

# Framework-specific query
codeinsight query "state management" --framework vue

# Get more context (increase retrieved chunks)
codeinsight query "routing setup" --framework react --top-k 10
```

### 3. Example Queries

#### React Development

```bash
codeinsight query "useState hook example" --framework react
codeinsight query "create react app setup" --framework react
codeinsight query "component lifecycle methods" --framework react
```

#### Vue Development

```bash
codeinsight query "composition api setup" --framework vue
codeinsight query "vue router configuration" --framework vue
codeinsight query "reactive data binding" --framework vue
```

#### General Web Development

```bash
codeinsight query "express server setup" --framework express
codeinsight query "jest testing configuration" --framework jest
codeinsight query "webpack configuration" --framework webpack
```

## 📋 Supported Frameworks

| Framework | Description | Documentation Source |
|-----------|-------------|---------------------|
| `react` | React - The library for web UIs | https://react.dev |
| `vue` | Vue.js - The Progressive Framework | https://vuejs.org |
| `angular` | Angular - Platform for mobile & desktop | https://angular.io |
| `svelte` | Svelte - Cybernetically enhanced apps | https://svelte.dev |
| `next` | Next.js - The React Framework | https://nextjs.org |
| `nuxt` | Nuxt - The Intuitive Vue Framework | https://nuxt.com |
| `express` | Express - Fast Node.js web framework | https://expressjs.com |
| `jest` | Jest - Delightful JavaScript Testing | https://jestjs.io |
| `webpack` | webpack - Static module bundler | https://webpack.js.org |

*And many more! Use `codeinsight update --list-frameworks` to see all available options.*

## 🏗️ Architecture

```
CodeInsight CLI
├── 📄 cli.py              # Main CLI interface
├── 🧠 core/
│   ├── scraper.py         # Web scraping with robots.txt compliance
│   ├── embedder.py        # Text chunking and TF-IDF embeddings
│   ├── retriever.py       # Vector similarity search
│   ├── llm_client.py      # Ollama HTTP API integration
│   ├── suggester.py       # Response formatting and suggestions
│   └── utils.py           # Configuration and utilities
├── ⚙️ configs/
│   └── docs_sources.yaml  # Framework documentation URLs
└── 💾 data/
    ├── docs/              # Scraped documentation storage
    └── db/                # Vector database (embeddings + metadata)
```

## 🔧 Configuration

CodeInsight uses `configs/docs_sources.yaml` to manage documentation sources:

```yaml
frameworks:
  react:
    url: "https://react.dev/learn"
    description: "React - The library for web and native user interfaces"
  
  vue:
    url: "https://vuejs.org/guide/"
    description: "Vue.js - The Progressive JavaScript Framework"
```

To add new frameworks, edit this file and run:

```bash
codeinsight update your-new-framework
```

## 🧪 Development

### Setup Development Environment

```bash
git clone https://github.com/your-username/CodeInsight-CLI.git
cd CodeInsight-CLI

# Install development dependencies
pip install -r dev-requirements.txt

# Install in development mode
pip install -e .
```

### Run Tests

```bash
# Run all tests
make test

# Or directly with pytest
python -m pytest tests/ -v
```

### Make Commands

```bash
make install    # Install package locally
make test       # Run test suite
make clean      # Clean build artifacts
make release    # Tag and push release
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes and add tests
4. Ensure tests pass: `make test`
5. Commit changes: `git commit -m "feat: add amazing feature"`
6. Push to branch: `git push origin feature/amazing-feature`
7. Open a Pull Request

## 🐛 Troubleshooting

### Ollama Connection Issues

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Start Ollama if not running
ollama serve

# Pull a model if none available
ollama pull llama2
```

### Installation Issues

```bash
# Ensure Python 3.10+
python --version

# Update pip
pip install --upgrade pip

# Reinstall with verbose output
pip install -e . -v
```

### Permission Issues (Windows)

```bash
# Run as administrator or use user install
pip install --user -e .
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Ollama](https://ollama.ai) for local LLM inference
- [LangChain](https://langchain.com) for RAG framework
- [Click](https://click.palletsprojects.com) for CLI framework
- [Rich](https://rich.readthedocs.io) for beautiful terminal output

---

**Built with ❤️ for developers who value privacy and local-first tools.**# CodeInsight-CLI
