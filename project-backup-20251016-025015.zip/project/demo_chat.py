#!/usr/bin/env python3
"""
Demo script to showcase CodeInsight's interactive capabilities
"""
import time
from cli import console, ui
from core.retriever import retrieve
from core.llm_client import answer_query
from core.input_validation import sanitize_user_input

def demo_interactive_chat():
    """Demonstrate the interactive chat interface"""
    
    # Show banner
    ui.show_gemini_style_banner()
    console.print(f"\n[cyan]Framework:[/cyan] react")
    console.print(f"[cyan]Demo Mode:[/cyan] Interactive Chat Simulation")
    console.print("=" * 60)
    
    # Simulate user interactions
    demo_queries = [
        "How do I create a React component?",
        "What is JSX?", 
        "How do I handle events in React?",
        "What are React hooks?"
    ]
    
    for i, user_input in enumerate(demo_queries, 1):
        console.print(f"\n[bold blue]Demo Query #{i}:[/bold blue]")
        
        # Show user input bubble
        ui.render_user_message(user_input)
        
        try:
            # Show thinking indicator
            with console.status("[cyan]Thinking...[/cyan]", spinner="dots"):
                time.sleep(0.5)  # Simulate thinking time
                # Retrieve context
                context_chunks = retrieve(user_input, "react", 3)
                
                # Generate response
                answer = answer_query(user_input, context_chunks)
            
            # Show assistant response bubble
            ui.render_assistant_message(answer)
            
            # Add some spacing for readability
            console.print()
            
            # Pause between queries
            if i < len(demo_queries):
                time.sleep(1)
                
        except Exception as e:
            console.print(f"[red]Error: {str(e)}[/red]")
    
    console.print("[green]✅ Interactive Chat Demo Complete![/green]")
    console.print("\n[cyan]To start interactive chat:[/cyan]")
    console.print("  python cli.py chat")
    console.print("  python cli.py chat --framework vue")
    console.print("  python cli.py chat --model llama3.2:1b")

if __name__ == "__main__":
    demo_interactive_chat()