"""
CodeInsight CLI - Local RAG-powered developer assistant.
"""

__version__ = "0.1.0"
__author__ = "CodeInsight Team"
__description__ = "Local RAG-powered CLI developer assistant"