"""
Utility functions for CodeInsight.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from .configuration import get_config_manager


def ensure_directories():
    """Ensure required directories exist."""
    dirs = ["data/docs", "data/db", "configs"]
    for dir_path in dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)


def get_project_root() -> Path:
    """Get the project root directory."""
    return Path(__file__).parent.parent


def load_docs_sources() -> Dict[str, Any]:
    """
    Load documentation sources configuration from YAML file.
    Uses the new configuration management system.
    
    Returns:
        Dictionary mapping framework names to their source URLs and metadata
    """
    try:
        config_manager = get_config_manager()
        return config_manager.load_config("docs_sources")
    except Exception as e:
        # Fallback to legacy loading if configuration manager fails
        return _load_docs_sources_legacy()


def _load_docs_sources_legacy() -> Dict[str, Any]:
    """
    Legacy documentation sources loading for backward compatibility.
    
    Returns:
        Dictionary with default configuration
    """
    config_file = get_project_root() / "configs" / "docs_sources.yaml"
    
    if not config_file.exists():
        # Return default configuration if file doesn't exist
        return {
            "frameworks": {
                "react": {
                    "url": "https://react.dev/",
                    "description": "React - The library for web and native user interfaces"
                },
                "httpbin": {
                    "url": "https://httpbin.org/html", 
                    "description": "HTTPBin - HTTP Request & Response Service"
                }
            }
        }
    
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"Warning: Error loading configuration file: {e}")
        return {"frameworks": {}}


def get_framework_url(framework_name: str) -> Optional[str]:
    """
    Get the documentation URL for a framework using configuration manager.
    
    Args:
        framework_name: Name of the framework
        
    Returns:
        URL string, or None if not found
    """
    try:
        config_manager = get_config_manager()
        framework_config = config_manager.get_framework_config(framework_name)
        
        if framework_config:
            return framework_config.get("url")
        
        # Fallback to legacy loading
        config = _load_docs_sources_legacy()
        frameworks = config.get("frameworks", {})
        
        if framework_name in frameworks:
            return frameworks[framework_name]["url"]
        
        return None
        
    except Exception as e:
        print(f"Warning: Error getting framework URL: {e}")
        return None


def list_available_frameworks() -> Dict[str, str]:
    """
    List all available frameworks with their descriptions using configuration manager.
    
    Returns:
        Dictionary mapping framework names to descriptions
    """
    try:
        config_manager = get_config_manager()
        config = config_manager.load_config("docs_sources")
        frameworks = config.get("frameworks", {})
        
        return {
            name: framework_config.get("description", f"{name} framework")
            for name, framework_config in frameworks.items()
        }
        
    except Exception as e:
        print(f"Warning: Error listing frameworks: {e}")
        # Fallback to legacy loading
        config = _load_docs_sources_legacy()
        frameworks = config.get("frameworks", {})
        
        return {
            name: framework_config.get("description", f"{name} framework")
            for name, framework_config in frameworks.items()
        }