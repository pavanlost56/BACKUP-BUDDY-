"""
Interactive UI components for CodeInsight CLI.
Provides rich, interactive command experience with progress indicators,
streaming responses, and enhanced user feedback.
"""

import time
import threading
from typing import Dict, Any, List, Callable, Optional
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich.text import Text
from rich.layout import Layout
from rich.align import Align
from rich.padding import Padding
from rich.markdown import Markdown


def _create_live(*args, **kwargs):
    """Factory to obtain Live dynamically so tests can patch rich.live.Live."""
    from rich.live import Live
    return Live(*args, **kwargs)


class InteractiveUI:
    """Enhanced interactive UI components for CodeInsight CLI."""
    
    def __init__(self, console: Console):
        self.console = console
        self.current_operations = {}
        self._live_display = None
        
    def show_gemini_style_banner(self, version="1.0.0", status=None):
        """Display a Gemini CLI inspired welcome banner."""

        banner_table = Table.grid(padding=(0, 1), expand=True)
        banner_table.add_column(justify="center")

        banner_table.add_row(Text("CodeInsight", style="bold cyan"))
        banner_table.add_row(Text(f"v{version}", style="cyan"))
        banner_table.add_row(Text("Your local-first, privacy-focused AI developer assistant.", style="white"))
        banner_table.add_row(Text("", style="dim"))
        banner_table.add_row(Text("[~] Instant startup  -  [bot] Ollama-native  -  [lock] Local-first", style="dim"))

        main_panel = Panel(
            banner_table,
            border_style="blue",
            expand=False,
            title="[bold]Welcome[/bold]"
        )

        self.console.print(main_panel)

        if status:
            self.show_system_status(status)

        self.show_quick_actions()

    def show_quick_actions(self):
        """Display quick-start suggestions similar to Gemini CLI."""
        suggestions = Table.grid(padding=(0, 2))
        suggestions.add_column(justify="left")
        suggestions.add_row(Text("Try asking:", style="bold white"))
        suggestions.add_row(Text("- Explore React server components", style="dim"))
        suggestions.add_row(Text("- Draft a FastAPI service with auth", style="dim"))
        suggestions.add_row(Text("- Update Vue docs and summarize changes", style="dim"))

        self.console.print(
            Panel(
                suggestions,
                border_style="blue",
                title="Quick Actions",
                expand=False,
            )
        )

    def show_system_status(self, status: Dict[str, Any]):
        """Display system status in a clean table."""
        table = Table.grid(expand=True)
        table.add_column(justify="left", ratio=1)
        table.add_column(justify="left", ratio=1)
        table.add_column(justify="left", ratio=2)

        # Core Systems
        table.add_row("Core Systems", "[OK] Ready", "CLI, Agent, RAG pipeline")
        
        # Performance Monitor
        perf_status = status.get("performance_monitor", {})
        perf_icon = "[OK]" if perf_status.get("active") else "[X]"
        perf_details = "Real-time metrics enabled" if perf_status.get("active") else "Disabled"
        table.add_row("Performance Monitor", f"{perf_icon} {perf_status.get('status', 'Unknown')}", perf_details)

        # Cache System
        cache_status = status.get("cache", {})
        cache_icon = "[OK]" if cache_status.get("active") else "[X]"
        cache_details = f"Multi-level caching active ({cache_status.get('size_mb', 0):.2f} MB)"
        table.add_row("Cache System", f"{cache_icon} {cache_status.get('status', 'Ready')}", cache_details)

        # Ollama LLM
        ollama_status = status.get("ollama", {})
        ollama_icon = "[OK]" if ollama_status.get("connected") else "[!]"
        model_count = ollama_status.get('model_count', 0)
        model_text = f"{model_count} model{'s' if model_count != 1 else ''} available"
        if not ollama_status.get("connected"):
            model_text = "Connection failed"
        elif model_count == 0:
            model_text = "[yellow]No models found. Run 'ollama pull <model>'[/yellow]"
        
        table.add_row("Ollama LLM", f"{ollama_icon} {ollama_status.get('status', 'Unknown')}", model_text)
        
        self.console.print(
            Panel(
                table,
                title="[bold]System Status[/bold]",
                border_style="blue",
                expand=False
            )
        )

    def get_gemini_style_prompt(self) -> str:
        """Return the string for a Gemini-style prompt."""
        return "+-> "

    def render_user_message(self, message: str):
        """Render a chat bubble for user input."""
        bubble = Panel(
            Text(message, style="white"),
            border_style="cyan",
            title="[bold white]You[/bold white]",
            title_align="left",
            subtitle_align="right",
            subtitle="+",
        )
        self.console.print(bubble)

    def render_assistant_message(self, message: str):
        """Render a chat bubble for assistant responses."""
        bubble = Panel(
            Text(message, style="white"),
            border_style="magenta",
            title="[bold magenta]CodeInsight[/bold magenta]",
            title_align="left",
        )
        self.console.print(bubble)

    def render_routing(self, command: List[str], reasoning: Optional[str] = None):
        """Show how CodeInsight routed a natural query."""
        text = Text()
        text.append("-> ", style="cyan")
        text.append(" ".join(command), style="bold cyan")
        if reasoning:
            text.append(f"\n{reasoning}", style="dim")

        self.console.print(
            Panel(
                text,
                border_style="cyan",
                title="Routing",
                expand=False,
            )
        )
        
    def show_welcome_banner(self):
        """Display an enhanced welcome banner."""
        welcome_text = """
[bold blue][bot] CodeInsight CLI[/bold blue] - Your Hybrid Development Assistant

[dim]* Local RAG + Web Search + GitHub Integration
[search] Intelligent tool routing for up-to-date answers
[docs] Query documentation, find trends, explore repositories[/dim]

[yellow]Type your question or use specific commands:[/yellow]
- [cyan]codeinsight query "What are React hooks?"[/cyan] - Documentation queries
- [cyan]codeinsight agent "find trending Python libraries"[/cyan] - Web/GitHub searches  
- [cyan]codeinsight update react --force[/cyan] - Update local documentation
        """
        
        panel = Panel(
            welcome_text,
            title="Welcome to CodeInsight",
            border_style="blue",
            padding=(1, 2)
        )
        self.console.print(panel)
    
    def show_agent_planning(self, task: str, planned_steps: List[Dict[str, Any]]) -> bool:
        """Show agent planning with option for user to approve or modify.
        
        Args:
            task: The user's original task
            planned_steps: List of planned execution steps
            
        Returns:
            bool: True if user approves, False if they want to cancel
        """
        self.console.print(f"\n[bold cyan][bot] Agent Planning[/bold cyan]")
        self.console.print(f"[dim]Task: {task}[/dim]")
        
        # Create planning table
        table = Table(title="Execution Plan", show_header=True, header_style="bold magenta")
        table.add_column("Step", style="cyan", width=6)
        table.add_column("Tool", style="green", width=20)
        table.add_column("Action", style="yellow")
        table.add_column("Parameters", style="dim")
        
        for i, step in enumerate(planned_steps, 1):
            tool_name = step.get("tool_name", "unknown")
            action = step.get("action", "execute")
            params = step.get("parameters", {})
            
            # Format parameters nicely
            param_str = ", ".join([f"{k}={v}" for k, v in params.items() if v])
            if len(param_str) > 40:
                param_str = param_str[:37] + "..."
            
            table.add_row(
                str(i),
                tool_name,
                action,
                param_str
            )
        
        self.console.print(table)
        
        # Ask for user confirmation
        return Confirm.ask("\n[yellow]Proceed with this plan?[/yellow]", default=True)
    
    def create_progress_tracker(self, total_steps: int, task_description: str = "Processing") -> 'ProgressTracker':
        """Create a progress tracker for multi-step operations."""
        return ProgressTracker(self.console, total_steps, task_description)
    
    def stream_agent_response(self, response_generator, step_count: int = 1):
        """Stream agent responses in real-time with progress indication."""
        with Progress(
            SpinnerColumn(spinner_name="line"),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=self.console
        ) as progress:
            
            main_task = progress.add_task("Executing agent steps...", total=step_count)
            
            for i, step_result in enumerate(response_generator):
                # Update progress
                progress.update(main_task, completed=i + 1)
                
                # Show intermediate results if available
                if step_result.get("success") and "result" in step_result:
                    result_text = step_result["result"]
                    if result_text and len(result_text.strip()) > 0:
                        # Show a preview of the result
                        preview = result_text[:200] + "..." if len(result_text) > 200 else result_text
                        step_panel = Panel(
                            preview,
                            title=f"Step {i + 1} Result Preview",
                            border_style="green",
                            padding=(0, 1)
                        )
                        self.console.print(step_panel)
    
    def show_tool_selection_prompt(self, available_tools: List[str], query: str) -> Optional[str]:
        """Show interactive tool selection if agent is uncertain."""
        self.console.print(f"\n[yellow][?] Multiple tools could handle this query:[/yellow]")
        self.console.print(f"[dim]Query: {query}[/dim]\n")
        
        # Create tool selection table
        table = Table(show_header=True, header_style="bold blue")
        table.add_column("Option", style="cyan", width=8)
        table.add_column("Tool", style="green", width=20)
        table.add_column("Best For", style="yellow")
        
        tool_descriptions = {
            "rag_query_tool": "Local documentation, established concepts",
            "web_search_tool": "Current trends, latest information",
            "github_tool": "Repository data, trending projects",
            "url_fetch_tool": "Specific web content, articles",
            "doc_scrape_tool": "Update local documentation",
            "framework_list_tool": "Available frameworks, configuration"
        }
        
        # Add auto option
        table.add_row("auto", "Agent Choice", "Let the agent decide automatically")
        
        for i, tool in enumerate(available_tools, 1):
            description = tool_descriptions.get(tool, "General purpose tool")
            table.add_row(str(i), tool, description)
        
        self.console.print(table)
        
        # Get user choice
        choice = Prompt.ask(
            "\n[cyan]Select tool[/cyan]",
            choices=["auto"] + [str(i) for i in range(1, len(available_tools) + 1)],
            default="auto"
        )
        
        if choice == "auto":
            return None  # Let agent decide
        else:
            return available_tools[int(choice) - 1]
    
    def show_error_with_suggestions(self, error: str, suggestions: List[str] = None):
        """Display error with helpful suggestions and formatting."""
        error_panel = Panel(
            f"[red][X] Error:[/red] {error}",
            title="Operation Failed",
            border_style="red",
            padding=(1, 2)
        )
        self.console.print(error_panel)
        
        if suggestions:
            suggestion_text = "\n".join([f"- {s}" for s in suggestions])
            suggestion_panel = Panel(
                suggestion_text,
                title="[idea] Suggestions",
                border_style="yellow",
                padding=(1, 2)
            )
            self.console.print(suggestion_panel)
    
    def show_success_with_metadata(self, message: str, metadata: Dict[str, Any] = None):
        """Display success message with optional metadata."""
        success_panel = Panel(
            f"[green][OK] Success:[/green] {message}",
            title="Operation Completed",
            border_style="green",
            padding=(1, 2)
        )
        self.console.print(success_panel)
        
        if metadata:
            # Create metadata table
            table = Table(show_header=False, box=None, padding=(0, 1))
            table.add_column("Key", style="cyan")
            table.add_column("Value", style="white")
            
            for key, value in metadata.items():
                if value is not None:
                    table.add_row(f"{key.replace('_', ' ').title()}:", str(value))
            
            if table.row_count > 0:
                metadata_panel = Panel(
                    table,
                    title="Details",
                    border_style="blue",
                    padding=(0, 1)
                )
                self.console.print(metadata_panel)


class ProgressTracker:
    """Tracks progress of long-running operations with rich display."""
    
    def __init__(self, console: Console, total_steps: int, description: str = "Processing"):
        self.console = console
        self.total_steps = total_steps
        self.description = description
        self.current_step = 0
        self.progress = None
        self.task_id = None
        self.step_details = []
        
    def __enter__(self):
        """Start progress tracking."""
        self.progress = Progress(
            SpinnerColumn(spinner_name="line"),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=self.console
        )
        self.progress.__enter__()
        self.task_id = self.progress.add_task(self.description, total=self.total_steps)
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """End progress tracking."""
        if self.progress:
            self.progress.__exit__(exc_type, exc_val, exc_tb)
    
    def update_step(self, step_name: str, details: str = None):
        """Update current step with name and optional details."""
        self.current_step += 1
        self.step_details.append({"name": step_name, "details": details})
        
        if self.progress and self.task_id:
            description = f"{self.description} - {step_name}"
            self.progress.update(
                self.task_id, 
                completed=self.current_step,
                description=description
            )
    
    def complete(self, final_message: str = None):
        """Mark progress as complete."""
        if self.progress and self.task_id:
            self.progress.update(
                self.task_id,
                completed=self.total_steps,
                description=final_message or f"{self.description} - Complete"
            )


class StreamingResponse:
    """Handles streaming display of agent responses."""
    
    def __init__(self, console: Console):
        self.console = console
        self.current_content = ""
        self.live_display = None
        
    def start_streaming(self, title: str = "Agent Response"):
        """Start streaming display."""
        panel = Panel(
            self.current_content,
            title=title,
            border_style="cyan"
        )
        self.live_display = _create_live(panel, console=self.console, refresh_per_second=4)
        self.live_display.start()
    
    def update_content(self, new_content: str):
        """Update streaming content."""
        self.current_content = new_content
        if self.live_display:
            panel = Panel(
                self.current_content,
                title="Agent Response",
                border_style="cyan"
            )
            self.live_display.update(panel)
    
    def finish_streaming(self):
        """Finish streaming and show final result."""
        if self.live_display:
            self.live_display.stop()
            
        # Show final result with formatting
        final_panel = Panel(
            self.current_content,
            title="[OK] Final Result",
            border_style="green",
            padding=(1, 2)
        )
        self.console.print(final_panel)


def create_interactive_ui(console: Console) -> InteractiveUI:
    """Factory function to create InteractiveUI instance."""
    return InteractiveUI(console)
