"""
Core modules for CodeInsight - a local RAG-powered CLI developer assistant.
"""

__version__ = "0.1.0"