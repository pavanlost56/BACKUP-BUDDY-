"""
LLM client for communicating with Ollama local inference server.
"""

from typing import List, Dict, Any, Optional

import requests
import json

from core.performance_monitoring import timed_operation
from .configuration import get_config_manager


class LLMClient:
    """Client for communicating with Ollama local inference server."""

    def __init__(self):
        self.config_manager = get_config_manager()
        self.ollama_config = self._get_ollama_config()
        self.base_url = self.ollama_config.get("base_url", "http://localhost:11434")

    def _get_ollama_config(self) -> Dict[str, Any]:
        """Get Ollama configuration from settings."""
        return self.config_manager.get_setting("ollama", default={
            "default_model": "mistral:7b-instruct",
            "base_url": "http://localhost:11434",
            "temperature": 0.1,
            "top_p": 0.9,
            "top_k": 40
        })

    def get_connection_status(self) -> Dict[str, Any]:
        """Check connection to Ollama and return a status dictionary."""
        is_connected = self.check_ollama_server()
        models = self.get_available_models() if is_connected else []
        
        return {
            "connected": is_connected,
            "status": "Connected" if is_connected else "Unavailable",
            "model_count": len(models),
            "models": models,
            "base_url": self.base_url
        }

    def check_ollama_server(self) -> bool:
        """Check if Ollama server is running and accessible."""
        try:
            response = requests.get(f"{self.base_url}/api/version", timeout=5)
            return response.status_code == 200
        except requests.RequestException:
            return False

    def get_available_models(self) -> List[str]:
        """Get list of available models from Ollama server."""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                data = response.json()
                return [model["name"] for model in data.get("models", [])]
            return []
        except requests.RequestException:
            return []

    def _ensure_model_available(self, model: str) -> bool:
        """Ensure the specified model is available, attempting to pull it if not."""
        import subprocess
        
        available_models = self.get_available_models()
        if model in available_models:
            return True
            
        # Try to pull the model
        try:
            print(f"Model '{model}' not found. Attempting to pull...")
            result = subprocess.run(
                ["ollama", "pull", model], 
                capture_output=True, 
                text=True, 
                timeout=300,  # 5 minutes timeout
                encoding='utf-8',
                errors='ignore'  # Handle encoding issues gracefully
            )
            if result.returncode == 0:
                print(f"Successfully pulled model '{model}'")
                return True
            else:
                print(f"Failed to pull model '{model}': {result.stderr}")
                return False
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception) as e:
            print(f"Error pulling model '{model}': {e}")
            return False

    @timed_operation("ollama_generate")
    def call_ollama_generate(self, prompt: str, model: Optional[str] = None) -> str:
        """Call Ollama's generate API with a prompt."""
        model = model or self.ollama_config.get("default_model", "mistral:7b-instruct")
        url = f"{self.base_url}/api/generate"
        
        # Ensure model is available
        if not self._ensure_model_available(model):
            raise ConnectionError(f"Model '{model}' is not available and could not be pulled. Run 'ollama pull {model}' manually.")
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": self.ollama_config.get("temperature", 0.1),
                "top_p": self.ollama_config.get("top_p", 0.9),
                "top_k": self.ollama_config.get("top_k", 40)
            }
        }
        
        try:
            response = requests.post(url, json=payload, timeout=120)
            response.raise_for_status()
            result = response.json()
            return result.get("response", "").strip()
        except requests.RequestException as e:
            raise ConnectionError(f"Failed to connect to Ollama server: {e}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid response from Ollama server: {e}")

    def build_rag_prompt(self, query: str, context_chunks: List[Dict[str, Any]]) -> str:
        """Build the RAG prompt using the specified template."""
        context_parts = [f"{chunk['content']}\nSource: {chunk['source_path']}#{chunk['chunk_id']}" for chunk in context_chunks]
        context_text = "\n\n".join(context_parts)
        
        prompt = f"""SYSTEM: You are CodeInsight — a precise local developer assistant. CRITICAL RULES:
1. Answer ONLY using the provided context chunks below
2. If information is missing from context, explicitly state "This information is not available in the provided documentation"
3. Do NOT generate code examples unless they appear verbatim in the context
4. Always cite specific source files and chunk IDs
5. Structure response as: Summary (2-3 lines), Steps/Code (only if in context), Sources (specific citations)

CONTEXT CHUNKS:
{context_text}

USER QUERY:
{query}

REQUIRED FORMAT:
## Summary
[Brief answer based ONLY on provided context]

## Steps/Code
[Include ONLY if specific steps or code appear in the context. Wrap code in triple backticks with language.]

## Sources
[List specific source files and chunk IDs used: source_path#chunk_id]

REMEMBER: If context lacks sufficient information, say so clearly. Never invent information."""
        return prompt

    @timed_operation("answer_query")
    def answer_query(self, query: str, context_chunks: list) -> str:
        """Generate an answer using Ollama LLM with retrieved context."""
        if not self.check_ollama_server():
            context_summary = "\n".join([f"- {chunk['content'][:100]}..." for chunk in context_chunks])
            return f"""## Summary
Ollama server not responding at {self.base_url} — start with 'ollama serve'.

## Fallback Response
Based on available context for query: "{query}"
{context_summary}
"""
        try:
            prompt = self.build_rag_prompt(query, context_chunks)
            response = self.call_ollama_generate(prompt)
            return response
        except (ConnectionError, ValueError) as e:
            context_summary = "\n".join([f"- {chunk['content'][:100]}..." for chunk in context_chunks])
            return f"""## Summary
Error communicating with Ollama: {str(e)}

## Fallback Response
Based on available context for query: "{query}"
{context_summary}
"""

# Singleton instance
_llm_client = None

def get_llm_client() -> LLMClient:
    """Get the singleton instance of the LLMClient."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client


# Backwards-compatible module-level functions
def check_ollama_server(base_url: Optional[str] = None) -> bool:
    """Proxy to maintain compatibility with existing imports."""
    client = get_llm_client()
    if base_url and base_url != client.base_url:
        client.base_url = base_url
    return client.check_ollama_server()


def get_available_models(base_url: Optional[str] = None) -> List[str]:
    """Proxy that returns available models from Ollama."""
    client = get_llm_client()
    if base_url and base_url != client.base_url:
        client.base_url = base_url
    return client.get_available_models()


def call_ollama_generate(prompt: str, model: Optional[str] = None, base_url: Optional[str] = None) -> str:
    """Proxy to the client's generate method."""
    client = get_llm_client()
    if base_url and base_url != client.base_url:
        client.base_url = base_url
    return client.call_ollama_generate(prompt, model=model)


def build_rag_prompt(query: str, context_chunks: List[Dict[str, Any]]) -> str:
    """Proxy to build the standard RAG prompt."""
    client = get_llm_client()
    return client.build_rag_prompt(query, context_chunks)


def answer_query(query: str, context_chunks: list) -> str:
    """Proxy to maintain the public API expected by other modules."""
    client = get_llm_client()
    return client.answer_query(query, context_chunks)


def get_ollama_config() -> Dict[str, Any]:
    """Get Ollama configuration settings."""
    client = get_llm_client()
    return client.ollama_config


__all__ = [
    "LLMClient",
    "get_llm_client",
    "check_ollama_server",
    "get_available_models",
    "call_ollama_generate",
    "build_rag_prompt",
    "answer_query",
    "get_ollama_config",
]