"""
Retriever module for similarity search and context retrieval.
"""

import json
import numpy as np
import pickle
from pathlib import Path
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Dict, Any
from core.performance_monitoring import timed_operation


def load_framework_database(framework_name: str, persist_dir: str = "data/db") -> tuple:
    """
    Load the vector database for a specific framework.
    
    Args:
        framework_name: Name of the framework
        persist_dir: Directory where database is persisted
        
    Returns:
        Tuple of (chunks_data, vectorizer, embeddings_matrix, metadata)
    """
    db_path = Path(persist_dir) / framework_name
    
    if not db_path.exists():
        raise FileNotFoundError(f"Database not found for framework: {framework_name}")
    
    # Load chunks
    chunks_file = db_path / "chunks.json"
    if not chunks_file.exists():
        raise FileNotFoundError(f"Chunks file not found: {chunks_file}")
    
    with open(chunks_file, "r", encoding="utf-8") as f:
        chunks_data = json.load(f)
    
    # Load vectorizer
    vectorizer_file = db_path / "vectorizer.pkl"
    if not vectorizer_file.exists():
        raise FileNotFoundError(f"Vectorizer file not found: {vectorizer_file}")
    
    with open(vectorizer_file, "rb") as f:
        vectorizer = pickle.load(f)
    
    # Load embeddings
    embeddings_file = db_path / "embeddings.npy"
    if not embeddings_file.exists():
        raise FileNotFoundError(f"Embeddings file not found: {embeddings_file}")
    
    embeddings = np.load(embeddings_file)
    
    # Load metadata
    metadata_file = db_path / "metadata.json"
    metadata = {}
    if metadata_file.exists():
        with open(metadata_file, "r", encoding="utf-8") as f:
            metadata = json.load(f)
    
    return chunks_data, vectorizer, embeddings, metadata


def compute_query_similarity(query: str, vectorizer, doc_embeddings: np.ndarray) -> np.ndarray:
    """
    Compute cosine similarity between query and document embeddings.
    
    Args:
        query: Search query text
        vectorizer: Trained TF-IDF vectorizer
        doc_embeddings: Document embedding matrix
        
    Returns:
        Array of similarity scores
    """
    # Transform query using the same vectorizer
    query_embedding = vectorizer.transform([query])
    
    # Compute cosine similarity
    similarities = cosine_similarity(query_embedding, doc_embeddings)
    
    return similarities[0]  # Return 1D array


@timed_operation("retrieve")
def retrieve(query: str, framework_name: str, top_k: int = 5) -> list:
    """
    Retrieve relevant context chunks for a query.
    
    Args:
        query: The user's query
        framework_name: Framework to search within
        top_k: Number of top results to return
        
    Returns:
        List of context chunks with metadata and similarity scores
    """
    try:
        # Load the database
        chunks_data, vectorizer, embeddings, metadata = load_framework_database(framework_name)
        
        if not chunks_data:
            return []
        
        # Compute similarities
        similarities = compute_query_similarity(query, vectorizer, embeddings)
        
        # Get top-k indices
        top_indices = np.argsort(similarities)[::-1][:top_k]
        
        # Build results with metadata
        results = []
        for idx in top_indices:
            chunk = chunks_data[idx]
            similarity_score = float(similarities[idx])
            
            result = {
                "content": chunk["content"],
                "source_path": chunk["source_file"],
                "chunk_id": chunk["id"],
                "chunk_hash": chunk["hash"],
                "similarity_score": similarity_score,
                "chunk_index": chunk["chunk_index"]
            }
            results.append(result)
        
        return results
        
    except FileNotFoundError as e:
        # Return empty results if database doesn't exist
        print(f"Warning: {e}")
        return []
    except Exception as e:
        print(f"Error during retrieval: {e}")
        return []