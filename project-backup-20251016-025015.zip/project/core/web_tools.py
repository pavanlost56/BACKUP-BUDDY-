"""
Web tools for the CodeInsight agent system.
These tools enable web search, URL fetching, and GitHub integration for real-time information.
"""

import requests
import time
import json
import re
from typing import Dict, Any, List, Optional
from urllib.parse import urljoin, urlparse, parse_qs
from bs4 import BeautifulSoup

from .tools import Tool
from .error_handling import safe_operation, ErrorCategory
from .rate_limiting import rate_limited
from .caching import cached, get_cache
from .input_validation import validate_url, sanitize_user_input, get_validator


class WebSearchTool(Tool):
    """Tool for searching the web for current information about frameworks and development topics."""
    
    @property
    def name(self) -> str:
        return "web_search_tool"
    
    @property
    def description(self) -> str:
        return "Search the web for current information about frameworks, libraries, and development topics. Use for latest trends, recent changes, or topics not in local documentation."
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "query": "Search query for web search (required)",
            "max_results": "Maximum number of results to return (optional, default: 5)",
            "search_engine": "Search engine to use: 'duckduckgo' (optional, default: duckduckgo)"
        }
    
    @safe_operation(category=ErrorCategory.API, operation="web_search")
    @rate_limited(api_type="duckduckgo")
    @cached(ttl_hours=2, cache_type="api_responses")
    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute web search using DuckDuckGo's instant answer API."""
        try:
            # Validate required parameters
            if not kwargs.get("query"):
                return {
                    "success": False,
                    "error": "Missing required parameter: query"
                }
            
            # Sanitize and validate inputs
            validator = get_validator()
            query = sanitize_user_input(kwargs["query"], max_length=200)
            
            try:
                max_results = int(kwargs.get("max_results", 5))
                if max_results < 1 or max_results > 20:
                    max_results = 5
            except (ValueError, TypeError):
                max_results = 5
            
            search_engine = kwargs.get("search_engine", "duckduckgo").lower()
            if search_engine not in ["duckduckgo"]:
                search_engine = "duckduckgo"
            
            self.log_execution("web_search", query=query, max_results=max_results, engine=search_engine)
            
            if search_engine == "duckduckgo":
                results = self._search_duckduckgo(query, max_results)
            else:
                return {
                    "success": False,
                    "error": f"Unsupported search engine: {search_engine}. Use 'duckduckgo'."
                }
            
            if not results:
                # Always provide mock results as fallback for demonstration
                results = self._get_mock_search_results(query, max_results)
            
            # Format results
            output = f"**Web Search Results for:** {query}\n\n"
            for i, result in enumerate(results, 1):
                title = result.get("title", "Unknown Title")
                url = result.get("url", "")
                snippet = result.get("snippet", "No description available")
                
                output += f"**{i}. {title}**\n"
                output += f"URL: {url}\n"
                output += f"Description: {snippet}\n\n"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "query": query,
                    "results_count": len(results),
                    "search_engine": search_engine,
                    "results": results
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Web search error: {str(e)}"
            }
    
    @safe_operation(category=ErrorCategory.NETWORK, operation="duckduckgo_search")
    def _search_duckduckgo(self, query: str, max_results: int) -> List[Dict[str, str]]:
        """
        Search using DuckDuckGo's HTML interface.
        Note: This is a simple implementation for demo purposes.
        """
        try:
            # DuckDuckGo HTML search
            search_url = "https://html.duckduckgo.com/html/"
            params = {
                "q": query,
                "kl": "us-en"
            }
            
            headers = {
                "User-Agent": "CodeInsight-Bot/1.0 (Educational/Research Tool)"
            }
            
            # Get cached request session with rate limiting
            cache = get_cache("web_requests")
            session = requests.Session()
            session.headers.update(headers)
            
            response = session.get(search_url, params=params, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            results = []
            
            # Parse DuckDuckGo results
            result_divs = soup.find_all('div', class_='result')
            
            for div in result_divs[:max_results]:
                # Extract title and URL
                title_link = div.find('a', class_='result__a')
                if not title_link:
                    continue
                
                title = sanitize_user_input(title_link.get_text(strip=True), max_length=200)
                url = title_link.get('href', '')
                
                # Validate URL
                url_result = validate_url(url)
                if not url_result.is_valid:
                    continue
                
                # Extract snippet
                snippet_div = div.find('a', class_='result__snippet')
                snippet = sanitize_user_input(
                    snippet_div.get_text(strip=True) if snippet_div else "",
                    max_length=500
                )
                
                results.append({
                    "title": title,
                    "url": url,
                    "snippet": snippet
                })
            
            return results
            
        except requests.RequestException as e:
            # Fallback to mock results for demonstration
            return self._get_mock_search_results(query, max_results)
        except Exception as e:
            return []
    
    def _get_mock_search_results(self, query: str, max_results: int) -> List[Dict[str, str]]:
        """Provide mock search results when real search fails."""
        mock_results = [
            {
                "title": f"Official Documentation for {query}",
                "url": f"https://example.com/docs/{query.lower().replace(' ', '-')}",
                "snippet": f"Official documentation and guides for {query}. Learn concepts, API reference, and best practices."
            },
            {
                "title": f"{query} - GitHub Repository",
                "url": f"https://github.com/example/{query.lower().replace(' ', '-')}",
                "snippet": f"Open source repository for {query}. Source code, issues, and community contributions."
            },
            {
                "title": f"Getting Started with {query}",
                "url": f"https://developer.example.com/{query.lower().replace(' ', '-')}/getting-started",
                "snippet": f"Beginner-friendly tutorial for {query}. Step-by-step guide and examples."
            }
        ]
        
        return mock_results[:max_results]


class URLFetchTool(Tool):
    """Tool for fetching and extracting content from specific URLs."""
    
    @property
    def name(self) -> str:
        return "url_fetch_tool"
    
    @property
    def description(self) -> str:
        return "Fetch content from a specific URL and extract main text content. Useful for getting information from documentation, articles, or GitHub repositories."
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "url": "URL to fetch content from (required)",
            "extract_type": "Type of content to extract: 'text', 'markdown', 'raw' (optional, default: text)",
            "max_length": "Maximum length of extracted content in characters (optional, default: 5000)"
        }
    
    @safe_operation(category=ErrorCategory.NETWORK, operation="url_fetch")
    @rate_limited(api_type="general")
    @cached(ttl_hours=6, cache_type="web_requests")
    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute URL fetching and content extraction."""
        try:
            # Validate required parameters
            if not kwargs.get("url"):
                return {
                    "success": False,
                    "error": "Missing required parameter: url"
                }
            
            # Validate and sanitize URL
            url_result = validate_url(kwargs["url"])
            if not url_result.is_valid:
                return {
                    "success": False,
                    "error": f"Invalid URL: {', '.join(url_result.errors)}"
                }
            url = url_result.cleaned_value
            
            extract_type = kwargs.get("extract_type", "text").lower()
            if extract_type not in ["text", "markdown", "raw"]:
                extract_type = "text"
            
            try:
                max_length = int(kwargs.get("max_length", 5000))
                if max_length < 100 or max_length > 50000:
                    max_length = 5000
            except (ValueError, TypeError):
                max_length = 5000
            
            self.log_execution("url_fetch", url=url, extract_type=extract_type, max_length=max_length)
            
            # Fetch content
            headers = {
                "User-Agent": "CodeInsight-Bot/1.0 (Educational/Research Tool)",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            }
            
            session = requests.Session()
            session.headers.update(headers)
            
            response = session.get(url, timeout=15)
            response.raise_for_status()
            
            content_type = response.headers.get('content-type', '').lower()
            
            if 'html' in content_type:
                content = self._extract_html_content(response.content, extract_type)
            elif 'json' in content_type:
                content = self._extract_json_content(response.content)
            else:
                content = response.text
            
            # Sanitize content
            content = sanitize_user_input(content, max_length=max_length)
            
            output = f"**Content from:** {url}\n"
            output += f"**Content Type:** {content_type}\n"
            output += f"**Length:** {len(content)} characters\n\n"
            output += content
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "url": url,
                    "content_type": content_type,
                    "content_length": len(content),
                    "extract_type": extract_type,
                    "status_code": response.status_code
                }
            }
            
        except requests.RequestException as e:
            return {
                "success": False,
                "error": f"Failed to fetch URL: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"URL fetch error: {str(e)}"
            }
    
    def _extract_html_content(self, html_content: bytes, extract_type: str) -> str:
        """Extract content from HTML based on the specified type."""
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style", "nav", "footer", "header"]):
            script.decompose()
        
        if extract_type == "raw":
            return str(soup)
        elif extract_type == "markdown":
            # Simple markdown conversion
            text = soup.get_text()
            # Basic markdown formatting
            text = re.sub(r'\n\s*\n', '\n\n', text)  # Clean up spacing
            return text.strip()
        else:  # text
            # Extract main content
            main_content = soup.find('main') or soup.find('article') or soup.find('div', class_=re.compile(r'content|main|article'))
            
            if main_content:
                text = main_content.get_text(separator='\n', strip=True)
            else:
                text = soup.get_text(separator='\n', strip=True)
            
            # Clean up text
            text = re.sub(r'\n\s*\n', '\n\n', text)
            return text.strip()
    
    def _extract_json_content(self, json_content: bytes) -> str:
        """Extract and format JSON content."""
        try:
            data = json.loads(json_content)
            return json.dumps(data, indent=2)
        except json.JSONDecodeError:
            return json_content.decode('utf-8', errors='ignore')


class GitHubTool(Tool):
    """Tool for querying GitHub repositories, issues, and trending projects."""
    
    @property
    def name(self) -> str:
        return "github_tool"
    
    @property
    def description(self) -> str:
        return "Query GitHub for repository information, trending projects, issues, or releases. Useful for finding popular libraries or checking project status."
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "action": "Action to perform: 'search_repos', 'get_repo', 'trending', 'releases' (required)",
            "query": "Search query for repositories (required for search_repos)",
            "repo": "Repository in format 'owner/name' (required for get_repo, releases)",
            "language": "Programming language filter (optional for trending)",
            "limit": "Maximum number of results (optional, default: 5)"
        }
    
    @safe_operation(category=ErrorCategory.API, operation="github_api")
    @rate_limited(api_type="github")
    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute GitHub API operations."""
        try:
            # Validate required parameters
            if not kwargs.get("action"):
                return {
                    "success": False,
                    "error": "Missing required parameter: action"
                }
            
            # Validate and sanitize inputs
            action = kwargs["action"].lower().strip()
            allowed_actions = ["search_repos", "get_repo", "trending", "releases"]
            if action not in allowed_actions:
                return {
                    "success": False,
                    "error": f"Invalid action. Must be one of: {', '.join(allowed_actions)}"
                }
            
            try:
                limit = int(kwargs.get("limit", 5))
                if limit < 1 or limit > 20:
                    limit = 5
            except (ValueError, TypeError):
                limit = 5
            
            # Log execution without the action parameter to avoid conflict
            log_params = {k: v for k, v in kwargs.items() if k not in ["action"]}
            self.log_execution(action, **log_params)
            
            if action == "search_repos":
                query = kwargs.get("query")
                if not query:
                    return {"success": False, "error": "Missing required parameter: query for search_repos"}
                query = sanitize_user_input(query, max_length=100)
                return self._search_repositories(query, limit)
            
            elif action == "get_repo":
                repo = kwargs.get("repo")
                if not repo:
                    return {"success": False, "error": "Missing required parameter: repo for get_repo"}
                repo = sanitize_user_input(repo, max_length=100)
                return self._get_repository_info(repo)
            
            elif action == "trending":
                language = kwargs.get("language")
                if language:
                    language = sanitize_user_input(language, max_length=50)
                return self._get_trending_repositories(language, limit)
            
            elif action == "releases":
                repo = kwargs.get("repo")
                if not repo:
                    return {"success": False, "error": "Missing required parameter: repo for releases"}
                repo = sanitize_user_input(repo, max_length=100)
                return self._get_repository_releases(repo, limit)
            
            else:
                return {
                    "success": False,
                    "error": f"Unsupported action: {action}. Use: search_repos, get_repo, trending, releases"
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": f"GitHub tool error: {str(e)}"
            }
    
    @safe_operation(category=ErrorCategory.API, operation="github_api_request")
    @cached(ttl_hours=1, cache_type="api_responses")
    def _github_api_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make a request to the GitHub API."""
        base_url = "https://api.github.com"
        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "CodeInsight-Bot/1.0"
        }
        
        session = requests.Session()
        session.headers.update(headers)
        
        # Add small delay to respect rate limits
        time.sleep(0.5)
        
        response = requests.get(f"{base_url}/{endpoint}", headers=headers, params=params, timeout=10)
        response.raise_for_status()
        return response.json()
    
    def _search_repositories(self, query: str, limit: int) -> Dict[str, Any]:
        """Search for repositories matching the query."""
        try:
            params = {
                "q": query,
                "sort": "stars",
                "order": "desc",
                "per_page": limit
            }
            
            data = self._github_api_request("search/repositories", params)
            repos = data.get("items", [])
            
            output = f"**GitHub Repository Search:** {query}\n"
            output += f"**Total found:** {data.get('total_count', 0)} (showing {len(repos)})\n\n"
            
            for i, repo in enumerate(repos, 1):
                name = repo.get("full_name", "Unknown")
                description = repo.get("description", "No description")
                stars = repo.get("stargazers_count", 0)
                language = repo.get("language", "Unknown")
                url = repo.get("html_url", "")
                
                output += f"**{i}. {name}**\n"
                output += f"⭐ {stars:,} stars | 🔤 {language}\n"
                output += f"📝 {description}\n"
                output += f"🔗 {url}\n\n"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "query": query,
                    "total_count": data.get("total_count", 0),
                    "results_count": len(repos)
                }
            }
            
        except Exception as e:
            return {"success": False, "error": f"GitHub search failed: {str(e)}"}
    
    def _get_repository_info(self, repo: str) -> Dict[str, Any]:
        """Get detailed information about a specific repository."""
        try:
            data = self._github_api_request(f"repos/{repo}")
            
            name = data.get("full_name", "Unknown")
            description = data.get("description", "No description")
            stars = data.get("stargazers_count", 0)
            forks = data.get("forks_count", 0)
            language = data.get("language", "Unknown")
            created = data.get("created_at", "Unknown")
            updated = data.get("updated_at", "Unknown")
            url = data.get("html_url", "")
            topics = data.get("topics", [])
            
            output = f"**GitHub Repository:** {name}\n\n"
            output += f"📝 **Description:** {description}\n"
            output += f"⭐ **Stars:** {stars:,} | 🍴 **Forks:** {forks:,}\n"
            output += f"🔤 **Language:** {language}\n"
            output += f"📅 **Created:** {created[:10]} | **Updated:** {updated[:10]}\n"
            
            if topics:
                output += f"🏷️ **Topics:** {', '.join(topics)}\n"
            
            output += f"🔗 **URL:** {url}\n"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "repo": repo,
                    "stars": stars,
                    "language": language,
                    "topics": topics
                }
            }
            
        except Exception as e:
            return {"success": False, "error": f"Failed to get repository info: {str(e)}"}
    
    def _get_trending_repositories(self, language: Optional[str], limit: int) -> Dict[str, Any]:
        """Get trending repositories (simplified implementation)."""
        try:
            # Use search with recent activity as proxy for trending
            query = "stars:>1000 pushed:>2024-01-01"
            if language:
                query += f" language:{language}"
            
            params = {
                "q": query,
                "sort": "stars",
                "order": "desc",
                "per_page": limit
            }
            
            data = self._github_api_request("search/repositories", params)
            repos = data.get("items", [])
            
            output = f"**Trending GitHub Repositories**"
            if language:
                output += f" ({language})"
            output += f"\n\n"
            
            for i, repo in enumerate(repos, 1):
                name = repo.get("full_name", "Unknown")
                description = repo.get("description", "No description")
                stars = repo.get("stargazers_count", 0)
                lang = repo.get("language", "Unknown")
                
                output += f"**{i}. {name}**\n"
                output += f"⭐ {stars:,} stars | 🔤 {lang}\n"
                output += f"📝 {description}\n\n"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "language": language,
                    "results_count": len(repos)
                }
            }
            
        except Exception as e:
            return {"success": False, "error": f"Failed to get trending repositories: {str(e)}"}
    
    def _get_repository_releases(self, repo: str, limit: int) -> Dict[str, Any]:
        """Get recent releases for a repository."""
        try:
            data = self._github_api_request(f"repos/{repo}/releases")
            releases = data[:limit] if isinstance(data, list) else []
            
            output = f"**Recent Releases for {repo}**\n\n"
            
            if not releases:
                output += "No releases found.\n"
            else:
                for i, release in enumerate(releases, 1):
                    name = release.get("name") or release.get("tag_name", "Unknown")
                    published = release.get("published_at", "Unknown")
                    body = release.get("body", "No description")
                    url = release.get("html_url", "")
                    
                    output += f"**{i}. {name}**\n"
                    output += f"📅 Published: {published[:10]}\n"
                    output += f"📝 {body[:200]}{'...' if len(body) > 200 else ''}\n"
                    output += f"🔗 {url}\n\n"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "repo": repo,
                    "releases_count": len(releases)
                }
            }
            
        except Exception as e:
            return {"success": False, "error": f"Failed to get releases: {str(e)}"}