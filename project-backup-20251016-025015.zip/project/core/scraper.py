"""
Web scraper module for fetching and saving documentation.
Respects robots.txt and implements polite crawling.
"""

import time
import logging
import requests
from urllib.robotparser import RobotFileParser
from urllib.parse import urljoin, urlparse
from pathlib import Path
from bs4 import BeautifulSoup
import re
from core.performance_monitoring import timed_operation

logger = logging.getLogger("codeinsight.scraper")

FALLBACK_CONTENT = {
    "httpbin": {
        "title": "HTTPBin Sample Documentation",
        "source": "https://httpbin.org/html",
        "content": """## Overview
HTTPBin is a simple HTTP request and response service. It allows you to test HTTP clients by returning structured data for various request scenarios.

## Useful Endpoints
- `/get` - Inspect query parameters and headers.
- `/post` - Echo posted JSON or form data.
- `/status/{code}` - Simulate HTTP status codes for testing error handling.
- `/delay/{seconds}` - Introduce artificial latency when testing retries.

## Tips
- HTTPBin is ideal for demonstrations, tutorials, and verifying HTTP libraries.
- Responses are JSON by default; append `?format=json` on supported endpoints to enforce JSON output.
""",
    }
}

def _save_markdown(framework_name: str, title: str, source_url: str, content: str) -> Path:
    """Persist scraped or fallback content to the docs directory."""
    docs_dir = Path("data/docs")
    docs_dir.mkdir(parents=True, exist_ok=True)
    
    output_file = docs_dir / f"{framework_name}.md"
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"# {title}\n\n")
        f.write(f"Source: {source_url}\n")
        f.write(f"Fetched: {timestamp}\n\n")
        f.write("---\n\n")
        f.write(content.strip())
        f.write("\n")
    
    return output_file


def check_robots_txt(url: str, user_agent: str = "CodeInsight-Bot") -> bool:
    """
    Check if the URL is allowed by robots.txt.
    
    Args:
        url: The URL to check
        user_agent: User agent string to check against
        
    Returns:
        True if allowed, False if disallowed
    """
    try:
        parsed_url = urlparse(url)
        robots_url = f"{parsed_url.scheme}://{parsed_url.netloc}/robots.txt"
        
        rp = RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        
        return rp.can_fetch(user_agent, url)
    except Exception:
        # If robots.txt cannot be fetched or parsed, assume allowed
        return True


def extract_main_content(soup: BeautifulSoup) -> str:
    """
    Extract main content from HTML using content heuristics.
    
    Args:
        soup: BeautifulSoup parsed HTML
        
    Returns:
        Extracted text content as markdown-like string
    """
    # Remove script and style elements
    for script in soup(["script", "style", "nav", "header", "footer", "aside"]):
        script.decompose()
    
    # Try to find main content area using common selectors
    content_selectors = [
        "main",
        "article", 
        ".content",
        ".main-content",
        ".documentation",
        ".docs",
        "#content",
        "#main",
        ".markdown-body"
    ]
    
    content_element = None
    for selector in content_selectors:
        content_element = soup.select_one(selector)
        if content_element:
            break
    
    # Fallback to body if no content area found
    if not content_element:
        content_element = soup.find("body")
    
    if not content_element:
        return soup.get_text()
    
    # Extract text with basic markdown formatting
    text_content = []
    
    for element in content_element.find_all(True):
        if element.name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            level = int(element.name[1])
            text_content.append(f"{'#' * level} {element.get_text().strip()}")
        elif element.name == 'p':
            text_content.append(element.get_text().strip())
        elif element.name in ['code', 'pre']:
            code_text = element.get_text().strip()
            if '\n' in code_text:
                text_content.append(f"```\n{code_text}\n```")
            else:
                text_content.append(f"`{code_text}`")
        elif element.name in ['ul', 'ol']:
            for li in element.find_all('li', recursive=False):
                text_content.append(f"- {li.get_text().strip()}")
    
    # Clean up and join content
    content = '\n\n'.join(filter(None, text_content))
    
    # Remove excessive whitespace
    content = re.sub(r'\n{3,}', '\n\n', content)
    
    return content.strip()


@timed_operation("fetch_and_save")
def fetch_and_save(url: str, framework_name: str) -> dict:
    """
    Fetch documentation from URL and save to local file.
    
    Args:
        url: The documentation URL to fetch
        framework_name: Name of the framework/library for file naming
        
    Returns:
        Metadata dict with title, url, fetch_time
    """
    # Check robots.txt first; log but continue if disallowed to support offline/local usage
    robots_allowed = check_robots_txt(url)
    if not robots_allowed:
        logger.warning("Robots.txt disallows %s; continuing fetch due to explicit user request.", url)
    
    # Polite headers
    headers = {
        'User-Agent': 'CodeInsight-Bot/1.0 (Local documentation indexer)',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    
    # Rate limiting - sleep 1 second before request
    time.sleep(1)
    
    try:
        # Fetch the page
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        # Parse with BeautifulSoup
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Extract title
        title_element = soup.find('title')
        title = title_element.get_text().strip() if title_element else f"{framework_name} Documentation"
        
        # Extract main content
        content = extract_main_content(soup)
        
        output_file = _save_markdown(framework_name, title, url, content)
        fetch_timestamp = time.time()
        
        return {
            "title": title,
            "url": url,
            "fetch_time": fetch_timestamp,
            "file_path": str(output_file),
            "content_length": len(content),
            "robots_allowed": robots_allowed,
            "fallback_used": False,
        }
        
    except requests.RequestException as e:
        fallback = FALLBACK_CONTENT.get(framework_name)
        if fallback:
            logger.warning(
                "Failed to fetch %s (%s); using bundled offline content.",
                url,
                e,
            )
            output_file = _save_markdown(
                framework_name,
                fallback["title"],
                fallback["source"],
                fallback["content"],
            )
            fetch_timestamp = time.time()
            return {
                "title": fallback["title"],
                "url": fallback["source"],
                "fetch_time": fetch_timestamp,
                "file_path": str(output_file),
                "content_length": len(fallback["content"]),
                "robots_allowed": robots_allowed,
                "fallback_used": True,
            }
        raise ValueError(f"Failed to fetch {url}: {e}")
    except Exception as e:
        fallback = FALLBACK_CONTENT.get(framework_name)
        if fallback:
            logger.warning(
                "Processing error for %s (%s); using bundled offline content.",
                url,
                e,
            )
            output_file = _save_markdown(
                framework_name,
                fallback["title"],
                fallback["source"],
                fallback["content"],
            )
            fetch_timestamp = time.time()
            return {
                "title": fallback["title"],
                "url": fallback["source"],
                "fetch_time": fetch_timestamp,
                "file_path": str(output_file),
                "content_length": len(fallback["content"]),
                "robots_allowed": robots_allowed,
                "fallback_used": True,
            }
        raise ValueError(f"Error processing {url}: {e}")
