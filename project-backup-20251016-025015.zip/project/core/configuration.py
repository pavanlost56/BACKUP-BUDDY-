"""
Configuration management system for CodeInsight.
Provides schema validation, migration support, and robust configuration handling.
"""

import yaml
from pathlib import Path
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass
from datetime import datetime
import logging
import shutil
import threading
from copy import deepcopy

from .input_validation import get_validator, ValidationResult
from .error_handling import ConfigurationError, safe_operation, ErrorCategory


@dataclass
class ConfigurationSchema:
    """Schema definition for configuration validation."""
    version: str
    required_fields: List[str]
    optional_fields: Dict[str, Any]
    field_types: Dict[str, type]
    field_validators: Dict[str, Any]


class ConfigurationManager:
    """Robust configuration management with validation and migration."""
    
    def __init__(self, config_dir: Optional[Union[str, Path]] = None):
        self.logger = logging.getLogger("codeinsight.config")
        self.validator = get_validator()
        self._lock = threading.RLock()
        
        if config_dir is not None:
            self.config_dir = Path(config_dir)
            self.user_config_dir = self.config_dir.parent
        else:
            self.user_config_dir = Path.home() / ".codeinsight"
            self.config_dir = self.user_config_dir / "configs"
        
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Check for and copy default configs if user dir is new or empty
        self._initialize_user_configs()
        
        # Configuration schemas by version
        self.schemas = self._setup_schemas()
        self.current_version = "1.1.0"
        
        # Configuration cache
        self._config_cache = {}
        self._cache_timestamps = {}

    def _initialize_user_configs(self):
        """Initialize user config directory with default files if they don't exist."""
        default_config_path = self._get_default_config_path()
        if not default_config_path:
            self.logger.warning("Could not find default configuration files in package.")
            return

        for default_file in default_config_path.glob("*.yaml"):
            user_file = self.config_dir / default_file.name
            if not user_file.exists():
                try:
                    shutil.copy(default_file, user_file)
                    self.logger.info(f"Copied default config: {default_file.name}")
                except Exception as e:
                    self.logger.error(f"Failed to copy default config {default_file.name}: {e}")

    def _get_default_config_path(self) -> Optional[Path]:
        """Find the path to the default configs in the installed package."""
        try:
            # This assumes the default configs are in a 'configs' dir next to this module
            # For a package, it might be in site-packages/codeinsight/configs
            base_path = Path(__file__).parent.parent / "configs"
            if base_path.exists():
                return base_path
            
            # Fallback for development environment
            dev_path = Path.cwd() / "configs"
            if dev_path.exists():
                return dev_path
                
        except Exception as e:
            self.logger.error(f"Error finding default config path: {e}")
        return None
    
    def _setup_schemas(self) -> Dict[str, ConfigurationSchema]:
        """Setup configuration schemas for different versions."""
        return {
            "1.0.0": ConfigurationSchema(
                version="1.0.0",
                required_fields=["frameworks"],
                optional_fields={},
                field_types={
                    "frameworks": dict
                },
                field_validators={
                    "frameworks": self._validate_frameworks_v1
                }
            ),
            "1.1.0": ConfigurationSchema(
                version="1.1.0",
                required_fields=["frameworks", "metadata"],
                optional_fields={
                    "settings": {
                        "default_framework": "react",
                        "max_cache_size_mb": 100,
                        "enable_web_search": True,
                        "rate_limits": {
                            "github": {"requests_per_minute": 60, "requests_per_hour": 5000},
                            "duckduckgo": {"requests_per_minute": 30, "requests_per_hour": 1000}
                        },
                        "ollama": {
                            "default_model": "llama3.2",
                            "base_url": "http://localhost:11434",
                            "temperature": 0.1,
                            "top_p": 0.9,
                            "top_k": 40,
                            "available_models": ["llama3.2", "mistral", "codellama", "llama2"]
                        }
                    }
                },
                field_types={
                    "frameworks": dict,
                    "metadata": dict,
                    "settings": dict
                },
                field_validators={
                    "frameworks": self._validate_frameworks_v1_1,
                    "metadata": self._validate_metadata,
                    "settings": self._validate_settings
                }
            )
        }
    
    @safe_operation(category=ErrorCategory.CONFIG, operation="load_configuration")
    def load_config(self, config_name: str = "docs_sources", 
                   force_reload: bool = False) -> Dict[str, Any]:
        """
        Load configuration with caching and validation.
        
        Args:
            config_name: Name of the configuration file (without extension)
            force_reload: Force reload even if cached
            
        Returns:
            Validated configuration dictionary
        """
        with self._lock:
            config_path = self.config_dir / f"{config_name}.yaml"
            
            # Check cache first
            if not force_reload and config_name in self._config_cache:
                cached_timestamp = self._cache_timestamps.get(config_name, 0)
                file_timestamp = config_path.stat().st_mtime if config_path.exists() else 0
                
                if cached_timestamp >= file_timestamp:
                    return deepcopy(self._config_cache[config_name])
            
            # Load from file
            if not config_path.exists():
                self.logger.warning(f"Configuration file not found: {config_path}")
                default_config = self._create_default_config(config_name)
                if default_config:
                    self.save_config(default_config, config_name)
                    self.logger.info(f"Created default configuration for '{config_name}'")
                    cached_default = self._config_cache.get(config_name, default_config)
                    return deepcopy(cached_default)
                raise FileNotFoundError(
                    f"Configuration file not found and could not create a default for: {config_path}"
                )
    
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config_data = yaml.safe_load(f)
                
                if config_data is None:
                    config_data = {}
                
                # Validate and migrate if needed
                validated_config = self._validate_and_migrate(config_data, config_name)
                
                # Cache the result
                self._config_cache[config_name] = deepcopy(validated_config)
                self._cache_timestamps[config_name] = datetime.now().timestamp()
                
                return deepcopy(validated_config)
                
            except yaml.YAMLError as e:
                raise ConfigurationError(f"Invalid YAML in {config_path}: {e}")
            except Exception as e:
                raise ConfigurationError(f"Failed to load configuration {config_path}: {e}")
    
    @safe_operation(category=ErrorCategory.CONFIG, operation="save_configuration")
    def save_config(self, config_data: Dict[str, Any], 
                   config_name: str = "docs_sources") -> bool:
        """
        Save configuration with validation and backup.
        
        Args:
            config_data: Configuration data to save
            config_name: Name of the configuration file
            
        Returns:
            True if saved successfully
        """
        with self._lock:
            config_path = self.config_dir / f"{config_name}.yaml"
            
            # Validate before saving
            validated_config = self._validate_and_migrate(config_data, config_name)
            
            # Create backup if file exists
            if config_path.exists():
                backup_path = config_path.with_suffix(
                    f'.yaml.backup.{int(datetime.now().timestamp())}'
                )
                shutil.copy2(config_path, backup_path)
                
                # Keep only last 5 backups
                self._cleanup_backups(config_path)
            else:
                self.logger.info(f"Creating new configuration file: {config_path}")
            
            # Save configuration
            try:
                with open(config_path, 'w', encoding='utf-8') as f:
                    yaml.dump(
                        validated_config,
                        f,
                        default_flow_style=False,
                        allow_unicode=True,
                        sort_keys=False,
                    )
                
                # Update cache
                self._config_cache[config_name] = deepcopy(validated_config)
                self._cache_timestamps[config_name] = datetime.now().timestamp()
                
                self.logger.info(f"Configuration saved: {config_path}")
                return True
                
            except Exception as e:
                raise ConfigurationError(f"Failed to save configuration {config_path}: {e}")

    def _cleanup_backups(self, config_path: Path, max_backups: int = 5) -> None:
        """Maintain only the most recent backup files for a configuration."""
        try:
            pattern = f"{config_path.name}.backup.*"
            backups = sorted(
                config_path.parent.glob(pattern),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            
            for backup in backups[max_backups:]:
                try:
                    backup.unlink(missing_ok=True)
                except TypeError:
                    # Python < 3.8 compatibility: retry without missing_ok
                    try:
                        backup.unlink()
                    except FileNotFoundError:
                        continue
        except Exception as exc:
            self.logger.warning(
                f"Failed to cleanup backups for {config_path.name}: {exc}"
            )

    def _validate_and_migrate(self, config_data: Dict[str, Any], 
                            config_name: str) -> Dict[str, Any]:
        """Validate configuration and migrate if needed."""
        config_copy = deepcopy(config_data) if config_data is not None else {}
        
        # Detect version
        detected_version = self._detect_version(config_copy)
        
        # Migrate if needed
        if detected_version != self.current_version:
            self.logger.info(f"Migrating configuration from {detected_version} to {self.current_version}")
            config_copy = self._migrate_config(config_copy, detected_version, self.current_version)
        
        # Validate against current schema
        return self._validate_config(config_copy)
    
    def _detect_version(self, config_data: Dict[str, Any]) -> str:
        """Detect configuration version based on structure."""
        # Check for explicit version
        if "metadata" in config_data and "version" in config_data["metadata"]:
            return config_data["metadata"]["version"]
        
        # Detect based on structure
        if "metadata" in config_data:
            return "1.1.0"
        elif "frameworks" in config_data:
            return "1.0.0"
        else:
            return "1.0.0"  # Default to oldest supported version
    
    def _migrate_config(self, config_data: Dict[str, Any], 
                       from_version: str, to_version: str) -> Dict[str, Any]:
        """Migrate configuration between versions."""
        if from_version == "1.0.0" and to_version == "1.1.0":
            return self._migrate_1_0_to_1_1(config_data)
        
        # No migration path found
        self.logger.warning(f"No migration path from {from_version} to {to_version}")
        return config_data
    
    def _migrate_1_0_to_1_1(self, config_data: Dict[str, Any]) -> Dict[str, Any]:
        """Migrate from version 1.0.0 to 1.1.0."""
        migrated = deepcopy(config_data)
        
        # Add metadata section
        if "metadata" not in migrated:
            migrated["metadata"] = {
                "version": "1.1.0",
                "created_at": datetime.now().isoformat(),
                "last_updated": datetime.now().isoformat(),
                "description": "CodeInsight documentation sources configuration"
            }
        else:
            migrated["metadata"]["version"] = "1.1.0"

        
        # Add default settings if not present
        if "settings" not in migrated:
            migrated["settings"] = deepcopy(self.schemas["1.1.0"].optional_fields["settings"])
        
        return migrated
    
    def _validate_config(self, config_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate configuration against schema."""
        if not isinstance(config_data, dict):
            raise ConfigurationError("Configuration data must be a dictionary.")
        
        config = deepcopy(config_data)
        version = self._detect_version(config_data)
        if version not in self.schemas:
            raise ConfigurationError(f"Unsupported configuration version: {version}")
        
        schema = self.schemas[version]

        # Ensure optional fields have defaults
        for field, default_value in schema.optional_fields.items():
            if field not in config:
                config[field] = deepcopy(default_value)
        
        # Check for required fields
        for field in schema.required_fields:
            if field not in config:
                raise ConfigurationError(f"Missing required field: {field}")
        
        # Validate field types and values
        for field, expected_type in schema.field_types.items():
            if field in config and not isinstance(config[field], expected_type):
                raise ConfigurationError(
                    f"Invalid type for '{field}'. Expected {expected_type}, got {type(config[field])}"
                )
        
        for field, validator_func in schema.field_validators.items():
            if field in config:
                result = validator_func(config[field])
                
                if isinstance(result, ValidationResult):
                    if not result.is_valid:
                        error_message = "; ".join(result.errors) if result.errors else "unknown validation error"
                        raise ConfigurationError(f"Validation failed for '{field}': {error_message}")
                    
                    if result.cleaned_value is not None:
                        config[field] = result.cleaned_value
                else:
                    # Backwards compatibility for validators returning tuple
                    try:
                        is_valid, cleaned_or_message = result
                    except (TypeError, ValueError):
                        raise ConfigurationError(
                            f"Validator for '{field}' returned unexpected result: {result}"
                        )
                    
                    if not is_valid:
                        raise ConfigurationError(f"Validation failed for '{field}': {cleaned_or_message}")
                    
                    if cleaned_or_message is not None and not isinstance(cleaned_or_message, str):
                        config[field] = cleaned_or_message
        
        return config

    def _validate_frameworks_common(
        self,
        frameworks: Dict[str, Any],
        *,
        allow_metadata: bool,
    ) -> ValidationResult:
        """Shared validation logic for framework dictionaries."""
        if not isinstance(frameworks, dict):
            return ValidationResult(
                is_valid=False,
                errors=["Framework definitions must be provided as a dictionary."],
            )
        
        errors: List[str] = []
        warnings: List[str] = []
        cleaned_frameworks: Dict[str, Any] = {}
        
        for name, config in frameworks.items():
            name_result = self.validator.validate_by_type(name, "filename")
            if not name_result.is_valid:
                errors.extend([f"Framework name '{name}': {err}" for err in name_result.errors])
                continue
            
            if not isinstance(config, dict):
                errors.append(f"Framework '{name}' configuration must be a dictionary.")
                continue
            
            if "url" not in config:
                errors.append(f"Framework '{name}' missing required 'url' field.")
                continue
            
            url_result = self.validator.validate_by_type(config["url"], "url")
            if not url_result.is_valid:
                errors.extend([f"Framework '{name}' URL: {err}" for err in url_result.errors])
                continue
            
            cleaned_config: Dict[str, Any] = {
                "url": url_result.cleaned_value,
                "description": str(
                    config.get("description", f"{name_result.cleaned_value} framework")
                ),
            }
            
            # Preserve optional metadata fields for v1.1 schemas
            if allow_metadata:
                metadata = config.get("metadata")
                if metadata:
                    if isinstance(metadata, dict):
                        cleaned_config["metadata"] = deepcopy(metadata)
                    else:
                        warnings.append(
                            f"Ignoring non-dictionary metadata for framework '{name}'."
                        )
                
                tags = config.get("tags")
                if tags is not None:
                    if isinstance(tags, (list, tuple, set)):
                        cleaned_config["tags"] = list(tags)
                    else:
                        warnings.append(
                            f"Ignoring tags for framework '{name}' because it is not a sequence."
                        )
                
                last_updated = config.get("last_updated")
                if last_updated:
                    try:
                        datetime.fromisoformat(str(last_updated))
                        cleaned_config["last_updated"] = str(last_updated)
                    except ValueError:
                        warnings.append(
                            f"Ignoring invalid last_updated timestamp for framework '{name}'."
                        )
                
                extra_fields = {
                    key: value
                    for key, value in config.items()
                    if key not in {"url", "description", "metadata", "tags", "last_updated"}
                }
                for key, value in extra_fields.items():
                    cleaned_config[key] = value
            else:
                # Preserve any additional fields while maintaining backwards compatibility
                extra_fields = {
                    key: value
                    for key, value in config.items()
                    if key not in {"url", "description"}
                }
                for key, value in extra_fields.items():
                    cleaned_config[key] = value
            
            cleaned_frameworks[name_result.cleaned_value] = cleaned_config
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            cleaned_value=cleaned_frameworks,
            errors=errors,
            warnings=warnings,
        )
    
    def _validate_frameworks_v1(self, frameworks: Dict[str, Any]) -> ValidationResult:
        """Validate frameworks configuration for version 1.0.0."""
        return self._validate_frameworks_common(frameworks, allow_metadata=False)
    
    def _validate_frameworks_v1_1(self, frameworks: Dict[str, Any]) -> ValidationResult:
        """Validator for the 'frameworks' dictionary in v1.1."""
        return self._validate_frameworks_common(frameworks, allow_metadata=True)

    def _validate_metadata(self, metadata: Dict[str, Any]) -> ValidationResult:
        """Validator for the 'metadata' dictionary."""
        if metadata is None:
            metadata = {}
        
        if not isinstance(metadata, dict):
            return ValidationResult(
                is_valid=False,
                errors=["Metadata must be provided as a dictionary."],
            )
        
        cleaned = {}
        errors: List[str] = []
        warnings: List[str] = []
        
        version = metadata.get("version", self.current_version)
        cleaned["version"] = str(version)
        
        for timestamp_key in ("created_at", "last_updated"):
            value = metadata.get(timestamp_key)
            if value is None:
                cleaned[timestamp_key] = datetime.now().isoformat()
                continue
            
            try:
                datetime.fromisoformat(str(value))
                cleaned[timestamp_key] = str(value)
            except ValueError:
                errors.append(f"Metadata field '{timestamp_key}' must be an ISO8601 timestamp.")
        
        description = metadata.get("description")
        if description is not None:
            cleaned["description"] = str(description)
        else:
            cleaned["description"] = ""
        
        # Preserve any additional metadata fields verbatim
        for key, value in metadata.items():
            if key in cleaned:
                continue
            cleaned[key] = value
        
        if errors:
            return ValidationResult(is_valid=False, errors=errors)
        
        return ValidationResult(
            is_valid=True,
            cleaned_value=cleaned,
            warnings=warnings,
        )

    def _validate_settings(self, settings: Dict[str, Any]) -> ValidationResult:
        """Validator for the 'settings' dictionary."""
        default_settings = deepcopy(
            self.schemas["1.1.0"].optional_fields.get("settings", {})
        )
        
        if settings is None:
            settings = {}
        
        if not isinstance(settings, dict):
            return ValidationResult(
                is_valid=False,
                errors=["Settings must be provided as a dictionary."],
            )
        
        cleaned = deepcopy(default_settings)
        warnings: List[str] = []
        
        for key, value in settings.items():
            if key == "default_framework":
                result = self.validator.validate_by_type(value, "filename")
                if result.is_valid:
                    cleaned[key] = result.cleaned_value
                else:
                    warnings.extend([f"default_framework: {err}" for err in result.errors])
            elif key == "max_cache_size_mb":
                try:
                    size_value = int(value)
                    if size_value <= 0:
                        warnings.append(
                            "max_cache_size_mb must be positive; falling back to default."
                        )
                    else:
                        cleaned[key] = size_value
                except (TypeError, ValueError):
                    warnings.append(
                        "max_cache_size_mb could not be interpreted as an integer; using default."
                    )
            elif key == "rate_limits" and isinstance(value, dict):
                cleaned_limits = {}
                for service, limits in value.items():
                    if not isinstance(limits, dict):
                        warnings.append(f"Ignoring malformed rate limit for '{service}'.")
                        continue
                    
                    try:
                        rpm = int(limits.get("requests_per_minute", 0))
                        rph = int(limits.get("requests_per_hour", 0))
                        if rpm <= 0 or rph <= 0:
                            warnings.append(
                                f"Rate limits for '{service}' must be positive integers; skipping."
                            )
                            continue
                        cleaned_limits[service] = {
                            "requests_per_minute": rpm,
                            "requests_per_hour": rph,
                        }
                    except (TypeError, ValueError):
                        warnings.append(
                            f"Rate limits for '{service}' contain non-integer values; skipping."
                        )
                if cleaned_limits:
                    cleaned["rate_limits"].update(cleaned_limits)
            elif key == "ollama" and isinstance(value, dict):
                cleaned["ollama"].update(value)
            else:
                cleaned[key] = value
        
        return ValidationResult(
            is_valid=True,
            cleaned_value=cleaned,
            warnings=warnings,
        )

    def _create_default_config(self, config_name: str) -> Dict[str, Any]:
        """Create a default configuration dictionary."""
        if config_name == "docs_sources":
            schema = self.schemas[self.current_version]
            return {
                "metadata": {
                    "version": self.current_version,
                    "created_at": datetime.now().isoformat(),
                    "last_updated": datetime.now().isoformat(),
                    "description": "CodeInsight documentation sources configuration"
                },
                "frameworks": {
                    "react": {
                        "url": "https://react.dev/",
                        "description": "React - The library for web and native user interfaces"
                    }
                },
                "settings": deepcopy(schema.optional_fields.get("settings", {}))
            }
        return {}

    def get_configuration_info(self) -> Dict[str, Any]:
        """Get metadata about the current configuration."""
        try:
            config = self.load_config("docs_sources")
            metadata = config.get("metadata", {})
            frameworks = config.get("frameworks", {})
            
            with self._lock:
                cache_status = {
                    "cached_items": len(self._config_cache),
                    "is_warm": len(self._config_cache) > 0,
                    "entries": {
                        name: {
                            "last_loaded": datetime.fromtimestamp(ts).isoformat()
                            if ts
                            else None
                        }
                        for name, ts in self._cache_timestamps.items()
                    },
                }
            
            return {
                "version": metadata.get("version", "N/A"),
                "last_updated": metadata.get("last_updated", "N/A"),
                "framework_count": len(frameworks),
                "config_file": str(self.config_dir / "docs_sources.yaml"),
                "cache_status": cache_status,
            }
        except ConfigurationError as e:
            return {"error": str(e)}
        except Exception as e:
            return {"error": f"An unexpected error occurred: {e}"}

    def get_framework_config(self, framework_name: str) -> Optional[Dict[str, Any]]:
        """Get configuration for a specific framework."""
        config = self.load_config("docs_sources")
        frameworks = config.get("frameworks", {})
        return frameworks.get(framework_name)
    
    def add_framework(self, name: str, url: str, description: str = None) -> bool:
        """Add or update a framework configuration."""
        config = self.load_config("docs_sources")
        
        # Validate inputs
        name_result = self.validator.validate_by_type(name, "filename")
        if not name_result.is_valid:
            raise ConfigurationError(f"Invalid framework name: {', '.join(name_result.errors)}")
        
        url_result = self.validator.validate_by_type(url, "url")
        if not url_result.is_valid:
            raise ConfigurationError(f"Invalid URL: {', '.join(url_result.errors)}")
        
        # Add framework
        if "frameworks" not in config:
            config["frameworks"] = {}
        
        config["frameworks"][name_result.cleaned_value] = {
            "url": url_result.cleaned_value,
            "description": description or f"{name} framework"
        }
        
        self.save_config(config, "docs_sources")
        return True
    
    def remove_framework(self, name: str) -> bool:
        """Remove a framework configuration."""
        config = self.load_config("docs_sources")
        
        if "frameworks" in config and name in config["frameworks"]:
            del config["frameworks"][name]
            self.save_config(config, "docs_sources")
            return True
        return False

    def get_setting(self, key: str, default: Any = None) -> Any:
        """Get a specific setting value."""
        config = self.load_config("docs_sources")
        # Navigate through nested keys e.g. "ollama.default_model"
        keys = key.split('.')
        value = config.get("settings", {})
        for k in keys:
            if not isinstance(value, dict):
                return default
            value = value.get(k)
            if value is None:
                return default
        return value

    def update_setting(self, key: str, value: Any):
        """Update a specific setting value."""
        config = self.load_config("docs_sources")
        keys = key.split('.')
        
        # Navigate to the parent dictionary
        d = config.setdefault("settings", {})
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        
        # Set the value
        d[keys[-1]] = value
        
        self.save_config(config, "docs_sources")

# Singleton instance
_config_manager = None

def get_config_manager() -> ConfigurationManager:
    """Get the singleton instance of the ConfigurationManager."""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigurationManager()
    return _config_manager
