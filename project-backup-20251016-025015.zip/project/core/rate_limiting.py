"""
Rate limiting and throttling system for CodeInsight API calls.
Prevents hitting API limits and implements intelligent backoff strategies.
"""

import time
import asyncio
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict, deque
import threading
import requests
from functools import wraps
import logging


@dataclass
class RateLimit:
    """Rate limit configuration."""
    requests_per_minute: int
    requests_per_hour: int
    burst_limit: int = 10
    backoff_factor: float = 2.0
    max_backoff: float = 300.0  # 5 minutes max
    retry_attempts: int = 3


@dataclass 
class APICallRecord:
    """Record of an API call."""
    timestamp: datetime
    endpoint: str
    success: bool
    response_time: float
    status_code: Optional[int] = None


class RateLimiter:
    """Intelligent rate limiter with adaptive throttling."""
    
    def __init__(self):
        self.api_limits = self._setup_api_limits()
        self.call_history = defaultdict(deque)  # endpoint -> deque of timestamps
        self.backoff_state = defaultdict(float)  # endpoint -> current backoff delay
        self.lock = threading.RLock()
        self.logger = logging.getLogger("codeinsight.ratelimiter")
        
        # Statistics
        self.stats = defaultdict(lambda: {
            "total_calls": 0,
            "throttled_calls": 0,
            "failed_calls": 0,
            "avg_response_time": 0.0
        })
    
    def _setup_api_limits(self) -> Dict[str, RateLimit]:
        """Setup rate limits for different APIs."""
        return {
            "github": RateLimit(
                requests_per_minute=60,
                requests_per_hour=5000,
                burst_limit=10,
                backoff_factor=2.0,
                max_backoff=300.0,
                retry_attempts=3
            ),
            "duckduckgo": RateLimit(
                requests_per_minute=30,
                requests_per_hour=1000,
                burst_limit=5,
                backoff_factor=1.5,
                max_backoff=120.0,
                retry_attempts=2
            ),
            "web_scraping": RateLimit(
                requests_per_minute=20,
                requests_per_hour=500,
                burst_limit=3,
                backoff_factor=2.0,
                max_backoff=180.0,
                retry_attempts=2
            ),
            "default": RateLimit(
                requests_per_minute=40,
                requests_per_hour=1000,
                burst_limit=5,
                backoff_factor=2.0,
                max_backoff=120.0,
                retry_attempts=2
            )
        }
    
    def get_api_type(self, url: str) -> str:
        """Determine API type from URL."""
        url_lower = url.lower()
        
        if "github.com" in url_lower or "api.github.com" in url_lower:
            return "github"
        elif "duckduckgo.com" in url_lower:
            return "duckduckgo"
        elif any(domain in url_lower for domain in ["docs.", "documentation", "guide"]):
            return "web_scraping"
        else:
            return "default"
    
    def check_rate_limit(self, endpoint: str) -> tuple[bool, float]:
        """
        Check if request is allowed under rate limits.
        
        Args:
            endpoint: API endpoint identifier
            
        Returns:
            Tuple of (allowed, wait_time_seconds)
        """
        with self.lock:
            api_type = self.get_api_type(endpoint)
            rate_limit = self.api_limits[api_type]
            now = datetime.now()
            
            # Clean old records
            self._clean_old_records(endpoint, now)
            
            call_times = self.call_history[endpoint]
            
            # Check minute limit
            minute_ago = now - timedelta(minutes=1)
            recent_calls = len([t for t in call_times if t > minute_ago])
            
            if recent_calls >= rate_limit.requests_per_minute:
                wait_time = 60.0 - (now - min(call_times)).total_seconds()
                return False, max(wait_time, 1.0)
            
            # Check hour limit
            hour_ago = now - timedelta(hours=1)
            hourly_calls = len([t for t in call_times if t > hour_ago])
            
            if hourly_calls >= rate_limit.requests_per_hour:
                wait_time = 3600.0 - (now - min(call_times)).total_seconds()
                return False, max(wait_time, 60.0)
            
            # Check burst limit
            last_10_seconds = now - timedelta(seconds=10)
            burst_calls = len([t for t in call_times if t > last_10_seconds])
            
            if burst_calls >= rate_limit.burst_limit:
                return False, 10.0
            
            return True, 0.0
    
    def _clean_old_records(self, endpoint: str, now: datetime):
        """Remove old call records to keep memory usage reasonable."""
        call_times = self.call_history[endpoint]
        hour_ago = now - timedelta(hours=1)
        
        # Remove calls older than 1 hour
        while call_times and call_times[0] <= hour_ago:
            call_times.popleft()
    
    def record_call(self, endpoint: str, success: bool, response_time: float, 
                   status_code: Optional[int] = None):
        """Record an API call for rate limiting and statistics."""
        with self.lock:
            now = datetime.now()
            
            # Record timestamp
            self.call_history[endpoint].append(now)
            
            # Update statistics
            api_type = self.get_api_type(endpoint)
            stats = self.stats[api_type]
            stats["total_calls"] += 1
            
            if not success:
                stats["failed_calls"] += 1
                # Increase backoff for failed calls
                self._increase_backoff(endpoint)
            else:
                # Decrease backoff for successful calls
                self._decrease_backoff(endpoint)
            
            # Update average response time
            old_avg = stats["avg_response_time"]
            total_calls = stats["total_calls"]
            stats["avg_response_time"] = (old_avg * (total_calls - 1) + response_time) / total_calls
    
    def _increase_backoff(self, endpoint: str):
        """Increase backoff delay for endpoint."""
        api_type = self.get_api_type(endpoint)
        rate_limit = self.api_limits[api_type]
        
        current_backoff = self.backoff_state[endpoint]
        if current_backoff == 0:
            self.backoff_state[endpoint] = 1.0
        else:
            self.backoff_state[endpoint] = min(
                current_backoff * rate_limit.backoff_factor,
                rate_limit.max_backoff
            )
    
    def _decrease_backoff(self, endpoint: str):
        """Decrease backoff delay for successful calls."""
        current_backoff = self.backoff_state[endpoint]
        if current_backoff > 0:
            self.backoff_state[endpoint] = max(0, current_backoff * 0.5)
    
    def get_backoff_delay(self, endpoint: str) -> float:
        """Get current backoff delay for endpoint."""
        return self.backoff_state.get(endpoint, 0.0)
    
    def wait_if_needed(self, endpoint: str) -> bool:
        """
        Wait if rate limit requires it.
        
        Args:
            endpoint: API endpoint
            
        Returns:
            True if request can proceed, False if should be skipped
        """
        # Check backoff first
        backoff_delay = self.get_backoff_delay(endpoint)
        if backoff_delay > 0:
            self.logger.info(f"Backoff delay: {backoff_delay:.1f}s for {endpoint}")
            time.sleep(backoff_delay)
        
        # Check rate limits
        allowed, wait_time = self.check_rate_limit(endpoint)
        
        if not allowed:
            if wait_time > 60:  # Don't wait more than 1 minute
                self.logger.warning(f"Rate limit exceeded for {endpoint}, wait time: {wait_time:.1f}s")
                self.stats[self.get_api_type(endpoint)]["throttled_calls"] += 1
                return False
            
            self.logger.info(f"Rate limit waiting: {wait_time:.1f}s for {endpoint}")
            time.sleep(wait_time)
            self.stats[self.get_api_type(endpoint)]["throttled_calls"] += 1
        
        return True
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get rate limiting statistics."""
        with self.lock:
            return {
                "api_stats": dict(self.stats),
                "active_endpoints": len(self.call_history),
                "backoff_states": dict(self.backoff_state),
                "rate_limits": {k: {
                    "requests_per_minute": v.requests_per_minute,
                    "requests_per_hour": v.requests_per_hour,
                    "burst_limit": v.burst_limit
                } for k, v in self.api_limits.items()}
            }


def rate_limited(endpoint: str = None, api_type: str = None):
    """
    Decorator for rate-limited API calls.
    
    Args:
        endpoint: Specific endpoint identifier
        api_type: API type (github, duckduckgo, etc.)
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            rate_limiter = get_rate_limiter()
            
            # Determine endpoint
            call_endpoint = endpoint
            if not call_endpoint:
                # Try to extract from args/kwargs
                if args and isinstance(args[0], str) and args[0].startswith('http'):
                    call_endpoint = args[0]
                elif 'url' in kwargs:
                    call_endpoint = kwargs['url']
                else:
                    call_endpoint = f"{func.__module__}.{func.__name__}"
            
            # Wait if rate limited
            if not rate_limiter.wait_if_needed(call_endpoint):
                # Return rate limited response
                return {
                    "success": False,
                    "error": "Rate limit exceeded",
                    "rate_limited": True,
                    "suggestion": "Please try again later"
                }
            
            # Execute function with timing
            start_time = time.time()
            success = False
            status_code = None
            
            try:
                result = func(*args, **kwargs)
                success = True
                
                # Extract status code if it's a requests response
                if hasattr(result, 'status_code'):
                    status_code = result.status_code
                elif isinstance(result, dict) and 'status_code' in result:
                    status_code = result['status_code']
                
                return result
                
            except Exception as e:
                success = False
                # Try to extract status code from requests exceptions
                if hasattr(e, 'response') and hasattr(e.response, 'status_code'):
                    status_code = e.response.status_code
                raise
                
            finally:
                response_time = time.time() - start_time
                rate_limiter.record_call(call_endpoint, success, response_time, status_code)
        
        return wrapper
    return decorator


class RequestSession:
    """Enhanced requests session with rate limiting and retry logic."""
    
    def __init__(self):
        self.session = requests.Session()
        self.rate_limiter = get_rate_limiter()
        
        # Set reasonable defaults
        self.session.headers.update({
            'User-Agent': 'CodeInsight/1.0 (Educational Tool)'
        })
        
        # Configure timeouts
        self.default_timeout = (10, 30)  # (connect, read)
    
    @rate_limited()
    def get(self, url: str, **kwargs) -> requests.Response:
        """Rate-limited GET request."""
        kwargs.setdefault('timeout', self.default_timeout)
        return self.session.get(url, **kwargs)
    
    @rate_limited()
    def post(self, url: str, **kwargs) -> requests.Response:
        """Rate-limited POST request."""
        kwargs.setdefault('timeout', self.default_timeout)
        return self.session.post(url, **kwargs)
    
    def close(self):
        """Close the session."""
        self.session.close()


# Global rate limiter instance
_global_rate_limiter = None

def get_rate_limiter() -> RateLimiter:
    """Get the global rate limiter instance."""
    global _global_rate_limiter
    if _global_rate_limiter is None:
        _global_rate_limiter = RateLimiter()
    return _global_rate_limiter


def get_session() -> RequestSession:
    """Get a rate-limited requests session."""
    return RequestSession()