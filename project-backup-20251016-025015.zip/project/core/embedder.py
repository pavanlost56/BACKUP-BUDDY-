"""
Embedding module for creating and managing vector embeddings.
"""

import json
import hashlib
import numpy as np
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle
from typing import List, Dict, Any
import re
from core.performance_monitoring import timed_operation


def chunk_text(text: str, max_tokens: int = 1000) -> List[str]:
    """
    Split text into chunks of approximately max_tokens.
    
    Args:
        text: The text to chunk
        max_tokens: Maximum tokens per chunk (approximated by words)
        
    Returns:
        List of text chunks
    """
    # Simple token approximation: assume ~1.3 words per token
    max_words = int(max_tokens * 0.75)
    
    # Split text into paragraphs first
    paragraphs = text.split('\n\n')
    chunks = []
    current_chunk = ""
    
    for paragraph in paragraphs:
        paragraph = paragraph.strip()
        if not paragraph:
            continue
            
        # Count words in current chunk and paragraph
        current_words = len(current_chunk.split())
        paragraph_words = len(paragraph.split())
        
        # If adding this paragraph would exceed the limit, start a new chunk
        if current_words + paragraph_words > max_words and current_chunk:
            chunks.append(current_chunk.strip())
            current_chunk = paragraph
        else:
            if current_chunk:
                current_chunk += "\n\n" + paragraph
            else:
                current_chunk = paragraph
    
    # Add the last chunk if it's not empty
    if current_chunk.strip():
        chunks.append(current_chunk.strip())
    
    # If no chunks were created, split by sentences as fallback
    if not chunks and text.strip():
        sentences = re.split(r'[.!?]+', text)
        current_chunk = ""
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
                
            current_words = len(current_chunk.split())
            sentence_words = len(sentence.split())
            
            if current_words + sentence_words > max_words and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = sentence
            else:
                if current_chunk:
                    current_chunk += ". " + sentence
                else:
                    current_chunk = sentence
        
        if current_chunk.strip():
            chunks.append(current_chunk.strip())
    
    return chunks if chunks else [text]


def create_embeddings(texts: List[str]) -> tuple:
    """
    Create TF-IDF embeddings for a list of texts.
    
    Args:
        texts: List of text chunks to embed
        
    Returns:
        Tuple of (vectorizer, embeddings_matrix)
    """
    # Adjust parameters based on number of documents
    num_docs = len(texts)
    
    # Use TF-IDF for simple local embeddings
    vectorizer = TfidfVectorizer(
        max_features=min(1000, num_docs * 10),  # Adjust features based on doc count
        stop_words='english',
        ngram_range=(1, 2),
        min_df=1,  # Always 1 for small collections
        max_df=min(0.95, 1.0 - 1/num_docs) if num_docs > 1 else 1.0  # Adjust max_df
    )
    
    # Fit and transform the texts
    embeddings = vectorizer.fit_transform(texts)
    
    return vectorizer, embeddings


def save_embeddings_db(framework_name: str, chunks: List[str], vectorizer, embeddings, 
                      source_file: str, persist_dir: str = "data/db") -> dict:
    """
    Save embeddings and metadata to local JSON-based database.
    
    Args:
        framework_name: Name of the framework
        chunks: List of text chunks
        vectorizer: Trained TF-IDF vectorizer
        embeddings: Embedding matrix
        source_file: Path to source documentation file
        persist_dir: Directory to persist the database
        
    Returns:
        Metadata about the saved embeddings
    """
    persist_path = Path(persist_dir)
    persist_path.mkdir(parents=True, exist_ok=True)
    
    # Create framework-specific files
    framework_dir = persist_path / framework_name
    framework_dir.mkdir(exist_ok=True)
    
    # Save chunks with metadata
    chunks_data = []
    for i, chunk in enumerate(chunks):
        chunk_id = f"chunk_{i}"
        chunk_hash = hashlib.md5(chunk.encode()).hexdigest()[:8]
        
        chunks_data.append({
            "id": chunk_id,
            "content": chunk,
            "hash": chunk_hash,
            "source_file": source_file,
            "chunk_index": i
        })
    
    # Save chunks metadata
    with open(framework_dir / "chunks.json", "w", encoding="utf-8") as f:
        json.dump(chunks_data, f, indent=2, ensure_ascii=False)
    
    # Save vectorizer
    with open(framework_dir / "vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)
    
    # Save embeddings as numpy array
    embeddings_dense = embeddings.toarray()
    np.save(framework_dir / "embeddings.npy", embeddings_dense)
    
    # Save metadata
    metadata = {
        "framework": framework_name,
        "num_chunks": len(chunks),
        "embedding_dim": embeddings.shape[1],
        "source_file": source_file,
        "created_at": str(Path(source_file).stat().st_mtime) if Path(source_file).exists() else None
    }
    
    with open(framework_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    
    return metadata


@timed_operation("build_embeddings")
def build_embeddings(framework_name: str, docs_dir: str = "data/docs", persist_dir: str = "data/db") -> dict:
    """
    Build embeddings from documentation and store in local database.
    
    Args:
        framework_name: Name of the framework to process
        docs_dir: Directory containing documentation files
        persist_dir: Directory to persist the vector database
        
    Returns:
        Metadata about the embedding process
    """
    # Read the documentation file
    docs_path = Path(docs_dir)
    doc_file = docs_path / f"{framework_name}.md"
    
    if not doc_file.exists():
        raise FileNotFoundError(f"Documentation file not found: {doc_file}")
    
    with open(doc_file, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Chunk the text
    chunks = chunk_text(content, max_tokens=1000)
    
    if not chunks:
        raise ValueError(f"No text chunks extracted from {doc_file}")
    
    # Create embeddings
    vectorizer, embeddings = create_embeddings(chunks)
    
    # Save to database
    metadata = save_embeddings_db(
        framework_name, chunks, vectorizer, embeddings, 
        str(doc_file), persist_dir
    )
    
    return {
        "framework": framework_name,
        "status": "embeddings_created",
        "vectors_count": len(chunks),
        "embedding_dim": embeddings.shape[1],
        "source_file": str(doc_file)
    }