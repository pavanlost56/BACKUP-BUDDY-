"""Conversation orchestration for Gemini-style CLI experience."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from .configuration import get_config_manager
from .llm_client import get_llm_client


@dataclass
class ConversationDirective:
    """Instruction returned by the conversation engine."""

    action: str
    command: Optional[List[str]] = None
    response: Optional[str] = None
    reasoning: Optional[str] = None
    confidence: float = 0.0


class ConversationEngine:
    """Maps natural language input to CLI actions or responses."""

    def __init__(
        self,
        config_manager=None,
        llm_client=None,
        history_limit: int = 10,
    ) -> None:
        self.config_manager = config_manager or get_config_manager()
        self.llm_client = llm_client or get_llm_client()
        self.history: List[Dict[str, str]] = []
        self.history_limit = history_limit
        self.available_commands = {
            "agent": ["agent"],
            "query": ["query"],
            "update": ["update"],
            "model": ["model"],
            "perf": ["perf"],
        }

    def register_history(self, role: str, content: str) -> None:
        """Persist a turn in conversation history."""
        self.history.append({"role": role, "content": content})
        if len(self.history) > self.history_limit:
            self.history = self.history[-self.history_limit :]

    def interpret(self, user_input: str) -> ConversationDirective:
        """Infer the best action for a free-form user message."""
        cleaned = user_input.strip()
        if not cleaned:
            return ConversationDirective(
                action="respond",
                response="I didn't catch that. Try asking about docs or request the agent to help.",
                reasoning="empty_input",
                confidence=0.1,
            )

        directive = self._heuristic_route(cleaned, allow_general=False)
        if directive:
            self.register_history("user", cleaned)
            return directive

        status = self._get_llm_status()
        directive = self._llm_route(cleaned, status=status)
        if directive:
            self.register_history("user", cleaned)
            return directive

        directive = self._heuristic_route(cleaned, allow_general=True)
        if directive:
            self.register_history("user", cleaned)
            return directive

        return ConversationDirective(
            action="respond",
            response="I'm not sure how to help with that yet. Try 'query <topic>' or 'agent <task>'.",
            reasoning="no_route",
            confidence=0.0,
        )

    def _heuristic_route(
        self,
        message: str,
        allow_general: bool = True,
    ) -> Optional[ConversationDirective]:
        """Fast heuristics for common requests when LLM is unavailable."""
        lowered = message.lower()

        if lowered.startswith("query "):
            query = message.split(" ", 1)[1]
            return ConversationDirective(
                action="command",
                command=["query", query],
                reasoning="heuristic_prefix_query",
                confidence=0.9,
            )

        if lowered.startswith("agent "):
            prompt = message.split(" ", 1)[1]
            return ConversationDirective(
                action="command",
                command=["agent", prompt],
                reasoning="heuristic_prefix_agent",
                confidence=0.9,
            )

        if lowered.startswith("update "):
            framework = message.split(" ", 1)[1]
            return ConversationDirective(
                action="command",
                command=["update", framework],
                reasoning="heuristic_prefix_update",
                confidence=0.8,
            )

        if lowered in {"models", "list models"}:
            return ConversationDirective(
                action="command",
                command=["model", "list"],
                reasoning="heuristic_list_models",
                confidence=0.7,
            )

        if not allow_general:
            return None

        # Question style -> query
        if lowered.endswith("?") or any(word in lowered for word in ["how", "what", "docs", "documentation"]):
            return ConversationDirective(
                action="command",
                command=["query", message],
                reasoning="heuristic_question_query",
                confidence=0.6,
            )

        # Task style -> agent
        if any(word in lowered for word in ["build", "fix", "create", "implement", "help me", "draft", "plan"]):
            return ConversationDirective(
                action="command",
                command=["agent", message],
                reasoning="heuristic_task_agent",
                confidence=0.6,
            )

        return None

    def _get_llm_status(self) -> Dict[str, Optional[int]]:
        """Fetch LLM connection status safely."""
        try:
            status = self.llm_client.get_connection_status()
            if not isinstance(status, dict):
                return {}
            return status
        except Exception:
            return {}

    def _llm_route(
        self,
        message: str,
        status: Optional[Dict[str, Optional[int]]] = None,
    ) -> Optional[ConversationDirective]:
        """Use the LLM to propose an action when available."""
        status = status or self._get_llm_status()
        if not status.get("connected") or status.get("model_count", 0) == 0:
            return None

        system_prompt = (
            "You are the CodeInsight conversation router. "
            "Decide how to help the developer using available CLI actions. "
            "Allowed actions: 'query', 'agent', 'update', 'model', 'perf', or 'respond'. "
            "Return strict JSON with keys: action, command (array), reasoning, confidence (0-1). "
            "Use action 'respond' to reply inline without running a command."
        )

        history_lines = [
            f"{turn['role'].upper()}: {turn['content']}" for turn in self.history[-5 :]
        ]
        history_text = "\n".join(history_lines)

        payload = (
            f"SYSTEM:\n{system_prompt}\n\n"
            f"HISTORY:\n{history_text}\n\n"
            f"USER:\n{message}\n"
            "Respond with JSON only."
        )

        try:
            raw_response = self.llm_client.call_ollama_generate(payload)
        except Exception:
            return None

        json_match = re.search(r"\{.*\}", raw_response, re.DOTALL)
        if not json_match:
            return None

        try:
            data = json.loads(json_match.group())
        except json.JSONDecodeError:
            return None

        action = data.get("action")
        reasoning = data.get("reasoning")
        confidence = float(data.get("confidence", 0.5))

        if action == "respond":
            return ConversationDirective(
                action="respond",
                response=data.get("response") or data.get("message") or "Let me know how else I can help.",
                reasoning=reasoning or "llm_response",
                confidence=confidence,
            )

        command_tokens = data.get("command")
        if isinstance(command_tokens, list) and command_tokens:
            return ConversationDirective(
                action="command",
                command=[str(token) for token in command_tokens],
                reasoning=reasoning or "llm_command",
                confidence=confidence,
            )

        return None


def get_conversation_engine() -> ConversationEngine:
    """Factory for shared conversation engine."""
    return ConversationEngine()
