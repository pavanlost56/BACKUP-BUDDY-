"""
Robust error handling and recovery system for CodeInsight.
Provides comprehensive error management, recovery strategies, and user-friendly error reporting.
"""

import logging
import traceback
import sys
from typing import Dict, Any, Optional, Callable, Union
from functools import wraps
from dataclasses import dataclass
from enum import Enum
import time
import requests
from pathlib import Path


class ErrorSeverity(Enum):
    """Error severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ErrorCategory(Enum):
    """Error categories for better classification."""
    NETWORK = "network"
    FILE_SYSTEM = "file_system"
    CONFIG = "configuration"
    API = "api"
    USER_INPUT = "user_input"
    INTERNAL = "internal"
    DEPENDENCY = "dependency"


@dataclass
class ErrorContext:
    """Context information for error handling."""
    operation: str
    category: ErrorCategory
    severity: ErrorSeverity
    user_message: str
    technical_details: str
    suggestions: list[str]
    recovery_actions: list[str]
    metadata: Optional[Dict[str, Any]] = None


class CodeInsightError(Exception):
    """Base exception class for CodeInsight errors."""
    
    default_category = ErrorCategory.INTERNAL
    default_operation = "operation"
    default_severity = ErrorSeverity.MEDIUM
    
    def __init__(
        self,
        context: Union[ErrorContext, str],
        original_error: Exception = None
    ):
        if isinstance(context, ErrorContext):
            normalized_context = context
        else:
            message = str(context)
            category = getattr(self.__class__, "default_category", ErrorCategory.INTERNAL)
            severity = getattr(self.__class__, "default_severity", ErrorSeverity.MEDIUM)
            operation = getattr(
                self.__class__,
                "default_operation",
                self.__class__.__name__.lower(),
            )
            normalized_context = ErrorContext(
                operation=operation,
                category=category,
                severity=severity,
                user_message=message,
                technical_details=str(original_error) if original_error else message,
                suggestions=[],
                recovery_actions=[],
                metadata=None,
            )
        
        self.context = normalized_context
        self.original_error = original_error
        super().__init__(normalized_context.user_message)


class NetworkError(CodeInsightError):
    """Network-related errors."""
    default_category = ErrorCategory.NETWORK
    default_operation = "network operation"


class FileSystemError(CodeInsightError):
    """File system operation errors."""
    default_category = ErrorCategory.FILE_SYSTEM
    default_operation = "file system operation"


class ConfigurationError(CodeInsightError):
    """Configuration-related errors."""
    default_category = ErrorCategory.CONFIG
    default_operation = "configuration operation"


class APIError(CodeInsightError):
    """API-related errors."""
    default_category = ErrorCategory.API
    default_operation = "api operation"


class UserInputError(CodeInsightError):
    """User input validation errors."""
    default_category = ErrorCategory.USER_INPUT
    default_operation = "user input validation"


class ErrorHandler:
    """Comprehensive error handling and recovery system."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or self._setup_logger()
        self.error_counts = {}
        self.recovery_strategies = self._setup_recovery_strategies()
    
    def _setup_logger(self) -> logging.Logger:
        """Setup dedicated error logging."""
        logger = logging.getLogger("codeinsight.errors")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _setup_recovery_strategies(self) -> Dict[ErrorCategory, Callable]:
        """Setup automatic recovery strategies for different error types."""
        return {
            ErrorCategory.NETWORK: self._recover_network_error,
            ErrorCategory.FILE_SYSTEM: self._recover_filesystem_error,
            ErrorCategory.API: self._recover_api_error,
            ErrorCategory.CONFIG: self._recover_config_error
        }
    
    def handle_error(self, error: Exception, context: ErrorContext) -> Dict[str, Any]:
        """
        Handle errors with appropriate recovery strategies.
        
        Args:
            error: The original exception
            context: Error context information
            
        Returns:
            Recovery result with success status and details
        """
        # Log the error
        self._log_error(error, context)
        
        # Track error frequency
        self._track_error(context)
        
        # Attempt recovery
        recovery_result = self._attempt_recovery(error, context)
        
        # Create user-friendly error report
        error_report = self._create_error_report(error, context, recovery_result)
        
        return error_report
    
    def _log_error(self, error: Exception, context: ErrorContext):
        """Log error with appropriate level based on severity."""
        error_msg = f"{context.operation}: {context.user_message}"
        technical_msg = f"Technical: {context.technical_details}"
        
        if context.severity == ErrorSeverity.CRITICAL:
            self.logger.critical(f"{error_msg} | {technical_msg}", exc_info=error)
        elif context.severity == ErrorSeverity.HIGH:
            self.logger.error(f"{error_msg} | {technical_msg}", exc_info=error)
        elif context.severity == ErrorSeverity.MEDIUM:
            self.logger.warning(f"{error_msg} | {technical_msg}")
        else:
            self.logger.info(f"{error_msg} | {technical_msg}")
    
    def _track_error(self, context: ErrorContext):
        """Track error frequency for pattern analysis."""
        key = f"{context.category.value}:{context.operation}"
        self.error_counts[key] = self.error_counts.get(key, 0) + 1
    
    def _attempt_recovery(self, error: Exception, context: ErrorContext) -> Dict[str, Any]:
        """Attempt automatic recovery based on error category."""
        recovery_strategy = self.recovery_strategies.get(context.category)
        
        if not recovery_strategy:
            return {"success": False, "message": "No recovery strategy available"}
        
        try:
            return recovery_strategy(error, context)
        except Exception as recovery_error:
            self.logger.error(f"Recovery strategy failed: {recovery_error}")
            return {"success": False, "message": "Recovery attempt failed"}
    
    def _recover_network_error(self, error: Exception, context: ErrorContext) -> Dict[str, Any]:
        """Recover from network errors with retry and fallback strategies."""
        if isinstance(error, requests.exceptions.Timeout):
            return {"success": False, "message": "Timeout - try increasing timeout or check connection"}
        
        if isinstance(error, requests.exceptions.ConnectionError):
            # Check if it's a localhost connection (Ollama)
            if "localhost" in str(error) or "127.0.0.1" in str(error):
                return {
                    "success": False,
                    "message": "Local service unavailable",
                    "suggestions": [
                        "Start Ollama service: ollama serve",
                        "Check if port 11434 is available",
                        "Verify Ollama installation"
                    ]
                }
            
            return {
                "success": False,
                "message": "Network connection failed",
                "suggestions": [
                    "Check internet connection",
                    "Try again in a few moments",
                    "Check firewall settings"
                ]
            }
        
        if isinstance(error, requests.exceptions.HTTPError):
            status_code = getattr(error.response, 'status_code', None)
            if status_code == 429:  # Rate limited
                return {
                    "success": False,
                    "message": "Rate limit exceeded",
                    "suggestions": ["Wait before retrying", "Consider using different API endpoint"]
                }
            elif status_code == 404:
                return {
                    "success": False,
                    "message": "Resource not found",
                    "suggestions": ["Verify URL or endpoint", "Check API documentation"]
                }
        
        return {"success": False, "message": "Network error occurred"}
    
    def _recover_filesystem_error(self, error: Exception, context: ErrorContext) -> Dict[str, Any]:
        """Recover from file system errors."""
        if isinstance(error, PermissionError):
            return {
                "success": False,
                "message": "Permission denied",
                "suggestions": [
                    "Check file/directory permissions",
                    "Run with appropriate privileges",
                    "Verify file is not in use by another process"
                ]
            }
        
        if isinstance(error, FileNotFoundError):
            # Try to create parent directories
            if context.metadata and "file_path" in context.metadata:
                try:
                    file_path = Path(context.metadata["file_path"])
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                    return {"success": True, "message": "Created missing directories"}
                except Exception:
                    pass
            
            return {
                "success": False,
                "message": "File or directory not found",
                "suggestions": [
                    "Check file path is correct",
                    "Verify file exists",
                    "Check working directory"
                ]
            }
        
        if isinstance(error, OSError):
            return {
                "success": False,
                "message": "File system error",
                "suggestions": [
                    "Check disk space",
                    "Verify file path length",
                    "Check for file corruption"
                ]
            }
        
        return {"success": False, "message": "File system error occurred"}
    
    def _recover_api_error(self, error: Exception, context: ErrorContext) -> Dict[str, Any]:
        """Recover from API errors."""
        # Similar to network recovery but more API-specific
        return self._recover_network_error(error, context)
    
    def _recover_config_error(self, error: Exception, context: ErrorContext) -> Dict[str, Any]:
        """Recover from configuration errors."""
        if "yaml" in str(error).lower() or "json" in str(error).lower():
            return {
                "success": False,
                "message": "Configuration file format error",
                "suggestions": [
                    "Check YAML/JSON syntax",
                    "Validate configuration file",
                    "Reset to default configuration"
                ]
            }
        
        return {
            "success": False,
            "message": "Configuration error",
            "suggestions": [
                "Check configuration file exists",
                "Verify configuration format",
                "Reset to defaults if needed"
            ]
        }
    
    def _create_error_report(self, error: Exception, context: ErrorContext, 
                           recovery_result: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive error report for user display."""
        return {
            "error_occurred": True,
            "severity": context.severity.value,
            "category": context.category.value,
            "operation": context.operation,
            "user_message": context.user_message,
            "suggestions": context.suggestions + recovery_result.get("suggestions", []),
            "recovery_attempted": True,
            "recovery_successful": recovery_result.get("success", False),
            "recovery_message": recovery_result.get("message", ""),
            "technical_details": context.technical_details if context.severity in [ErrorSeverity.HIGH, ErrorSeverity.CRITICAL] else None,
            "error_id": f"{context.category.value}_{int(time.time())}"
        }
    
    def get_error_statistics(self) -> Dict[str, Any]:
        """Get error statistics for monitoring."""
        total_errors = sum(self.error_counts.values())
        if total_errors == 0:
            return {"total_errors": 0}
        
        most_common = sorted(self.error_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return {
            "total_errors": total_errors,
            "most_common_errors": most_common,
            "unique_error_types": len(self.error_counts),
            "error_frequency": self.error_counts
        }


def safe_operation(category: ErrorCategory, operation: str, severity: ErrorSeverity = ErrorSeverity.MEDIUM):
    """
    Decorator for safe operation execution with automatic error handling.
    
    Args:
        category: Error category
        operation: Operation description
        severity: Error severity level
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            error_handler = ErrorHandler()
            
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if isinstance(e, CodeInsightError):
                    raise
                # Create error context
                operation_label = operation.replace("_", " ")
                context = ErrorContext(
                    operation=operation,
                    category=category,
                    severity=severity,
                    user_message=f"Failed to {operation_label}",
                    technical_details=str(e),
                    suggestions=[
                        "Try the operation again",
                        "Check system requirements",
                        "Contact support if issue persists",
                    ],
                    recovery_actions=[],
                    metadata={"function": func.__name__, "args": str(args), "kwargs": str(kwargs)}
                )
                
                # Handle the error
                error_report = error_handler.handle_error(e, context)
                
                # Re-raise as CodeInsight error for consistent handling
                if category == ErrorCategory.NETWORK:
                    raise NetworkError(context, e)
                elif category == ErrorCategory.FILE_SYSTEM:
                    raise FileSystemError(context, e)
                elif category == ErrorCategory.CONFIG:
                    raise ConfigurationError(context, e)
                elif category == ErrorCategory.API:
                    raise APIError(context, e)
                elif category == ErrorCategory.USER_INPUT:
                    raise UserInputError(context, e)
                else:
                    raise CodeInsightError(context, e)
        
        return wrapper
    return decorator


# Global error handler instance
_global_error_handler = None

def get_error_handler() -> ErrorHandler:
    """Get the global error handler instance."""
    global _global_error_handler
    if _global_error_handler is None:
        _global_error_handler = ErrorHandler()
    return _global_error_handler
