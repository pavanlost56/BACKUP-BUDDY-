"""
Comprehensive logging system for CodeInsight.
Provides structured logging with rotation, levels, performance tracking, and monitoring.
"""

import logging
import logging.handlers
import json
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, Any, Optional, Union, List
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from enum import Enum
import threading
from functools import wraps
import inspect

from .configuration import get_config_manager


class LogLevel(Enum):
    """Log levels with numeric values."""
    TRACE = 5
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50


class LogFormat(Enum):
    """Available log formats."""
    STRUCTURED = "structured"  # JSON format
    HUMAN = "human"           # Human-readable format
    COMPACT = "compact"       # Single line format


@dataclass
class LogEntry:
    """Structured log entry."""
    timestamp: str
    level: str
    logger: str
    message: str
    module: str
    function: str
    line_number: int
    thread_id: str
    process_id: int
    extra: Dict[str, Any] = None
    exception_info: Dict[str, Any] = None
    performance_metrics: Dict[str, Any] = None


class StructuredFormatter(logging.Formatter):
    """Custom formatter for structured JSON logging."""
    
    def format(self, record):
        """Format log record as structured JSON."""
        # Extract caller information
        frame_info = self._get_caller_info()
        
        log_entry = LogEntry(
            timestamp=datetime.now(timezone.utc).isoformat(),
            level=record.levelname,
            logger=record.name,
            message=record.getMessage(),
            module=frame_info.get('module', record.module if hasattr(record, 'module') else ''),
            function=frame_info.get('function', record.funcName),
            line_number=frame_info.get('line_number', record.lineno),
            thread_id=str(threading.get_ident()),
            process_id=os.getpid(),
            extra=getattr(record, 'extra_data', {}),
            performance_metrics=getattr(record, 'performance_metrics', {}),
            exception_info=self._format_exception(record) if record.exc_info else None
        )
        
        return json.dumps(asdict(log_entry), default=str, ensure_ascii=False)
    
    def _get_caller_info(self) -> Dict[str, Any]:
        """Extract caller information from stack."""
        try:
            # Look for the actual caller (skip logging framework calls)
            frame = inspect.currentframe()
            while frame:
                code = frame.f_code
                filename = code.co_filename
                
                # Skip logging system files
                if not any(skip in filename for skip in ['logging', 'logger']):
                    return {
                        'module': Path(filename).stem,
                        'function': code.co_name,
                        'line_number': frame.f_lineno
                    }
                frame = frame.f_back
        except Exception:
            pass
        
        return {'module': '', 'function': '', 'line_number': 0}
    
    def _format_exception(self, record) -> Dict[str, Any]:
        """Format exception information."""
        if not record.exc_info:
            return None
        
        exc_type, exc_value, exc_traceback = record.exc_info
        
        return {
            'type': exc_type.__name__,
            'message': str(exc_value),
            'traceback': traceback.format_exception(exc_type, exc_value, exc_traceback),
            'traceback_string': ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        }


class HumanReadableFormatter(logging.Formatter):
    """Human-readable formatter with colors for console output."""
    
    COLORS = {
        'TRACE': '\033[94m',     # Blue
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
        'RESET': '\033[0m'       # Reset
    }
    
    def __init__(self, use_colors: bool = True):
        super().__init__()
        self.use_colors = use_colors and hasattr(sys.stderr, 'isatty') and sys.stderr.isatty()
    
    def format(self, record):
        """Format log record in human-readable format."""
        # Basic formatting
        timestamp = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S')
        level = record.levelname
        logger_name = record.name.split('.')[-1]  # Use short name
        message = record.getMessage()
        
        # Add color if enabled
        if self.use_colors and level in self.COLORS:
            level = f"{self.COLORS[level]}{level}{self.COLORS['RESET']}"
        
        # Format basic line
        log_line = f"{timestamp} | {level:<8} | {logger_name:<12} | {message}"
        
        # Add extra data if present
        if hasattr(record, 'extra_data') and record.extra_data:
            extras = ', '.join([f"{k}={v}" for k, v in record.extra_data.items()])
            log_line += f" | {extras}"
        
        # Add performance metrics if present
        if hasattr(record, 'performance_metrics') and record.performance_metrics:
            metrics = record.performance_metrics
            if 'duration_ms' in metrics:
                log_line += f" | {metrics['duration_ms']:.2f}ms"
        
        # Add exception info if present
        if record.exc_info:
            log_line += "\n" + self.formatException(record.exc_info)
        
        return log_line


class CompactFormatter(logging.Formatter):
    """Compact single-line formatter."""
    
    def format(self, record):
        """Format log record in compact single-line format."""
        timestamp = datetime.fromtimestamp(record.created).strftime('%H:%M:%S')
        level = record.levelname[0]  # Single character
        message = record.getMessage().replace('\n', ' ')
        
        line = f"{timestamp}|{level}|{message}"
        
        # Add performance info if available
        if hasattr(record, 'performance_metrics') and record.performance_metrics:
            metrics = record.performance_metrics
            if 'duration_ms' in metrics:
                line += f"|{metrics['duration_ms']:.1f}ms"
        
        return line


class PerformanceLogger:
    """Logger for performance tracking and monitoring."""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self._timers = {}
        self._lock = threading.Lock()
    
    def start_timer(self, operation: str, context: Dict[str, Any] = None) -> str:
        """Start a performance timer."""
        timer_id = f"{operation}_{int(time.time() * 1000000)}"
        
        with self._lock:
            self._timers[timer_id] = {
                'operation': operation,
                'start_time': time.perf_counter(),
                'context': context or {}
            }
        
        return timer_id
    
    def end_timer(self, timer_id: str, success: bool = True, extra_metrics: Dict[str, Any] = None):
        """End a performance timer and log metrics."""
        with self._lock:
            if timer_id not in self._timers:
                return
            
            timer_info = self._timers.pop(timer_id)
        
        duration = time.perf_counter() - timer_info['start_time']
        duration_ms = duration * 1000
        
        metrics = {
            'duration_ms': duration_ms,
            'duration_seconds': duration,
            'success': success,
            'operation': timer_info['operation']
        }
        
        if extra_metrics:
            metrics.update(extra_metrics)
        
        self.logger.info(
            f"Performance: {timer_info['operation']} completed",
            extra={
                'extra_data': timer_info['context'],
                'performance_metrics': metrics
            }
        )
    
    def time_operation(self, operation: str, context: Dict[str, Any] = None):
        """Decorator to time function execution."""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                timer_id = self.start_timer(operation, context)
                success = True
                extra_metrics = {}
                
                try:
                    result = func(*args, **kwargs)
                    
                    # Extract metrics from result if it's a dict with metrics
                    if isinstance(result, dict) and 'metrics' in result:
                        extra_metrics = result['metrics']
                    
                    return result
                
                except Exception as e:
                    success = False
                    extra_metrics['error'] = str(e)
                    raise
                
                finally:
                    self.end_timer(timer_id, success, extra_metrics)
            
            return wrapper
        return decorator


class LoggingManager:
    """Central logging management system."""
    
    def __init__(self, log_dir: Optional[Union[str, Path]] = None):
        default_dir = Path.home() / ".codeinsight" / "logs"
        self.log_dir = Path(log_dir) if log_dir else default_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Configuration
        self.config = self._load_logging_config()
        
        # Setup custom log level
        logging.addLevelName(LogLevel.TRACE.value, 'TRACE')
        
        # Initialize loggers
        self.loggers = {}
        self.performance_loggers = {}
        
        # Setup root logger
        self.setup_root_logger()
        
        # Ensure clean shutdown
        import atexit
        atexit.register(self.shutdown)
    
    def _load_logging_config(self) -> Dict[str, Any]:
        """Load logging configuration."""
        try:
            config_manager = get_config_manager()
            config = config_manager.load_config("docs_sources")
            logging_config = config.get("settings", {}).get("logging", {})
        except Exception:
            logging_config = {}
        
        # Default configuration
        default_config = {
            "level": "INFO",
            "format": "human",  # human, structured, compact
            "console_enabled": True,
            "file_enabled": True,
            "file_rotation": {
                "max_bytes": 10 * 1024 * 1024,  # 10MB
                "backup_count": 5
            },
            "performance_tracking": True,
            "structured_logs": {
                "enabled": True,
                "include_stack_trace": False
            }
        }
        
        # Merge with defaults
        for key, value in default_config.items():
            if key not in logging_config:
                logging_config[key] = value
        
        return logging_config
    
    def setup_root_logger(self):
        """Setup the root logger configuration."""
        root_logger = logging.getLogger()
        root_logger.setLevel(getattr(logging, self.config["level"]))
        
        # Clear existing handlers
        root_logger.handlers.clear()
        
        # Console handler
        if self.config["console_enabled"]:
            console_handler = logging.StreamHandler(sys.stderr)
            console_formatter = self._get_formatter("console")
            console_handler.setFormatter(console_formatter)
            console_handler.setLevel(getattr(logging, self.config["level"]))
            root_logger.addHandler(console_handler)
        
        # File handler with rotation
        if self.config["file_enabled"]:
            log_file = self.log_dir / "codeinsight.log"
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=self.config["file_rotation"]["max_bytes"],
                backupCount=self.config["file_rotation"]["backup_count"]
            )
            file_formatter = self._get_formatter("file")
            file_handler.setFormatter(file_formatter)
            file_handler.setLevel(logging.DEBUG)  # File gets all logs
            root_logger.addHandler(file_handler)
        
        # Structured logs handler
        if self.config["structured_logs"]["enabled"]:
            structured_file = self.log_dir / "codeinsight-structured.jsonl"
            structured_handler = logging.handlers.RotatingFileHandler(
                structured_file,
                maxBytes=self.config["file_rotation"]["max_bytes"],
                backupCount=self.config["file_rotation"]["backup_count"]
            )
            structured_handler.setFormatter(StructuredFormatter())
            structured_handler.setLevel(logging.DEBUG)
            root_logger.addHandler(structured_handler)
    
    def _get_formatter(self, handler_type: str) -> logging.Formatter:
        """Get appropriate formatter based on configuration."""
        format_type = self.config["format"]
        
        if handler_type == "console":
            if format_type == "human":
                return HumanReadableFormatter(use_colors=True)
            elif format_type == "compact":
                return CompactFormatter()
            else:
                return StructuredFormatter()
        
        elif handler_type == "file":
            if format_type == "structured":
                return StructuredFormatter()
            elif format_type == "compact":
                return CompactFormatter()
            else:
                return HumanReadableFormatter(use_colors=False)
        
        return HumanReadableFormatter(use_colors=False)
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get or create a logger with the specified name."""
        if name not in self.loggers:
            logger = logging.getLogger(f"codeinsight.{name}")
            self.loggers[name] = logger
            
            # Add trace method
            def trace(self, message, *args, **kwargs):
                if self.isEnabledFor(LogLevel.TRACE.value):
                    self._log(LogLevel.TRACE.value, message, args, **kwargs)
            
            logger.__class__.trace = trace
        
        return self.loggers[name]
    
    def get_performance_logger(self, name: str) -> PerformanceLogger:
        """Get or create a performance logger."""
        if name not in self.performance_loggers:
            base_logger = self.get_logger(f"performance.{name}")
            self.performance_loggers[name] = PerformanceLogger(base_logger)
        
        return self.performance_loggers[name]
    
    def set_level(self, level: Union[str, int]):
        """Set global logging level."""
        if isinstance(level, str):
            level = getattr(logging, level.upper())
        
        root_logger = logging.getLogger()
        root_logger.setLevel(level)
        
        # Update console handler level
        for handler in root_logger.handlers:
            if isinstance(handler, logging.StreamHandler) and handler.stream == sys.stderr:
                handler.setLevel(level)
    
    def log_system_info(self):
        """Log system information for debugging."""
        logger = self.get_logger("system")
        
        import platform
        import psutil
        
        system_info = {
            "platform": platform.system(),
            "platform_version": platform.version(),
            "python_version": platform.python_version(),
            "architecture": platform.architecture()[0],
            "processor": platform.processor(),
            "memory_total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
            "memory_available_gb": round(psutil.virtual_memory().available / (1024**3), 2),
            "disk_free_gb": round(psutil.disk_usage('.').free / (1024**3), 2)
        }
        
        logger.info("System information logged", extra={'extra_data': system_info})
    
    def create_context_manager(self, operation: str, logger_name: str = "general"):
        """Create a context manager for logging operations."""
        return LoggingContext(self.get_logger(logger_name), operation)
    
    def flush_all(self):
        """Flush all log handlers."""
        for handler in logging.getLogger().handlers:
            if not hasattr(handler, 'flush'):
                continue
            
            stream = getattr(handler, 'stream', None)
            if getattr(stream, 'closed', False):
                continue
            
            try:
                handler.flush()
            except ValueError:
                # Handler already closed; ignore
                continue
    
    def shutdown(self):
        """Shutdown logging system gracefully."""
        self.flush_all()
        logging.shutdown()


class LoggingContext:
    """Context manager for logging operations with automatic timing."""
    
    def __init__(self, logger: logging.Logger, operation: str, level: int = logging.INFO):
        self.logger = logger
        self.operation = operation
        self.level = level
        self.start_time = None
        self.extra_data = {}
    
    def __enter__(self):
        self.start_time = time.perf_counter()
        self.logger.log(self.level, f"Starting {self.operation}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.perf_counter() - self.start_time
        duration_ms = duration * 1000
        
        if exc_type is None:
            self.logger.log(
                self.level,
                f"Completed {self.operation}",
                extra={
                    'performance_metrics': {
                        'duration_ms': duration_ms,
                        'success': True,
                        'operation': self.operation
                    },
                    'extra_data': self.extra_data
                }
            )
        else:
            self.logger.error(
                f"Failed {self.operation}: {exc_val}",
                exc_info=(exc_type, exc_val, exc_tb),
                extra={
                    'performance_metrics': {
                        'duration_ms': duration_ms,
                        'success': False,
                        'operation': self.operation,
                        'error_type': exc_type.__name__
                    },
                    'extra_data': self.extra_data
                }
            )
    
    def add_context(self, **kwargs):
        """Add context data to be logged."""
        self.extra_data.update(kwargs)


# Global logging manager instance
_logging_manager = None

def get_logging_manager() -> LoggingManager:
    """Get the global logging manager instance."""
    global _logging_manager
    if _logging_manager is None:
        _logging_manager = LoggingManager()
    return _logging_manager

def get_logger(name: str) -> logging.Logger:
    """Get a logger instance."""
    return get_logging_manager().get_logger(name)

def get_performance_logger(name: str) -> PerformanceLogger:
    """Get a performance logger instance."""
    return get_logging_manager().get_performance_logger(name)

def log_context(operation: str, logger_name: str = "general"):
    """Create a logging context manager."""
    return get_logging_manager().create_context_manager(operation, logger_name)
