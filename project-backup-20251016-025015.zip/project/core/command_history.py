"""
Command history tracking for CodeInsight CLI.
Provides recall functionality and usage analytics.
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict


@dataclass
class CommandHistoryEntry:
    """Represents a single command history entry."""
    timestamp: str
    command: str
    args: List[str]
    success: bool
    duration_ms: Optional[int] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class CommandHistory:
    """Manages command history for CodeInsight CLI."""
    
    def __init__(self, history_file: str = "data/command_history.json", max_entries: int = 1000):
        self.history_file = Path(history_file)
        self.max_entries = max_entries
        self.entries: List[CommandHistoryEntry] = []
        self._load_history()
    
    def _load_history(self):
        """Load command history from file."""
        if self.history_file.exists():
            try:
                with open(self.history_file, 'r') as f:
                    data = json.load(f)
                    self.entries = [
                        CommandHistoryEntry(**entry) for entry in data.get("entries", [])
                    ]
            except (json.JSONDecodeError, TypeError) as e:
                # If history file is corrupted, start fresh
                self.entries = []
    
    def _save_history(self):
        """Save command history to file."""
        # Ensure directory exists
        self.history_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Keep only the most recent entries
        if len(self.entries) > self.max_entries:
            self.entries = self.entries[-self.max_entries:]
        
        data = {
            "entries": [asdict(entry) for entry in self.entries],
            "last_updated": datetime.now().isoformat()
        }
        
        with open(self.history_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def add_entry(self, command: str, args: List[str], success: bool, 
                  duration_ms: int = None, error: str = None, metadata: Dict[str, Any] = None):
        """Add a new command to history."""
        entry = CommandHistoryEntry(
            timestamp=datetime.now().isoformat(),
            command=command,
            args=args,
            success=success,
            duration_ms=duration_ms,
            error=error,
            metadata=metadata
        )
        
        self.entries.append(entry)
        self._save_history()
    
    def get_recent_commands(self, limit: int = 10) -> List[CommandHistoryEntry]:
        """Get the most recent commands."""
        return self.entries[-limit:] if self.entries else []
    
    def get_command_stats(self) -> Dict[str, Any]:
        """Get statistics about command usage."""
        if not self.entries:
            return {"total_commands": 0}
        
        total = len(self.entries)
        successful = sum(1 for entry in self.entries if entry.success)
        failed = total - successful
        
        # Command frequency
        command_counts = {}
        for entry in self.entries:
            command_counts[entry.command] = command_counts.get(entry.command, 0) + 1
        
        # Recent activity (last 24 hours)
        from datetime import datetime, timedelta
        now = datetime.now()
        yesterday = now - timedelta(days=1)
        recent_entries = [
            entry for entry in self.entries
            if datetime.fromisoformat(entry.timestamp) > yesterday
        ]
        
        return {
            "total_commands": total,
            "successful_commands": successful,
            "failed_commands": failed,
            "success_rate": successful / total if total > 0 else 0,
            "most_used_commands": sorted(command_counts.items(), key=lambda x: x[1], reverse=True)[:5],
            "recent_activity_24h": len(recent_entries),
            "average_duration_ms": sum(entry.duration_ms for entry in self.entries if entry.duration_ms) / 
                                  len([e for e in self.entries if e.duration_ms]) if any(e.duration_ms for e in self.entries) else None
        }
    
    def search_history(self, query: str, limit: int = 20) -> List[CommandHistoryEntry]:
        """Search command history by query string."""
        query_lower = query.lower()
        matches = []
        
        for entry in reversed(self.entries):  # Search from most recent
            if (query_lower in entry.command.lower() or 
                any(query_lower in arg.lower() for arg in entry.args)):
                matches.append(entry)
                if len(matches) >= limit:
                    break
        
        return matches
    
    def get_failed_commands(self, limit: int = 10) -> List[CommandHistoryEntry]:
        """Get recent failed commands for debugging."""
        failed = [entry for entry in reversed(self.entries) if not entry.success]
        return failed[:limit]
    
    def clear_history(self):
        """Clear all command history."""
        self.entries = []
        if self.history_file.exists():
            self.history_file.unlink()


# Global history instance
_history_instance = None

def get_command_history() -> CommandHistory:
    """Get the global command history instance."""
    global _history_instance
    if _history_instance is None:
        _history_instance = CommandHistory()
    return _history_instance