"""
Tool interface for CodeInsight Agent system.
Defines the base interface for all agent tools.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class Tool(ABC):
    """
    Base interface for all CodeInsight Agent tools.
    Tools are modular components that the agent can invoke to perform actions.
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Return the unique name of this tool."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Return a description of what this tool does."""
        pass
    
    @property
    @abstractmethod
    def parameters(self) -> Dict[str, str]:
        """Return a dictionary of parameter names and their descriptions."""
        pass
    
    @abstractmethod
    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the tool with given parameters.
        
        Args:
            **kwargs: Tool-specific parameters
            
        Returns:
            Dict containing:
            - success: bool indicating if execution succeeded
            - result: Any tool-specific result data
            - error: Optional error message if success=False
            - metadata: Optional additional information
        """
        pass
    
    def validate_parameters(self, **kwargs) -> bool:
        """
        Validate that required parameters are provided.
        
        Args:
            **kwargs: Parameters to validate
            
        Returns:
            True if parameters are valid, False otherwise
        """
        required_params = set(self.parameters.keys())
        provided_params = set(kwargs.keys())
        
        missing_params = required_params - provided_params
        if missing_params:
            logger.error(f"Tool {self.name} missing required parameters: {missing_params}")
            return False
        
        return True
    
    def log_execution(self, action: str, **kwargs):
        """Log tool execution for debugging."""
        logger.info(f"Tool {self.name}: {action} with params: {kwargs}")


class ToolRegistry:
    """
    Registry for managing available tools.
    Allows dynamic registration and lookup of tools.
    """
    
    def __init__(self):
        self._tools: Dict[str, Tool] = {}
    
    def register(self, tool: Tool):
        """Register a tool in the registry."""
        self._tools[tool.name] = tool
        logger.info(f"Registered tool: {tool.name}")
    
    def get_tool(self, name: str) -> Tool:
        """Get a tool by name."""
        if name not in self._tools:
            raise ValueError(f"Tool '{name}' not found in registry")
        return self._tools[name]
    
    def list_tools(self) -> List[Dict[str, str]]:
        """List all available tools with their descriptions."""
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": str(tool.parameters)
            }
            for tool in self._tools.values()
        ]
    
    def has_tool(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tools