"""
Dummy tools for testing the CodeInsight Agent system.
These tools provide basic functionality for initial testing.
"""

import time
from typing import Dict, Any
from .tools import Tool


class EchoTool(Tool):
    """
    Simple echo tool that returns the input message.
    Useful for testing agent tool dispatch.
    """
    
    @property
    def name(self) -> str:
        return "echo_tool"
    
    @property
    def description(self) -> str:
        return "Echoes back the provided message with a timestamp"
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "message": "The message to echo back"
        }
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        if not self.validate_parameters(**kwargs):
            return {
                "success": False,
                "error": "Missing required parameter: message"
            }
        
        message = kwargs.get("message", "")
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        
        self.log_execution("echo", message=message)
        
        return {
            "success": True,
            "result": f"Echo at {timestamp}: {message}",
            "metadata": {
                "original_message": message,
                "timestamp": timestamp,
                "tool_name": self.name
            }
        }


class CalculatorTool(Tool):
    """
    Simple calculator tool for basic arithmetic.
    Tests tool parameter validation and computation.
    """
    
    @property
    def name(self) -> str:
        return "calculator_tool"
    
    @property
    def description(self) -> str:
        return "Performs basic arithmetic operations (add, subtract, multiply, divide)"
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "operation": "The operation to perform: add, subtract, multiply, divide",
            "a": "First number",
            "b": "Second number"
        }
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        if not self.validate_parameters(**kwargs):
            return {
                "success": False,
                "error": "Missing required parameters: operation, a, b"
            }
        
        try:
            operation = kwargs.get("operation", "").lower()
            a = float(kwargs.get("a", 0))
            b = float(kwargs.get("b", 0))
            
            self.log_execution("calculate", operation=operation, a=a, b=b)
            
            if operation == "add":
                result = a + b
            elif operation == "subtract":
                result = a - b
            elif operation == "multiply":
                result = a * b
            elif operation == "divide":
                if b == 0:
                    return {
                        "success": False,
                        "error": "Division by zero is not allowed"
                    }
                result = a / b
            else:
                return {
                    "success": False,
                    "error": f"Unknown operation: {operation}. Use: add, subtract, multiply, divide"
                }
            
            return {
                "success": True,
                "result": result,
                "metadata": {
                    "operation": operation,
                    "operands": [a, b],
                    "formula": f"{a} {operation} {b} = {result}"
                }
            }
            
        except ValueError as e:
            return {
                "success": False,
                "error": f"Invalid number format: {e}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Calculation error: {e}"
            }