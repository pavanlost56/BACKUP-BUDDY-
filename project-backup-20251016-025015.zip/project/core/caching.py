"""
Intelligent caching system for CodeInsight.
Provides multi-layer caching for web requests, embeddings, and frequently accessed data.
"""

import hashlib
import json
import pickle
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, Union, Callable
from dataclasses import dataclass, asdict
from functools import wraps
import threading
import gzip
import logging
import uuid


@dataclass
class CacheEntry:
    """Cache entry with metadata."""
    key: str
    data: Any
    created_at: datetime
    last_accessed: datetime
    access_count: int
    expires_at: Optional[datetime] = None
    size_bytes: int = 0
    metadata: Optional[Dict[str, Any]] = None


class CacheStrategy:
    """Cache strategy configuration."""
    
    def __init__(self, 
                 max_size_mb: int = 100,
                 default_ttl_hours: int = 24,
                 max_entries: int = 1000,
                 eviction_policy: str = "lru",  # lru, lfu, ttl
                 compression: bool = True):
        self.max_size_mb = max_size_mb
        self.default_ttl_hours = default_ttl_hours
        self.max_entries = max_entries
        self.eviction_policy = eviction_policy
        self.compression = compression


class IntelligentCache:
    """Multi-layer intelligent caching system."""
    
    def __init__(self, cache_dir: str = "data/cache", strategy: CacheStrategy = None):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.strategy = strategy or CacheStrategy()
        self.logger = logging.getLogger("codeinsight.cache")
        
        # In-memory cache for hot data
        self.memory_cache: Dict[str, CacheEntry] = {}
        self.cache_lock = threading.RLock()
        
        # Cache statistics
        self.stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0,
            "memory_usage_mb": 0,
            "disk_usage_mb": 0
        }
        
        # Initialize cache
        self._initialize_cache()
    
    def _initialize_cache(self):
        """Initialize cache and load metadata."""
        self._update_disk_usage()
        self._cleanup_expired_entries()
    
    def _generate_key(self, data: Any) -> str:
        """Generate a unique cache key for data."""
        if isinstance(data, str):
            content = data
        elif isinstance(data, dict):
            content = json.dumps(data, sort_keys=True)
        else:
            content = str(data)
        
        return hashlib.sha256(content.encode()).hexdigest()[:32]
    
    def _serialize_data(self, data: Any) -> bytes:
        """Serialize data for storage."""
        serialized = pickle.dumps(data)
        
        if self.strategy.compression and len(serialized) > 1024:  # Compress if > 1KB
            serialized = gzip.compress(serialized)
        
        return serialized
    
    def _deserialize_data(self, data: bytes) -> Any:
        """Deserialize data from storage."""
        try:
            # Try decompression first
            if self.strategy.compression:
                try:
                    data = gzip.decompress(data)
                except:
                    pass  # Not compressed
            
            return pickle.loads(data)
        except Exception as e:
            self.logger.error(f"Failed to deserialize cache data: {e}")
            return None
    
    def _get_cache_file_path(self, key: str) -> Path:
        """Get file path for cache key."""
        # Create subdirectories based on key prefix for better organization
        subdir = key[:2]
        cache_subdir = self.cache_dir / subdir
        cache_subdir.mkdir(exist_ok=True)
        return cache_subdir / f"{key}.cache"
    
    def _calculate_size(self, data: Any) -> int:
        """Calculate approximate size of data in bytes."""
        try:
            return len(self._serialize_data(data))
        except:
            return len(str(data).encode())
    
    def _update_memory_usage(self):
        """Update memory usage statistics."""
        total_size = sum(entry.size_bytes for entry in self.memory_cache.values())
        self.stats["memory_usage_mb"] = total_size / (1024 * 1024)
    
    def _update_disk_usage(self):
        """Update disk usage statistics."""
        total_size = sum(f.stat().st_size for f in self.cache_dir.rglob("*.cache"))
        self.stats["disk_usage_mb"] = total_size / (1024 * 1024)
    
    def _cleanup_expired_entries(self):
        """Remove expired cache entries."""
        now = datetime.now()
        expired_keys = []
        
        with self.cache_lock:
            # Check memory cache
            for key, entry in self.memory_cache.items():
                if entry.expires_at and entry.expires_at < now:
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.memory_cache[key]
                self.stats["evictions"] += 1
            
            # Check disk cache
            for cache_file in self.cache_dir.rglob("*.cache"):
                try:
                    # Check file modification time
                    file_age = datetime.fromtimestamp(cache_file.stat().st_mtime)
                    max_age = timedelta(hours=self.strategy.default_ttl_hours * 2)
                    
                    if now - file_age > max_age:
                        cache_file.unlink()
                        self.stats["evictions"] += 1
                except Exception:
                    continue
    
    def _evict_if_needed(self):
        """Evict entries if cache limits are exceeded."""
        with self.cache_lock:
            # Check memory limits
            if len(self.memory_cache) > self.strategy.max_entries:
                self._evict_memory_entries()
            
            # Check size limits
            if self.stats["memory_usage_mb"] > self.strategy.max_size_mb:
                self._evict_by_size()
    
    def _evict_memory_entries(self):
        """Evict memory entries based on strategy."""
        entries_to_remove = len(self.memory_cache) - self.strategy.max_entries + 1
        
        if self.strategy.eviction_policy == "lru":
            # Remove least recently used
            sorted_entries = sorted(
                self.memory_cache.items(),
                key=lambda x: x[1].last_accessed
            )
        elif self.strategy.eviction_policy == "lfu":
            # Remove least frequently used
            sorted_entries = sorted(
                self.memory_cache.items(),
                key=lambda x: x[1].access_count
            )
        else:  # ttl
            # Remove oldest
            sorted_entries = sorted(
                self.memory_cache.items(),
                key=lambda x: x[1].created_at
            )
        
        for i in range(entries_to_remove):
            if i < len(sorted_entries):
                key = sorted_entries[i][0]
                del self.memory_cache[key]
                self.stats["evictions"] += 1
    
    def _evict_by_size(self):
        """Evict entries to reduce memory usage."""
        target_size = self.strategy.max_size_mb * 0.8  # Reduce to 80% of limit
        
        # Sort by size (largest first) and access pattern
        sorted_entries = sorted(
            self.memory_cache.items(),
            key=lambda x: (x[1].size_bytes, -x[1].access_count),
            reverse=True
        )
        
        current_size = self.stats["memory_usage_mb"]
        for key, entry in sorted_entries:
            if current_size <= target_size:
                break
            
            del self.memory_cache[key]
            current_size -= entry.size_bytes / (1024 * 1024)
            self.stats["evictions"] += 1
    
    def get(self, key: str) -> Optional[Any]:
        """Get data from cache."""
        with self.cache_lock:
            # Check memory cache first
            if key in self.memory_cache:
                entry = self.memory_cache[key]
                
                # Check expiration
                if entry.expires_at and entry.expires_at < datetime.now():
                    del self.memory_cache[key]
                    self.stats["misses"] += 1
                    return None
                
                # Update access info
                entry.last_accessed = datetime.now()
                entry.access_count += 1
                self.stats["hits"] += 1
                
                return entry.data
            
            # Check disk cache
            cache_file = self._get_cache_file_path(key)
            if cache_file.exists():
                try:
                    with open(cache_file, 'rb') as f:
                        metadata_size = int.from_bytes(f.read(4), 'big')
                        metadata_json = f.read(metadata_size).decode()
                        data_bytes = f.read()
                    
                    metadata = json.loads(metadata_json)
                    
                    # Check expiration
                    if metadata.get('expires_at'):
                        expires_at = datetime.fromisoformat(metadata['expires_at'])
                        if expires_at < datetime.now():
                            cache_file.unlink()
                            self.stats["misses"] += 1
                            return None
                    
                    # Deserialize data
                    data = self._deserialize_data(data_bytes)
                    if data is None:
                        cache_file.unlink()
                        self.stats["misses"] += 1
                        return None
                    
                    # Promote to memory cache if it's hot
                    self._promote_to_memory(key, data, metadata)
                    
                    self.stats["hits"] += 1
                    return data
                    
                except Exception as e:
                    self.logger.error(f"Failed to read cache file {cache_file}: {e}")
                    cache_file.unlink()
            
            self.stats["misses"] += 1
            return None
    
    def _promote_to_memory(self, key: str, data: Any, metadata: Dict[str, Any]):
        """Promote frequently accessed data to memory cache."""
        with self.cache_lock:
            size_bytes = self._calculate_size(data)
            expires_at = None
            
            if metadata.get('expires_at'):
                expires_at = datetime.fromisoformat(metadata['expires_at'])
            
            entry = CacheEntry(
                key=key,
                data=data,
                created_at=datetime.fromisoformat(metadata['created_at']),
                last_accessed=datetime.now(),
                access_count=metadata.get('access_count', 1) + 1,
                expires_at=expires_at,
                size_bytes=size_bytes,
                metadata=metadata.get('metadata')
            )
            
            # Only promote if it won't exceed memory limits
            if size_bytes < self.strategy.max_size_mb * 1024 * 1024 * 0.1:  # Less than 10% of max
                self.memory_cache[key] = entry
                self._update_memory_usage()
                self._evict_if_needed()
    
    def set(self, key: str, data: Any, ttl_hours: Optional[int] = None, 
            metadata: Optional[Dict[str, Any]] = None) -> bool:
        """Set data in cache."""
        with self.cache_lock:
            try:
                ttl = ttl_hours or self.strategy.default_ttl_hours
                expires_at = datetime.now() + timedelta(hours=ttl)
                size_bytes = self._calculate_size(data)
                
                # Create cache entry
                entry = CacheEntry(
                    key=key,
                    data=data,
                    created_at=datetime.now(),
                    last_accessed=datetime.now(),
                    access_count=1,
                    expires_at=expires_at,
                    size_bytes=size_bytes,
                    metadata=metadata
                )
                
                # Store in memory if reasonable size
                if size_bytes < self.strategy.max_size_mb * 1024 * 1024 * 0.1:
                    self.memory_cache[key] = entry
                    self._update_memory_usage()
                
                # Always store to disk for persistence
                self._store_to_disk(key, entry)
                
                # Cleanup if needed
                self._evict_if_needed()
                
                return True
                
            except Exception as e:
                self.logger.error(f"Failed to cache data for key {key}: {e}")
                return False
    
    def _store_to_disk(self, key: str, entry: CacheEntry):
        """Store entry to disk."""
        cache_file = self._get_cache_file_path(key)
        
        try:
            # Prepare metadata
            metadata = {
                "created_at": entry.created_at.isoformat(),
                "expires_at": entry.expires_at.isoformat() if entry.expires_at else None,
                "access_count": entry.access_count,
                "size_bytes": entry.size_bytes,
                "metadata": entry.metadata
            }
            
            metadata_json = json.dumps(metadata).encode()
            data_bytes = self._serialize_data(entry.data)
            
            # Write to file
            with open(cache_file, 'wb') as f:
                f.write(len(metadata_json).to_bytes(4, 'big'))
                f.write(metadata_json)
                f.write(data_bytes)
                
        except Exception as e:
            self.logger.error(f"Failed to store cache to disk: {e}")
    
    def delete(self, key: str) -> bool:
        """Delete entry from cache."""
        with self.cache_lock:
            deleted = False
            
            # Remove from memory
            if key in self.memory_cache:
                del self.memory_cache[key]
                deleted = True
            
            # Remove from disk
            cache_file = self._get_cache_file_path(key)
            if cache_file.exists():
                cache_file.unlink()
                deleted = True
            
            if deleted:
                self._update_memory_usage()
                self._update_disk_usage()
            
            return deleted
    
    def clear(self, pattern: Optional[str] = None):
        """Clear cache entries, optionally matching pattern."""
        with self.cache_lock:
            if pattern is None:
                # Clear everything
                self.memory_cache.clear()
                for cache_file in self.cache_dir.rglob("*.cache"):
                    cache_file.unlink()
            else:
                # Clear matching pattern
                keys_to_delete = [k for k in self.memory_cache.keys() if pattern in k]
                for key in keys_to_delete:
                    self.delete(key)
            
            self._update_memory_usage()
            self._update_disk_usage()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.cache_lock:
            self._update_memory_usage()
            self._update_disk_usage()
            
            hit_rate = 0.0
            total_requests = self.stats["hits"] + self.stats["misses"]
            if total_requests > 0:
                hit_rate = self.stats["hits"] / total_requests
            
            return {
                "hit_rate": hit_rate,
                "total_requests": total_requests,
                "memory_entries": len(self.memory_cache),
                "disk_entries": len(list(self.cache_dir.rglob("*.cache"))),
                **self.stats
            }

    def get_cache_size_mb(self) -> float:
        """Get total disk usage of the cache in MB."""
        with self.cache_lock:
            self._update_disk_usage()
            return self.stats.get("disk_usage_mb", 0.0)


def cached(key_func: Callable = None, ttl_hours: int = 24, 
          cache_type: str = "default"):
    """
    Decorator for caching function results.
    
    Args:
        key_func: Function to generate cache key from args
        ttl_hours: Time to live in hours
        cache_type: Type of cache to use
    """
    def decorator(func):
        namespace = uuid.uuid4().hex

        @wraps(func)
        def wrapper(*args, **kwargs):
            cache = get_cache(cache_type)
            
            # Generate cache key
            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                # Default key generation
                key_data = {
                    "function": f"{func.__module__}.{func.__name__}",
                    "args": str(args),
                    "kwargs": str(sorted(kwargs.items())),
                    "namespace": namespace,
                }
                cache_key = cache._generate_key(key_data)
            
            cache_key = f"{namespace}:{cache_key}"
            
            # Try to get from cache
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function and cache result
            result = func(*args, **kwargs)
            cache.set(cache_key, result, ttl_hours=ttl_hours, metadata={
                "function": func.__name__,
                "args_count": len(args),
                "kwargs_count": len(kwargs),
                "namespace": namespace,
            })
            
            return result
        
        return wrapper
    return decorator


# Global cache instances
_cache_instances = {}
_default_cache_manager = None

CacheManager = IntelligentCache


def get_cache(cache_type: str = "default") -> IntelligentCache:
    """Get cache instance by type."""
    if cache_type not in _cache_instances:
        cache_dir = f"data/cache/{cache_type}"
        
        # Different strategies for different cache types
        if cache_type == "web_requests":
            strategy = CacheStrategy(max_size_mb=50, default_ttl_hours=6)
        elif cache_type == "embeddings":
            strategy = CacheStrategy(max_size_mb=200, default_ttl_hours=168)  # 1 week
        elif cache_type == "api_responses":
            strategy = CacheStrategy(max_size_mb=30, default_ttl_hours=2)
        else:
            strategy = CacheStrategy()
        
        _cache_instances[cache_type] = IntelligentCache(cache_dir, strategy)
    
    return _cache_instances[cache_type]

def get_cache_manager() -> IntelligentCache:
    """Get the singleton instance of the default IntelligentCache."""
    global _default_cache_manager
    if _default_cache_manager is None:
        # Use the user's home directory for the cache
        cache_base_dir = Path.home() / ".codeinsight" / "cache"
        _default_cache_manager = IntelligentCache(cache_dir=str(cache_base_dir / "default"))
    return _default_cache_manager


__all__ = [
    "CacheEntry",
    "CacheStrategy",
    "IntelligentCache",
    "CacheManager",
    "cached",
    "get_cache",
    "get_cache_manager",
]
