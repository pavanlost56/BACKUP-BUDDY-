"""
Suggester module for formatting responses and providing actionable suggestions.
Enhances LLM outputs with structured formatting and source citations.
"""

import re
from typing import List, Dict, Any
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.syntax import Syntax


def validate_citation_metadata(context_chunks: List[Dict[str, Any]]) -> bool:
    """
    Validate that context chunks contain required citation metadata.
    
    Args:
        context_chunks: List of retrieved context chunks
        
    Returns:
        True if all chunks have required metadata
    """
    required_fields = ["source_path", "chunk_id", "content"]
    
    for chunk in context_chunks:
        for field in required_fields:
            if field not in chunk:
                return False
    
    return True


def extract_code_blocks(response: str) -> List[Dict[str, str]]:
    """
    Extract code blocks from response text.
    
    Args:
        response: The LLM response text
        
    Returns:
        List of dictionaries with 'language' and 'code' keys
    """
    code_blocks = []
    
    # Pattern to match fenced code blocks with optional language
    pattern = r'```(\w+)?\n?(.*?)\n?```'
    matches = re.finditer(pattern, response, re.DOTALL)
    
    for match in matches:
        language = match.group(1) or 'text'
        code = match.group(2).strip()
        
        if code:  # Only add non-empty code blocks
            code_blocks.append({
                'language': language,
                'code': code
            })
    
    return code_blocks


def parse_response_sections(response: str) -> Dict[str, str]:
    """
    Parse response into structured sections (Summary, Steps/Code, Sources).
    
    Args:
        response: The LLM response text
        
    Returns:
        Dictionary with section names as keys and content as values
    """
    sections = {
        'summary': '',
        'steps': '',
        'sources': ''
    }
    
    # Patterns for section headers
    summary_pattern = r'#+\s*Summary\s*\n(.*?)(?=#+\s*(?:Steps|Code|Sources)|$)'
    steps_pattern = r'#+\s*(?:Steps|Code|Steps/Code|Steps & Code)\s*\n(.*?)(?=#+\s*Sources|$)'
    sources_pattern = r'#+\s*Sources\s*\n(.*?)$'
    
    # Extract sections
    summary_match = re.search(summary_pattern, response, re.DOTALL | re.IGNORECASE)
    if summary_match:
        sections['summary'] = summary_match.group(1).strip()
    
    steps_match = re.search(steps_pattern, response, re.DOTALL | re.IGNORECASE)
    if steps_match:
        sections['steps'] = steps_match.group(1).strip()
    
    sources_match = re.search(sources_pattern, response, re.DOTALL | re.IGNORECASE)
    if sources_match:
        sections['sources'] = sources_match.group(1).strip()
    
    return sections


def format_response_with_rich(response: str, context_chunks: List[Dict[str, Any]], 
                            query: str, framework: str) -> Panel:
    """
    Format response using Rich panels with clear sections and citations.
    
    Args:
        response: The LLM response text
        context_chunks: List of retrieved context chunks for fallback citations
        query: Original user query
        framework: Framework being queried
        
    Returns:
        Rich Panel with formatted response
    """
    console = Console()
    
    # Parse response sections
    sections = parse_response_sections(response)
    
    # Build formatted content
    content_parts = []
    
    # Summary section
    if sections['summary']:
        content_parts.append(f"[bold cyan]## Summary[/bold cyan]")
        content_parts.append(sections['summary'])
        content_parts.append("")
    
    # Steps/Code section
    if sections['steps']:
        content_parts.append(f"[bold green]## Steps/Code[/bold green]")
        
        # Extract and format code blocks
        code_blocks = extract_code_blocks(sections['steps'])
        if code_blocks:
            # Remove code blocks from text and add them formatted
            steps_text = sections['steps']
            for block in code_blocks:
                # Remove the original code block
                pattern = f"```{block['language']}\n{re.escape(block['code'])}\n```"
                steps_text = re.sub(pattern, "", steps_text, flags=re.DOTALL)
            
            # Add cleaned text
            if steps_text.strip():
                content_parts.append(steps_text.strip())
                content_parts.append("")
            
            # Add formatted code blocks
            for block in code_blocks:
                content_parts.append(f"```{block['language']}")
                content_parts.append(block['code'])
                content_parts.append("```")
                content_parts.append("")
        else:
            content_parts.append(sections['steps'])
            content_parts.append("")
    
    # Sources section
    sources_content = sections['sources']
    if not sources_content.strip() and context_chunks:
        # Fallback: generate sources from context chunks
        sources_lines = []
        for chunk in context_chunks:
            source_path = chunk.get('source_path', 'unknown')
            chunk_id = chunk.get('chunk_id', 'unknown')
            similarity = chunk.get('similarity_score', 0)
            sources_lines.append(f"- {source_path}#{chunk_id} (similarity: {similarity:.3f})")
        sources_content = "\n".join(sources_lines)
    
    if sources_content:
        content_parts.append(f"[bold blue]## Sources[/bold blue]")
        content_parts.append(sources_content)
    
    # Join all parts
    formatted_content = "\n".join(content_parts)
    
    # Create panel
    title = f"CodeInsight Answer for '{query}' ({framework})"
    return Panel(
        formatted_content,
        title=title,
        border_style="blue",
        padding=(1, 2)
    )


def suggest_follow_up_actions(query: str, framework: str, 
                            context_chunks: List[Dict[str, Any]]) -> List[str]:
    """
    Suggest follow-up actions based on the query and retrieved context.
    
    Args:
        query: Original user query
        framework: Framework being queried
        context_chunks: Retrieved context chunks
        
    Returns:
        List of actionable suggestions
    """
    suggestions = []
    
    # Query type detection
    if any(word in query.lower() for word in ['install', 'setup', 'getting started']):
        suggestions.extend([
            f"Try: python cli.py query 'installation guide' --framework {framework}",
            f"Check official {framework} installation docs",
            "Run the setup commands in your project directory"
        ])
    
    elif any(word in query.lower() for word in ['component', 'create', 'build']):
        suggestions.extend([
            f"Try: python cli.py query 'component example' --framework {framework}",
            f"Explore more {framework} component patterns",
            "Create a minimal example to test the approach"
        ])
    
    elif any(word in query.lower() for word in ['error', 'bug', 'problem', 'issue']):
        suggestions.extend([
            f"Try: python cli.py query 'troubleshooting' --framework {framework}",
            "Check the browser/console for additional error details",
            "Verify your setup matches the documentation requirements"
        ])
    
    # General suggestions
    suggestions.extend([
        f"Update docs: python cli.py update {framework}",
        f"Explore related topics: python cli.py query '<your-topic>' --framework {framework}"
    ])
    
    return suggestions[:4]  # Limit to 4 suggestions


def create_fallback_response(query: str, framework: str, context_chunks: List[Dict[str, Any]], 
                           error_message: str = None) -> Panel:
    """
    Create a structured fallback response when LLM is unavailable.
    
    Args:
        query: Original user query
        framework: Framework being queried
        context_chunks: Retrieved context chunks
        error_message: Optional error message to include
        
    Returns:
        Rich Panel with formatted fallback response
    """
    content_parts = []
    
    # Error notification
    if error_message:
        content_parts.extend([
            "[bold red]## System Notice[/bold red]",
            f"Error: {error_message}",
            ""
        ])
    
    # Summary
    content_parts.extend([
        "[bold cyan]## Summary[/bold cyan]",
        f"Found {len(context_chunks)} relevant chunks for your query about '{query}' in {framework} documentation.",
        ""
    ])
    
    # Context preview
    if context_chunks:
        content_parts.extend([
            "[bold green]## Relevant Context[/bold green]"
        ])
        
        for i, chunk in enumerate(context_chunks[:2], 1):  # Show first 2 chunks
            content_preview = chunk.get('content', '')[:200] + "..." if len(chunk.get('content', '')) > 200 else chunk.get('content', '')
            similarity = chunk.get('similarity_score', 0)
            content_parts.extend([
                f"**Context {i}** (similarity: {similarity:.3f})",
                content_preview,
                ""
            ])
    
    # Sources
    if context_chunks:
        content_parts.extend([
            "[bold blue]## Sources[/bold blue]"
        ])
        for chunk in context_chunks:
            source_path = chunk.get('source_path', 'unknown')
            chunk_id = chunk.get('chunk_id', 'unknown')
            content_parts.append(f"- {source_path}#{chunk_id}")
        content_parts.append("")
    
    # Suggestions
    suggestions = suggest_follow_up_actions(query, framework, context_chunks)
    if suggestions:
        content_parts.extend([
            "[bold magenta]## Suggested Actions[/bold magenta]"
        ])
        for suggestion in suggestions:
            content_parts.append(f"• {suggestion}")
    
    formatted_content = "\n".join(content_parts)
    
    title = f"CodeInsight Response for '{query}' ({framework})"
    return Panel(
        formatted_content,
        title=title,
        border_style="yellow",
        padding=(1, 2)
    )