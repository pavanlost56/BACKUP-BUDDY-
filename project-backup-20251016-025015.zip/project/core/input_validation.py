"""
Input validation and sanitization for CodeInsight.
Provides comprehensive validation for all user inputs, file paths, API parameters, and commands.
"""

import re
import os
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Set, Callable
from dataclasses import dataclass
from urllib.parse import urlparse
import logging


@dataclass
class ValidationResult:
    """Result of input validation."""
    is_valid: bool
    cleaned_value: Any = None
    errors: List[str] = None
    warnings: List[str] = None
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []
        if self.warnings is None:
            self.warnings = []


class ValidationRule:
    """Base validation rule."""
    
    def __init__(self, name: str, error_message: str = None):
        self.name = name
        self.error_message = error_message or f"Validation failed for rule: {name}"
    
    def validate(self, value: Any) -> ValidationResult:
        """Validate value against this rule."""
        raise NotImplementedError
    
    def __call__(self, value: Any) -> ValidationResult:
        return self.validate(value)


class RegexRule(ValidationRule):
    """Validate against regex pattern."""
    
    def __init__(self, pattern: str, name: str = None, error_message: str = None, flags: int = 0):
        self.pattern = re.compile(pattern, flags)
        super().__init__(name or f"regex_{pattern}", error_message)
    
    def validate(self, value: Any) -> ValidationResult:
        str_value = str(value)
        if self.pattern.match(str_value):
            return ValidationResult(is_valid=True, cleaned_value=str_value)
        return ValidationResult(is_valid=False, errors=[self.error_message])


class LengthRule(ValidationRule):
    """Validate string/list length."""
    
    def __init__(self, min_length: int = None, max_length: int = None, 
                 name: str = None, error_message: str = None):
        self.min_length = min_length
        self.max_length = max_length
        super().__init__(
            name or f"length_{min_length}_{max_length}",
            error_message or f"Length must be between {min_length} and {max_length}"
        )
    
    def validate(self, value: Any) -> ValidationResult:
        length = len(value) if hasattr(value, '__len__') else 0
        
        if self.min_length is not None and length < self.min_length:
            return ValidationResult(is_valid=False, errors=[f"Too short (minimum {self.min_length})"])
        
        if self.max_length is not None and length > self.max_length:
            return ValidationResult(is_valid=False, errors=[f"Too long (maximum {self.max_length})"])
        
        return ValidationResult(is_valid=True, cleaned_value=value)


class TypeRule(ValidationRule):
    """Validate value type."""
    
    def __init__(self, expected_type: type, name: str = None, error_message: str = None):
        self.expected_type = expected_type
        
        # Handle tuple types for name generation
        if isinstance(expected_type, tuple):
            type_names = [t.__name__ for t in expected_type]
            type_name = "_or_".join(type_names)
            default_name = f"type_{type_name}"
            default_message = f"Expected one of types: {', '.join(type_names)}"
        else:
            type_name = expected_type.__name__
            default_name = f"type_{type_name}"
            default_message = f"Expected type {type_name}"
        
        super().__init__(
            name or default_name,
            error_message or default_message
        )
    
    def validate(self, value: Any) -> ValidationResult:
        if isinstance(value, self.expected_type):
            return ValidationResult(is_valid=True, cleaned_value=value)
        
        # Try type conversion for common cases
        try:
            if self.expected_type == int:
                cleaned = int(value)
            elif self.expected_type == float:
                cleaned = float(value)
            elif self.expected_type == str:
                cleaned = str(value)
            elif self.expected_type == bool:
                if isinstance(value, str):
                    cleaned = value.lower() in ('true', '1', 'yes', 'on')
                else:
                    cleaned = bool(value)
            else:
                return ValidationResult(is_valid=False, errors=[self.error_message])
            
            return ValidationResult(is_valid=True, cleaned_value=cleaned)
        except (ValueError, TypeError):
            return ValidationResult(is_valid=False, errors=[self.error_message])


class ChoiceRule(ValidationRule):
    """Validate value is in allowed choices."""
    
    def __init__(self, choices: List[Any], case_sensitive: bool = True,
                 name: str = None, error_message: str = None):
        self.choices = choices
        self.case_sensitive = case_sensitive
        super().__init__(
            name or f"choice_{len(choices)}",
            error_message or f"Must be one of: {', '.join(map(str, choices))}"
        )
    
    def validate(self, value: Any) -> ValidationResult:
        if self.case_sensitive:
            if value in self.choices:
                return ValidationResult(is_valid=True, cleaned_value=value)
        else:
            str_value = str(value).lower()
            str_choices = [str(c).lower() for c in self.choices]
            if str_value in str_choices:
                # Return original choice value
                index = str_choices.index(str_value)
                return ValidationResult(is_valid=True, cleaned_value=self.choices[index])
        
        return ValidationResult(is_valid=False, errors=[self.error_message])


class PathRule(ValidationRule):
    """Validate file/directory paths."""
    
    def __init__(self, must_exist: bool = False, must_be_file: bool = False,
                 must_be_dir: bool = False, create_dirs: bool = False,
                 allowed_extensions: Set[str] = None, name: str = None):
        self.must_exist = must_exist
        self.must_be_file = must_be_file
        self.must_be_dir = must_be_dir
        self.create_dirs = create_dirs
        self.allowed_extensions = allowed_extensions or set()
        super().__init__(name or "path_validation")
    
    def validate(self, value: Any) -> ValidationResult:
        try:
            path = Path(str(value))
            errors = []
            warnings = []
            
            # Resolve to absolute path
            try:
                resolved_path = path.resolve()
            except (OSError, RuntimeError) as e:
                return ValidationResult(is_valid=False, errors=[f"Invalid path: {e}"])
            
            # Check if path exists
            if self.must_exist and not resolved_path.exists():
                errors.append(f"Path does not exist: {resolved_path}")
            
            # Check file vs directory
            if resolved_path.exists():
                if self.must_be_file and not resolved_path.is_file():
                    errors.append(f"Path must be a file: {resolved_path}")
                if self.must_be_dir and not resolved_path.is_dir():
                    errors.append(f"Path must be a directory: {resolved_path}")
            
            # Check file extension
            if self.allowed_extensions and resolved_path.suffix:
                if resolved_path.suffix.lower() not in self.allowed_extensions:
                    errors.append(f"File extension must be one of: {', '.join(self.allowed_extensions)}")
            
            # Create directories if requested
            if self.create_dirs and not resolved_path.parent.exists():
                try:
                    resolved_path.parent.mkdir(parents=True, exist_ok=True)
                    warnings.append(f"Created directory: {resolved_path.parent}")
                except OSError as e:
                    errors.append(f"Cannot create directory: {e}")
            
            # Security checks
            try:
                # Check for path traversal
                if ".." in str(resolved_path):
                    warnings.append("Path contains '..' - potential security risk")
                
                # Check for suspicious characters
                suspicious_chars = ['<', '>', '|', '*', '?']
                if any(char in str(resolved_path) for char in suspicious_chars):
                    warnings.append("Path contains suspicious characters")
                    
            except Exception:
                pass  # Skip security checks if they fail
            
            if errors:
                return ValidationResult(is_valid=False, errors=errors, warnings=warnings)
            
            return ValidationResult(is_valid=True, cleaned_value=str(resolved_path), warnings=warnings)
            
        except Exception as e:
            return ValidationResult(is_valid=False, errors=[f"Path validation failed: {e}"])


class URLRule(ValidationRule):
    """Validate URLs."""
    
    def __init__(self, allowed_schemes: Set[str] = None, require_netloc: bool = True,
                 name: str = None):
        schemes = set(allowed_schemes) if allowed_schemes else {'http', 'https'}
        if not require_netloc and allowed_schemes is None:
            schemes = schemes | {'file'}
        self.allowed_schemes = schemes
        self.require_netloc = require_netloc
        super().__init__(name or "url_validation")
    
    def validate(self, value: Any) -> ValidationResult:
        try:
            url = str(value).strip()
            parsed = urlparse(url)
            errors = []
            
            # Check scheme
            if parsed.scheme not in self.allowed_schemes:
                errors.append(f"URL scheme must be one of: {', '.join(self.allowed_schemes)}")
            
            # Check netloc (domain)
            if self.require_netloc and not parsed.netloc:
                errors.append("URL must have a valid domain")
            
            # Basic format validation
            if not url.startswith(tuple(f"{scheme}://" for scheme in self.allowed_schemes)):
                errors.append("URL must start with a valid scheme")
            
            if errors:
                return ValidationResult(is_valid=False, errors=errors)
            
            return ValidationResult(is_valid=True, cleaned_value=url)
            
        except Exception as e:
            return ValidationResult(is_valid=False, errors=[f"URL validation failed: {e}"])


class JSONRule(ValidationRule):
    """Validate JSON strings."""
    
    def __init__(self, name: str = None):
        super().__init__(name or "json_validation")
    
    def validate(self, value: Any) -> ValidationResult:
        try:
            if isinstance(value, (dict, list)):
                # Already parsed JSON
                return ValidationResult(is_valid=True, cleaned_value=value)
            
            str_value = str(value).strip()
            parsed = json.loads(str_value)
            return ValidationResult(is_valid=True, cleaned_value=parsed)
            
        except (json.JSONDecodeError, ValueError) as e:
            return ValidationResult(is_valid=False, errors=[f"Invalid JSON: {e}"])


class Validator:
    """Main validation engine."""
    
    def __init__(self):
        self.logger = logging.getLogger("codeinsight.validator")
        
        # Predefined validation sets
        self.common_rules = {
            'filename': [
                RegexRule(r'^[a-zA-Z0-9_\-\.]+$', 'filename_chars', 
                         'Filename can only contain letters, numbers, underscore, hyphen, and dot'),
                LengthRule(1, 255)
            ],
            'command_name': [
                RegexRule(r'^[a-zA-Z][a-zA-Z0-9_\-]*$', 'command_name', 
                         'Command name must start with letter and contain only letters, numbers, underscore, hyphen'),
                LengthRule(1, 50)
            ],
            'api_key': [
                RegexRule(r'^[a-zA-Z0-9\-_]+$', 'api_key', 'API key contains invalid characters'),
                LengthRule(10, 200)
            ],
            'url': [URLRule()],
            'file_path': [PathRule()],
            'directory_path': [PathRule(must_be_dir=True)],
            'config_value': [
                TypeRule((str, int, float, bool)),
                LengthRule(0, 1000)
            ]
        }
    
    def validate_input(self, value: Any, rules: List[ValidationRule]) -> ValidationResult:
        """Validate value against a list of rules."""
        all_errors = []
        all_warnings = []
        cleaned_value = value
        
        for rule in rules:
            result = rule.validate(cleaned_value)
            
            if not result.is_valid:
                all_errors.extend(result.errors)
                # Stop on first error for stricter validation
                break
            
            all_warnings.extend(result.warnings)
            cleaned_value = result.cleaned_value
        
        return ValidationResult(
            is_valid=len(all_errors) == 0,
            cleaned_value=cleaned_value,
            errors=all_errors,
            warnings=all_warnings
        )
    
    def validate_by_type(self, value: Any, validation_type: str) -> ValidationResult:
        """Validate using predefined rule sets."""
        if validation_type not in self.common_rules:
            return ValidationResult(is_valid=False, errors=[f"Unknown validation type: {validation_type}"])
        
        return self.validate_input(value, self.common_rules[validation_type])
    
    def sanitize_string(self, value: str, max_length: int = 1000, 
                       allowed_chars: str = None) -> str:
        """Sanitize string input."""
        if not isinstance(value, str):
            value = str(value)
        
        # Truncate if too long
        if len(value) > max_length:
            value = value[:max_length]
        
        # Filter allowed characters
        if allowed_chars:
            value = ''.join(c for c in value if c in allowed_chars)
        
        # Remove control characters except common whitespace
        value = ''.join(c for c in value if ord(c) >= 32 or c in '\t\n\r')
        
        return value.strip()
    
    def sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for safe filesystem operations."""
        # Remove path separators
        filename = filename.replace('/', '_').replace('\\', '_')
        
        # Remove dangerous characters
        dangerous_chars = '<>:"|?*'
        for char in dangerous_chars:
            filename = filename.replace(char, '_')
        
        # Remove control characters
        filename = ''.join(c for c in filename if ord(c) >= 32)
        
        # Truncate and ensure not empty
        filename = filename[:255].strip()
        if not filename:
            filename = 'unnamed_file'
        
        return filename
    
    def validate_config_data(self, config_data: Dict[str, Any]) -> ValidationResult:
        """Validate configuration data structure."""
        errors = []
        warnings = []
        cleaned_config = {}
        
        try:
            # Validate structure
            if not isinstance(config_data, dict):
                return ValidationResult(is_valid=False, errors=["Config must be a dictionary"])
            
            # Validate each key-value pair
            for key, value in config_data.items():
                # Validate key
                key_result = self.validate_input(key, [
                    TypeRule(str),
                    RegexRule(r'^[a-zA-Z][a-zA-Z0-9_]*$', 'config_key'),
                    LengthRule(1, 50)
                ])
                
                if not key_result.is_valid:
                    errors.extend([f"Config key '{key}': {err}" for err in key_result.errors])
                    continue
                
                # Validate value
                value_result = self.validate_by_type(value, 'config_value')
                if not value_result.is_valid:
                    warnings.extend([f"Config value '{key}': {warn}" for warn in value_result.errors])
                    # Keep original value but warn
                    cleaned_config[key_result.cleaned_value] = value
                else:
                    cleaned_config[key_result.cleaned_value] = value_result.cleaned_value
                    warnings.extend([f"Config value '{key}': {warn}" for warn in value_result.warnings])
            
            return ValidationResult(
                is_valid=len(errors) == 0,
                cleaned_value=cleaned_config,
                errors=errors,
                warnings=warnings
            )
            
        except Exception as e:
            return ValidationResult(is_valid=False, errors=[f"Config validation failed: {e}"])
    
    def validate_command_args(self, args: List[str]) -> ValidationResult:
        """Validate command line arguments."""
        errors = []
        warnings = []
        cleaned_args = []
        
        for i, arg in enumerate(args):
            # Basic sanitization
            sanitized_arg = self.sanitize_string(arg, max_length=500)
            
            # Check for suspicious patterns
            suspicious_patterns = [
                r'[;&|]',  # Command injection
                r'\$\(',   # Command substitution
                r'`',      # Backticks
                r'\.\./',  # Path traversal
            ]
            
            for pattern in suspicious_patterns:
                if re.search(pattern, sanitized_arg):
                    warnings.append(f"Argument {i} contains suspicious pattern: {pattern}")
            
            cleaned_args.append(sanitized_arg)
        
        return ValidationResult(
            is_valid=True,
            cleaned_value=cleaned_args,
            warnings=warnings
        )


def validate_input(value: Any, validation_type: str) -> ValidationResult:
    """Convenience function for input validation."""
    validator = Validator()
    return validator.validate_by_type(value, validation_type)


def sanitize_user_input(value: str, max_length: int = 1000) -> str:
    """Convenience function for string sanitization."""
    validator = Validator()
    return validator.sanitize_string(value, max_length)


def safe_path(path_input: str, must_exist: bool = False, 
              create_dirs: bool = False) -> ValidationResult:
    """Convenience function for safe path handling."""
    rule = PathRule(must_exist=must_exist, create_dirs=create_dirs)
    return rule.validate(path_input)


def validate_url(url: str, allowed_schemes: Set[str] = None) -> ValidationResult:
    """Convenience function for URL validation."""
    rule = URLRule(allowed_schemes=allowed_schemes)
    return rule.validate(url)


# Global validator instance
_validator = None

def get_validator() -> Validator:
    """Get global validator instance."""
    global _validator
    if _validator is None:
        _validator = Validator()
    return _validator
