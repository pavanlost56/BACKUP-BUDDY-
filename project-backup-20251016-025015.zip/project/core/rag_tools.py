"""
RAG tools for the CodeInsight agent system.
These tools wrap existing RAG functionality to make it available to the agent.
"""

import os
import json
import yaml
from typing import Dict, Any, List

from .tools import Tool
from .retriever import retrieve
from .llm_client import answer_query
from .suggester import create_fallback_response
from .scraper import fetch_and_save
from .embedder import build_embeddings


class RAGQueryTool(Tool):
    """Tool for querying documentation using RAG."""
    
    @property
    def name(self) -> str:
        return "rag_query_tool"
    
    @property
    def description(self) -> str:
        return "Query documentation using Retrieval-Augmented Generation (RAG). Finds relevant documentation chunks and generates answers."
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "query": "The documentation question to answer (required)",
            "framework": "Framework to search within (optional, default: react)",
            "top_k": "Number of context chunks to retrieve (optional, default: 5)"
        }
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute RAG query against documentation."""
        try:
            # Validate required parameters
            if not kwargs.get("query"):
                return {
                    "success": False,
                    "error": "Missing required parameter: query"
                }
            
            query = kwargs["query"]
            framework = kwargs.get("framework", "react")
            top_k_str = kwargs.get("top_k", "5")
            
            # Validate top_k parameter
            try:
                top_k = int(top_k_str)
                if top_k <= 0:
                    raise ValueError("top_k must be positive")
            except (ValueError, TypeError):
                return {
                    "success": False,
                    "error": f"Invalid top_k parameter: {top_k_str}. Must be a positive integer."
                }
            
            self.log_execution("rag_query", query=query, framework=framework, top_k=top_k)
            
            # Retrieve relevant documentation
            chunks = retrieve(query, framework, top_k)
            
            if not chunks:
                return {
                    "success": True,
                    "result": f"No documentation found for '{query}' in {framework} framework.",
                    "metadata": {"query": query, "framework": framework, "chunks_found": 0}
                }
            
            # Generate answer using LLM
            answer = answer_query(query, chunks)
            
            # Format output
            output = f"**Query:** {query}\n"
            output += f"**Framework:** {framework}\n"
            output += f"**Sources found:** {len(chunks)}\n\n"
            output += f"**Answer:**\n{answer}\n\n"
            output += "**Source chunks:**\n"
            for i, chunk in enumerate(chunks[:3], 1):  # Show first 3 chunks
                source = chunk.get("metadata", {}).get("source", "unknown")
                content = chunk.get("content", "")[:200] + "..." if len(chunk.get("content", "")) > 200 else chunk.get("content", "")
                output += f"{i}. From {source}: {content}\n"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "query": query,
                    "framework": framework,
                    "chunks_found": len(chunks),
                    "answer": answer
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"RAG query error: {str(e)}"
            }


class DocumentationScrapeTool(Tool):
    """Tool for scraping and updating documentation."""
    
    @property
    def name(self) -> str:
        return "doc_scrape_tool"
    
    @property
    def description(self) -> str:
        return "Scrape documentation from web sources and update local embeddings database."
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "framework": "Framework to scrape documentation for (required)",
            "force_update": "Whether to force update even if already exists (optional, default: false)"
        }
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute documentation scraping and embedding update."""
        try:
            # Validate required parameters
            if not kwargs.get("framework"):
                return {
                    "success": False,
                    "error": "Missing required parameter: framework"
                }
            
            framework = kwargs["framework"]
            force_update = kwargs.get("force_update", "false").lower() == "true"
            
            self.log_execution("doc_scrape", framework=framework, force_update=force_update)
            
            # Use the embedder's build_embeddings function which handles both scraping and embedding
            result = build_embeddings(framework)
            
            if not result or "error" in result:
                return {
                    "success": False,
                    "error": f"Failed to build embeddings for {framework}: {result.get('error', 'unknown error')}"
                }
            
            chunks_count = result.get("chunks_count", 0)
            
            output = f"Successfully built embeddings for {framework}.\n"
            output += f"Content chunks processed: {chunks_count}\n"
            output += f"Database path: {result.get('db_path', 'unknown')}"
            
            return {
                "success": True,
                "result": output,
                "metadata": {
                    "framework": framework,
                    "chunks_processed": chunks_count,
                    "force_update": force_update
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Documentation scrape error: {str(e)}"
            }


class FrameworkListTool(Tool):
    """Tool for listing available frameworks."""
    
    @property
    def name(self) -> str:
        return "framework_list_tool"
    
    @property
    def description(self) -> str:
        return "List all available frameworks that can be queried or updated."
    
    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "format": "Output format: 'text' or 'json' (optional, default: text)"
        }
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute framework listing."""
        try:
            output_format = kwargs.get("format", "text").lower()
            
            self.log_execution("framework_list", format=output_format)
            
            # Try to load from config file
            config_path = "configs/docs_sources.yaml"
            frameworks = []
            
            if os.path.exists(config_path):
                try:
                    with open(config_path, 'r') as f:
                        config = yaml.safe_load(f)
                        if config and "frameworks" in config:
                            # Convert config format to list
                            frameworks = []
                            for name, info in config["frameworks"].items():
                                frameworks.append({
                                    "name": name,
                                    "url": info.get("url", "unknown") if isinstance(info, dict) else str(info),
                                    "description": info.get("description", "") if isinstance(info, dict) else ""
                                })
                except Exception:
                    # Fallback to default if config load fails
                    pass
            
            # Default frameworks if no config
            if not frameworks:
                frameworks = [
                    {"name": "react", "url": "https://react.dev", "description": "React - The library for web and native user interfaces"},
                    {"name": "vue", "url": "https://vuejs.org", "description": "Vue.js - The Progressive JavaScript Framework"},
                    {"name": "angular", "url": "https://angular.io", "description": "Angular - The Modern Web Developer's Platform"},
                    {"name": "svelte", "url": "https://svelte.dev", "description": "Svelte - Cybernetically enhanced web apps"},
                    {"name": "next", "url": "https://nextjs.org", "description": "Next.js - The React Framework"},
                    {"name": "nuxt", "url": "https://nuxt.com", "description": "Nuxt - The Vue Framework"}
                ]
            
            if output_format == "json":
                result = json.dumps(frameworks, indent=2)
            else:
                # Text format
                result = "Available frameworks:\n\n"
                for fw in frameworks:
                    name = fw.get("name", "unknown")
                    url = fw.get("url", "unknown")
                    desc = fw.get("description", "")
                    if desc:
                        result += f"• **{name}**: {desc} ({url})\n"
                    else:
                        result += f"• **{name}**: {url}\n"
            
            return {
                "success": True,
                "result": result,
                "metadata": {
                    "frameworks_count": len(frameworks),
                    "format": output_format
                }
            }
                
        except Exception as e:
            return {
                "success": False,
                "error": f"Framework list error: {str(e)}"
            }