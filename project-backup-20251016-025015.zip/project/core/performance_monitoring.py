"""
Performance monitoring and optimization system for CodeInsight.
Provides comprehensive timing metrics, resource monitoring, and optimization insights.
"""

import time
import psutil
import threading
import functools
import json
import gc
import statistics
from pathlib import Path
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from collections import defaultdict, deque
from enum import Enum
import json
import statistics
import gc
import sys
import os

from .logging_system import get_logger, get_performance_logger


class MetricType(Enum):
    """Types of performance metrics."""
    DURATION = "duration"
    MEMORY = "memory" 
    CPU = "cpu"
    DISK = "disk"
    NETWORK = "network"
    CACHE = "cache"
    DATABASE = "database"
    CUSTOM = "custom"


class PerformanceLevel(Enum):
    """Performance level classifications."""
    EXCELLENT = "excellent"    # < 100ms
    GOOD = "good"             # 100ms - 500ms
    ACCEPTABLE = "acceptable"  # 500ms - 2s
    SLOW = "slow"             # 2s - 10s
    CRITICAL = "critical"     # > 10s


@dataclass
class MetricData:
    """Individual performance metric data point."""
    timestamp: float
    value: float
    metric_type: MetricType
    operation: str
    context: Dict[str, Any] = None
    tags: List[str] = None


@dataclass
class PerformanceSummary:
    """Summary of performance metrics for an operation."""
    operation: str
    total_calls: int
    avg_duration_ms: float
    min_duration_ms: float
    max_duration_ms: float
    p95_duration_ms: float
    p99_duration_ms: float
    success_rate: float
    error_count: int
    last_called: datetime
    performance_level: PerformanceLevel
    trend: str  # "improving", "stable", "degrading"


class PerformanceCollector:
    """Collects and aggregates performance metrics."""
    
    def __init__(self, max_metrics: int = 10000, data_dir: Optional[Path] = None):
        self.max_metrics = max_metrics
        self.metrics = deque(maxlen=max_metrics)
        self.operation_stats = defaultdict(list)
        self.lock = threading.Lock()
        self.logger = get_logger("performance")
        
        # System monitoring
        self.system_metrics = deque(maxlen=1000)
        self.monitoring_enabled = True
        
        # Persistence
        self.data_dir = data_dir or Path("data/performance")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.metrics_file = self.data_dir / "metrics.json"
        self.stats_file = self.data_dir / "operation_stats.json"
        
        # Load existing data
        self._load_data()
        
        # Start background monitoring
        self._start_system_monitoring()
    
    def __del__(self):
        """Ensure data is saved when the object is destroyed."""
        try:
            self._save_data()
        except Exception:
            pass  # Ignore errors during cleanup
    
    def _save_data(self):
        """Save metrics and operation stats to disk."""
        try:
            with self.lock:
                # Save operation stats (this is what we need for summaries)
                stats_data = {}
                for operation, stats_list in self.operation_stats.items():
                    stats_data[operation] = stats_list
                
                with open(self.stats_file, 'w') as f:
                    json.dump(stats_data, f, indent=2)
                
                self.logger.debug(f"Saved performance data to {self.stats_file}")
        except Exception as e:
            self.logger.error(f"Failed to save performance data: {e}")
    
    def _load_data(self):
        """Load metrics and operation stats from disk."""
        try:
            if self.stats_file.exists():
                with open(self.stats_file, 'r') as f:
                    stats_data = json.load(f)
                
                with self.lock:
                    # Restore operation stats
                    for operation, stats_list in stats_data.items():
                        self.operation_stats[operation] = stats_list
                
                self.logger.debug(f"Loaded performance data from {self.stats_file}")
        except Exception as e:
            self.logger.error(f"Failed to load performance data: {e}")
    
    def record_metric(self, operation: str, duration_ms: float, 
                     metric_type: MetricType = MetricType.DURATION,
                     context: Dict[str, Any] = None, 
                     tags: List[str] = None,
                     success: bool = True):
        """Record a performance metric."""
        metric = MetricData(
            timestamp=time.time(),
            value=duration_ms,
            metric_type=metric_type,
            operation=operation,
            context=context or {},
            tags=tags or []
        )
        
        with self.lock:
            self.metrics.append(metric)
            self.operation_stats[operation].append({
                'duration_ms': duration_ms,
                'timestamp': metric.timestamp,
                'success': success,
                'context': context or {}
            })
            
            # Keep only recent stats per operation
            if len(self.operation_stats[operation]) > 1000:
                self.operation_stats[operation] = self.operation_stats[operation][-500:]
        
        # Save data periodically (every 5th metric)
        if len(self.metrics) % 5 == 0:
            self._save_data()
    
    def get_operation_summary(self, operation: str) -> Optional[PerformanceSummary]:
        """Get performance summary for a specific operation."""
        with self.lock:
            if operation not in self.operation_stats:
                return None
            
            stats = self.operation_stats[operation]
            if not stats:
                return None
            
            durations = [s['duration_ms'] for s in stats]
            successes = [s['success'] for s in stats]
            
            avg_duration = statistics.mean(durations)
            min_duration = min(durations)
            max_duration = max(durations)
            
            # Calculate percentiles
            sorted_durations = sorted(durations)
            p95_duration = sorted_durations[int(len(sorted_durations) * 0.95)]
            p99_duration = sorted_durations[int(len(sorted_durations) * 0.99)]
            
            success_rate = sum(successes) / len(successes) if successes else 0
            error_count = len(successes) - sum(successes)
            
            last_called = datetime.fromtimestamp(max(s['timestamp'] for s in stats))
            
            # Determine performance level
            performance_level = self._classify_performance(avg_duration)
            
            # Calculate trend
            trend = self._calculate_trend(durations)
            
            return PerformanceSummary(
                operation=operation,
                total_calls=len(stats),
                avg_duration_ms=avg_duration,
                min_duration_ms=min_duration,
                max_duration_ms=max_duration,
                p95_duration_ms=p95_duration,
                p99_duration_ms=p99_duration,
                success_rate=success_rate,
                error_count=error_count,
                last_called=last_called,
                performance_level=performance_level,
                trend=trend
            )
    
    def get_all_summaries(self) -> List[PerformanceSummary]:
        """Get performance summaries for all operations."""
        summaries = []
        for operation in self.operation_stats.keys():
            summary = self.get_operation_summary(operation)
            if summary:
                summaries.append(summary)
        
        return sorted(summaries, key=lambda x: x.avg_duration_ms, reverse=True)
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """Get current system performance metrics."""
        try:
            # CPU and Memory
            cpu_percent = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            
            # Disk usage for current directory
            disk = psutil.disk_usage('.')
            
            # Network I/O
            net_io = psutil.net_io_counters()
            
            # Process-specific metrics
            process = psutil.Process()
            process_memory = process.memory_info()
            
            return {
                'cpu_percent': cpu_percent,
                'memory_total_gb': memory.total / (1024**3),
                'memory_available_gb': memory.available / (1024**3),
                'memory_used_percent': memory.percent,
                'disk_total_gb': disk.total / (1024**3),
                'disk_free_gb': disk.free / (1024**3),
                'disk_used_percent': (disk.used / disk.total) * 100,
                'network_bytes_sent': net_io.bytes_sent,
                'network_bytes_recv': net_io.bytes_recv,
                'process_memory_mb': process_memory.rss / (1024**2),
                'process_memory_vms_mb': process_memory.vms / (1024**2),
                'python_objects': len(gc.get_objects()),
                'timestamp': time.time()
            }
        except Exception as e:
            self.logger.warning(f"Failed to collect system metrics: {e}")
            return {'error': str(e), 'timestamp': time.time()}
    
    def _classify_performance(self, duration_ms: float) -> PerformanceLevel:
        """Classify performance level based on duration."""
        if duration_ms < 100:
            return PerformanceLevel.EXCELLENT
        elif duration_ms < 500:
            return PerformanceLevel.GOOD
        elif duration_ms < 2000:
            return PerformanceLevel.ACCEPTABLE
        elif duration_ms < 10000:
            return PerformanceLevel.SLOW
        else:
            return PerformanceLevel.CRITICAL
    
    def _calculate_trend(self, durations: List[float]) -> str:
        """Calculate performance trend from recent measurements."""
        if len(durations) < 10:
            return "insufficient_data"
        
        # Compare recent vs older measurements
        recent = durations[-10:]
        older = durations[-20:-10] if len(durations) >= 20 else durations[:-10]
        
        recent_avg = statistics.mean(recent)
        older_avg = statistics.mean(older)
        
        change_percent = ((recent_avg - older_avg) / older_avg) * 100
        
        if change_percent < -5:
            return "improving"
        elif change_percent > 5:
            return "degrading"
        else:
            return "stable"
    
    def _start_system_monitoring(self):
        """Start background system monitoring."""
        def monitor():
            while self.monitoring_enabled:
                try:
                    metrics = self.get_system_metrics()
                    self.system_metrics.append(metrics)
                    time.sleep(30)  # Collect every 30 seconds
                except Exception as e:
                    self.logger.error(f"System monitoring error: {e}")
                    time.sleep(60)  # Wait longer on error
        
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
    
    def get_recent_system_metrics(self, minutes: int = 5) -> List[Dict[str, Any]]:
        """Get system metrics from the last N minutes."""
        cutoff_time = time.time() - (minutes * 60)
        return [m for m in self.system_metrics if m.get('timestamp', 0) > cutoff_time]
    
    def export_metrics(self, filepath: str, format: str = "json"):
        """Export metrics to file."""
        data = {
            'performance_summaries': [asdict(s) for s in self.get_all_summaries()],
            'system_metrics': list(self.system_metrics),
            'export_timestamp': datetime.now().isoformat()
        }
        
        filepath = Path(filepath)
        if format.lower() == "json":
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2, default=str)
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def clear_metrics(self, older_than_hours: int = 24):
        """Clear old metrics to free memory."""
        cutoff_time = time.time() - (older_than_hours * 3600)
        
        with self.lock:
            # Clear old metrics
            self.metrics = deque(
                [m for m in self.metrics if m.timestamp > cutoff_time],
                maxlen=self.max_metrics
            )
            
            # Clear old operation stats
            for operation in self.operation_stats:
                self.operation_stats[operation] = [
                    s for s in self.operation_stats[operation]
                    if s['timestamp'] > cutoff_time
                ]
        
        # Save after cleanup
        self._save_data()


class PerformanceProfiler:
    """Advanced profiler for specific operations."""
    
    def __init__(self, operation: str, collector: PerformanceCollector):
        self.operation = operation
        self.collector = collector
        self.start_time = None
        self.context = {}
        self.tags = []
        
        # System state at start
        self.start_memory = None
        self.start_cpu_time = None
    
    def __enter__(self):
        self.start_time = time.perf_counter()
        
        # Capture initial system state
        try:
            process = psutil.Process()
            self.start_memory = process.memory_info().rss
            self.start_cpu_time = process.cpu_times()
        except Exception:
            pass
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration_ms = (time.perf_counter() - self.start_time) * 1000
        success = exc_type is None
        
        # Capture resource usage
        context = self.context.copy()
        try:
            process = psutil.Process()
            end_memory = process.memory_info().rss
            end_cpu_time = process.cpu_times()
            
            if self.start_memory:
                context['memory_delta_mb'] = (end_memory - self.start_memory) / (1024**2)
            
            if self.start_cpu_time:
                context['cpu_user_delta'] = end_cpu_time.user - self.start_cpu_time.user
                context['cpu_system_delta'] = end_cpu_time.system - self.start_cpu_time.system
        except Exception:
            pass
        
        if exc_type:
            context['error_type'] = exc_type.__name__
            context['error_message'] = str(exc_val)
        
        self.collector.record_metric(
            operation=self.operation,
            duration_ms=duration_ms,
            context=context,
            tags=self.tags,
            success=success
        )
    
    def add_context(self, **kwargs):
        """Add context data to be recorded with the metric."""
        self.context.update(kwargs)
    
    def add_tag(self, tag: str):
        """Add a tag to this performance measurement."""
        self.tags.append(tag)


def timed_operation(operation: str, collector: Optional[PerformanceCollector] = None):
    """Decorator to automatically time operations."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal collector
            if collector is None:
                collector = get_performance_monitor()
            
            with PerformanceProfiler(operation, collector) as profiler:
                # Add function metadata
                profiler.add_context(
                    function_name=func.__name__,
                    module=func.__module__,
                    args_count=len(args),
                    kwargs_count=len(kwargs)
                )
                
                return func(*args, **kwargs)
        
        return wrapper
    return decorator


class PerformanceOptimizer:
    """Provides optimization recommendations based on performance data."""
    
    def __init__(self, collector: PerformanceCollector):
        self.collector = collector
        self.logger = get_logger("optimizer")
    
    def analyze_bottlenecks(self) -> List[Dict[str, Any]]:
        """Analyze performance data to identify bottlenecks."""
        summaries = self.collector.get_all_summaries()
        bottlenecks = []
        
        for summary in summaries:
            issues = []
            
            # Check for slow operations
            if summary.performance_level in [PerformanceLevel.SLOW, PerformanceLevel.CRITICAL]:
                issues.append({
                    'type': 'slow_operation',
                    'severity': 'high' if summary.performance_level == PerformanceLevel.CRITICAL else 'medium',
                    'description': f"Operation takes {summary.avg_duration_ms:.1f}ms on average"
                })
            
            # Check for degrading performance
            if summary.trend == "degrading":
                issues.append({
                    'type': 'performance_degradation',
                    'severity': 'medium',
                    'description': "Performance is degrading over time"
                })
            
            # Check for high error rates
            if summary.error_count > 0 and summary.success_rate < 0.95:
                issues.append({
                    'type': 'high_error_rate',
                    'severity': 'high',
                    'description': f"Error rate: {(1-summary.success_rate)*100:.1f}%"
                })
            
            # Check for high variance (inconsistent performance)
            variance_ratio = (summary.max_duration_ms - summary.min_duration_ms) / summary.avg_duration_ms
            if variance_ratio > 2.0:
                issues.append({
                    'type': 'high_variance',
                    'severity': 'low',
                    'description': f"Inconsistent performance (variance ratio: {variance_ratio:.1f})"
                })
            
            if issues:
                bottlenecks.append({
                    'operation': summary.operation,
                    'issues': issues,
                    'metrics': asdict(summary)
                })
        
        return sorted(bottlenecks, key=lambda x: len(x['issues']), reverse=True)
    
    def get_optimization_recommendations(self) -> List[Dict[str, Any]]:
        """Get specific optimization recommendations."""
        bottlenecks = self.analyze_bottlenecks()
        recommendations = []
        
        for bottleneck in bottlenecks:
            operation = bottleneck['operation']
            for issue in bottleneck['issues']:
                rec = self._get_recommendation_for_issue(operation, issue)
                if rec:
                    recommendations.append(rec)
        
        # System-level recommendations
        system_metrics = self.collector.get_recent_system_metrics(minutes=5)
        if system_metrics:
            system_recs = self._get_system_recommendations(system_metrics)
            recommendations.extend(system_recs)
        
        return recommendations
    
    def _get_recommendation_for_issue(self, operation: str, issue: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Get recommendation for a specific performance issue."""
        issue_type = issue['type']
        
        if issue_type == 'slow_operation':
            if 'web' in operation.lower() or 'api' in operation.lower():
                return {
                    'operation': operation,
                    'type': 'caching',
                    'priority': 'high',
                    'description': 'Consider implementing or optimizing caching for web/API requests',
                    'implementation': 'Use @cached decorator with appropriate TTL'
                }
            elif 'database' in operation.lower() or 'query' in operation.lower():
                return {
                    'operation': operation,
                    'type': 'database_optimization',
                    'priority': 'high',
                    'description': 'Optimize database queries or add indexing',
                    'implementation': 'Review query patterns and consider batch operations'
                }
            elif 'embedding' in operation.lower():
                return {
                    'operation': operation,
                    'type': 'embedding_optimization',
                    'priority': 'medium',
                    'description': 'Consider batch processing or model optimization',
                    'implementation': 'Process embeddings in batches or use lighter models'
                }
        
        elif issue_type == 'high_error_rate':
            return {
                'operation': operation,
                'type': 'error_handling',
                'priority': 'high',
                'description': 'Improve error handling and resilience',
                'implementation': 'Add retry logic and better input validation'
            }
        
        elif issue_type == 'performance_degradation':
            return {
                'operation': operation,
                'type': 'monitoring',
                'priority': 'medium',
                'description': 'Monitor operation for memory leaks or resource issues',
                'implementation': 'Add resource monitoring and regular cleanup'
            }
        
        return None
    
    def _get_system_recommendations(self, system_metrics: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Get system-level optimization recommendations."""
        if not system_metrics:
            return []
        
        recommendations = []
        
        # Calculate averages
        avg_cpu = statistics.mean(m.get('cpu_percent', 0) for m in system_metrics if 'cpu_percent' in m)
        avg_memory = statistics.mean(m.get('memory_used_percent', 0) for m in system_metrics if 'memory_used_percent' in m)
        
        if avg_cpu > 80:
            recommendations.append({
                'operation': 'system',
                'type': 'cpu_optimization',
                'priority': 'high',
                'description': f'High CPU usage detected ({avg_cpu:.1f}% average)',
                'implementation': 'Consider optimizing algorithms or adding asynchronous processing'
            })
        
        if avg_memory > 85:
            recommendations.append({
                'operation': 'system',
                'type': 'memory_optimization',
                'priority': 'high',
                'description': f'High memory usage detected ({avg_memory:.1f}% average)',
                'implementation': 'Review memory usage patterns and implement cleanup routines'
            })
        
        return recommendations


# Global performance monitor instance
_performance_monitor = None

def get_performance_monitor() -> PerformanceCollector:
    """Get the global performance monitor instance."""
    global _performance_monitor
    if _performance_monitor is None:
        _performance_monitor = PerformanceCollector()
    return _performance_monitor

def profile_operation(operation: str) -> PerformanceProfiler:
    """Create a performance profiler for an operation."""
    return PerformanceProfiler(operation, get_performance_monitor())

def get_optimizer() -> PerformanceOptimizer:
    """Get a performance optimizer instance."""
    return PerformanceOptimizer(get_performance_monitor())