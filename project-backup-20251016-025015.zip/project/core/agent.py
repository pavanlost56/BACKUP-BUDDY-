"""
CodeInsight Agent - Main agent class for orchestrating tools and tasks.
Inspired by gemini-cli but focused on documentation and development assistance.
"""

import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum

from .tools import Tool, ToolRegistry
from .llm_client import call_ollama_generate

logger = logging.getLogger(__name__)


class AgentState(Enum):
    """Agent execution states."""
    IDLE = "idle"
    PLANNING = "planning"
    EXECUTING = "executing"
    COMPLETED = "completed"
    ERROR = "error"


@dataclass
class AgentStep:
    """Represents a single step in agent execution."""
    step_id: int
    tool_name: str
    parameters: Dict[str, Any]
    description: str
    executed: bool = False
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class CodeInsightAgent:
    """
    Main agent class for CodeInsight.
    
    Orchestrates tools to complete developer tasks while maintaining
    focus on documentation, code suggestions, and development assistance.
    """
    
    def __init__(self, tool_registry: ToolRegistry):
        self.tool_registry = tool_registry
        self.state = AgentState.IDLE
        self.current_task = ""
        self.execution_plan: List[AgentStep] = []
        self.step_counter = 0
        self.context = {}
    
    def accept_task(self, task: str) -> str:
        """
        Accept a task and return initial response.
        
        Args:
            task: The user's task description
            
        Returns:
            Initial response acknowledging the task
        """
        self.current_task = task
        self.state = AgentState.PLANNING
        self.execution_plan = []
        self.step_counter = 0
        self.context = {"task": task}
        
        logger.info(f"Agent accepted task: {task}")
        
        return f"📋 Task accepted: {task}\n🤔 Analyzing task and planning approach..."
    
    def plan_execution(self) -> List[AgentStep]:
        """
        Create an execution plan for the current task.
        Uses LLM to determine which tools to call and in what order.
        Falls back to simple heuristics if LLM unavailable.
        
        Returns:
            List of planned execution steps
        """
        self.state = AgentState.PLANNING
        
        # Build planning prompt
        tools_info = self._format_tools_for_prompt()
        planning_prompt = self._build_planning_prompt(self.current_task, tools_info)
        
        try:
            # Get plan from LLM
            plan_response = call_ollama_generate(planning_prompt)
            
            # Parse plan into steps
            steps = self._parse_plan_response(plan_response)
            self.execution_plan = steps
            
            logger.info(f"Generated plan with {len(steps)} steps")
            return steps
            
        except Exception as e:
            logger.error(f"Error planning execution: {e}")
            
            # Fallback: create simple plan based on task keywords
            fallback_steps = self._create_fallback_plan(self.current_task)
            self.execution_plan = fallback_steps
            
            logger.info(f"Using fallback plan with {len(fallback_steps)} steps")
            return fallback_steps
    
    def execute_plan(self, confirm_steps: bool = True) -> Dict[str, Any]:
        """
        Execute the planned steps.
        
        Args:
            confirm_steps: Whether to confirm each step before execution
            
        Returns:
            Execution results
        """
        if not self.execution_plan:
            return {"success": False, "error": "No execution plan available"}

        self.state = AgentState.EXECUTING
        results = []
        
        for step in self.execution_plan:
            if confirm_steps:
                logger.info(f"About to execute: {step.description}")
            
            try:
                result = self._execute_step(step)
                results.append(result)
                
                if not result.get("success", False):
                    logger.error(f"Step failed: {step.description}")
                    self.state = AgentState.ERROR
                    break
                    
            except Exception as e:
                logger.error(f"Error executing step {step.step_id}: {e}")
                step.error = str(e)
                self.state = AgentState.ERROR
                break
        
        if self.state != AgentState.ERROR:
            self.state = AgentState.COMPLETED
        
        return {
            "success": self.state == AgentState.COMPLETED,
            "steps_completed": len([r for r in results if r.get("success")]),
            "total_steps": len(self.execution_plan),
            "results": results
        }
    
    def execute_step(self, step) -> Dict[str, Any]:
        """
        Execute a single step (public method for external use).
        
        Args:
            step: The execution step to run
            
        Returns:
            Step execution result
        """
        return self._execute_step(step)
    
    def _execute_step(self, step: AgentStep) -> Dict[str, Any]:
        """Execute a single step."""
        logger.info(f"Executing step {step.step_id}: {step.tool_name}")
        
        try:
            tool = self.tool_registry.get_tool(step.tool_name)
            result = tool.execute(**step.parameters)
            
            step.executed = True
            step.result = result
            
            # Store result in context for future steps
            self.context[f"step_{step.step_id}_result"] = result
            
            return result
            
        except Exception as e:
            step.error = str(e)
            return {"success": False, "error": str(e)}
    
    def _format_tools_for_prompt(self) -> str:
        """Format available tools for the planning prompt."""
        tools = self.tool_registry.list_tools()
        tool_descriptions = []
        
        for tool in tools:
            tool_descriptions.append(
                f"- {tool['name']}: {tool['description']}\n"
                f"  Parameters: {tool['parameters']}"
            )
        
        return "\n".join(tool_descriptions)
    
    def _build_planning_prompt(self, task: str, tools_info: str) -> str:
        """Build the planning prompt for the LLM."""
        return f"""SYSTEM: You are CodeInsight Agent. You help developers with documentation, code suggestions, and development tasks. You receive a task and must create a plan using available tools.

TASK: {task}

AVAILABLE TOOLS:
{tools_info}

CONSTRAINTS:
- Only use available tools
- Focus on documentation, code assistance, development workflows
- Do not hallucinate or invent information
- Plan should be logical and step-by-step
- Each step must specify tool name and parameters

RESPONSE FORMAT:
Create a numbered plan where each step specifies:
1. TOOL: tool_name
   PARAMS: {{parameter: value}}
   DESCRIPTION: what this step accomplishes

Your plan:"""
    
    def _parse_plan_response(self, plan_response: str) -> List[AgentStep]:
        """
        Parse LLM response into execution steps.
        Simplified parser for now - can be enhanced later.
        """
        steps = []
        lines = plan_response.strip().split('\n')
        
        current_step = None
        step_id = 0
        
        for line in lines:
            line = line.strip()
            
            if line.startswith('TOOL:'):
                if current_step:
                    steps.append(current_step)
                
                step_id += 1
                tool_name = line.replace('TOOL:', '').strip()
                current_step = AgentStep(
                    step_id=step_id,
                    tool_name=tool_name,
                    parameters={},
                    description=""
                )
            
            elif line.startswith('PARAMS:') and current_step:
                # Simplified parameter parsing
                params_str = line.replace('PARAMS:', '').strip()
                # For now, just store as string - enhance later
                current_step.parameters = {"raw_params": params_str}
            
            elif line.startswith('DESCRIPTION:') and current_step:
                desc = line.replace('DESCRIPTION:', '').strip()
                current_step.description = desc
        
        if current_step:
            steps.append(current_step)
        
        return steps
    
    def _create_fallback_plan(self, task: str) -> List[AgentStep]:
        """
        Create a simple fallback plan when LLM is unavailable.
        Uses keyword matching to suggest appropriate tools for developer tasks.
        """
        steps = []
        task_lower = task.lower()
        
        # Web search patterns - for current/latest information
        if any(word in task_lower for word in [
            "latest", "newest", "recent", "current", "trending", "popular", 
            "github", "search", "find", "what's new", "updates", "releases",
            "breaking changes", "migration", "compare", "vs", "versus"
        ]):
            # Determine if it's a GitHub-specific query
            if any(word in task_lower for word in ["github", "repository", "repo", "trending", "releases"]):
                if "trending" in task_lower:
                    language = "javascript"  # default
                    languages = ["javascript", "python", "typescript", "react", "vue", "go", "rust"]
                    for lang in languages:
                        if lang in task_lower:
                            language = lang
                            break
                    
                    steps.append(AgentStep(
                        step_id=1,
                        tool_name="github_tool",
                        parameters={"action": "trending", "language": language, "limit": "5"},
                        description=f"Find trending {language} repositories on GitHub"
                    ))
                elif any(word in task_lower for word in ["releases", "version"]):
                    # Try to extract repo name or use a popular one as example
                    repo = "facebook/react"  # default
                    if "vue" in task_lower:
                        repo = "vuejs/vue"
                    elif "angular" in task_lower:
                        repo = "angular/angular"
                    
                    steps.append(AgentStep(
                        step_id=1,
                        tool_name="github_tool",
                        parameters={"action": "releases", "repo": repo, "limit": "3"},
                        description=f"Get recent releases for {repo}"
                    ))
                else:
                    # General GitHub search
                    query = task.replace("github", "").replace("repository", "").strip()
                    if not query:
                        query = "react"
                    
                    steps.append(AgentStep(
                        step_id=1,
                        tool_name="github_tool",
                        parameters={"action": "search_repos", "query": query, "limit": "5"},
                        description=f"Search GitHub repositories for: {query}"
                    ))
            else:
                # General web search
                steps.append(AgentStep(
                    step_id=1,
                    tool_name="web_search_tool",
                    parameters={"query": task, "max_results": "5"},
                    description=f"Search the web for: {task}"
                ))
        
        # URL fetch patterns
        elif any(word in task_lower for word in ["fetch", "get", "retrieve"]) and any(word in task_lower for word in ["url", "http", "link", "page"]):
            # Extract URL if possible, otherwise use placeholder
            url = "https://example.com"  # placeholder
            
            steps.append(AgentStep(
                step_id=1,
                tool_name="url_fetch_tool",
                parameters={"url": url, "extract_type": "text"},
                description=f"Fetch content from URL"
            ))
        
        # Documentation query patterns - for local knowledge
        elif any(word in task_lower for word in [
            "how to", "what is", "explain", "documentation", "docs", "guide", 
            "tutorial", "setup", "install", "configure", "create", "build",
            "component", "function", "method", "api", "example"
        ]):
            # Extract framework if mentioned
            framework = "react"  # default
            frameworks = ["react", "vue", "angular", "svelte", "next", "nuxt", 
                         "express", "flask", "django", "node", "webpack", "vite"]
            
            for fw in frameworks:
                if fw in task_lower:
                    framework = fw
                    break
            
            steps.append(AgentStep(
                step_id=1,
                tool_name="rag_query_tool",
                parameters={"query": task, "framework": framework, "top_k": "5"},
                description=f"Query {framework} documentation for: {task}"
            ))
        
        # Update/scrape patterns
        elif any(word in task_lower for word in [
            "update", "refresh", "scrape", "fetch", "download", "sync"
        ]):
            # Extract framework to update
            framework = "react"  # default
            frameworks = ["react", "vue", "angular", "svelte", "next", "nuxt"]
            
            for fw in frameworks:
                if fw in task_lower:
                    framework = fw
                    break
            
            steps.append(AgentStep(
                step_id=1,
                tool_name="doc_scrape_tool",
                parameters={"framework": framework, "force_update": "true"},
                description=f"Update {framework} documentation and embeddings"
            ))
        
        # Framework listing patterns
        elif any(word in task_lower for word in [
            "list", "show", "available", "frameworks", "options"
        ]):
            steps.append(AgentStep(
                step_id=1,
                tool_name="framework_list_tool",
                parameters={},
                description="List all available frameworks"
            ))
        
        # Legacy dummy tool patterns (for testing)
        elif "echo" in task_lower or "hello" in task_lower:
            message = task.replace("echo", "").replace("hello", "hello").strip()
            if not message:
                message = "Hello from CodeInsight Agent"
            
            steps.append(AgentStep(
                step_id=1,
                tool_name="echo_tool",
                parameters={"message": message},
                description=f"Echo message: {message}"
            ))
        
        elif any(op in task_lower for op in ["add", "subtract", "multiply", "divide", "calculate"]):
            steps.append(AgentStep(
                step_id=1,
                tool_name="calculator_tool", 
                parameters={"operation": "add", "a": "2", "b": "3"},
                description="Perform basic calculation (fallback: 2+3)"
            ))
        
        else:
            # Default: treat as documentation query for local knowledge
            steps.append(AgentStep(
                step_id=1,
                tool_name="rag_query_tool",
                parameters={"query": task, "framework": "react", "top_k": "5"},
                description=f"Search documentation for: {task}"
            ))
        
        return steps
    
    def get_status(self) -> Dict[str, Any]:
        """Get current agent status."""
        return {
            "state": self.state.value,
            "current_task": self.current_task,
            "plan_steps": len(self.execution_plan),
            "completed_steps": len([s for s in self.execution_plan if s.executed]),
            "context_keys": list(self.context.keys())
        }