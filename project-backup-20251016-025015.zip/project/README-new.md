# CodeInsight - Local RAG-Powered Developer Assistant

<div align="center">

![Python](https://img.shields.io/badge/python-3.11+-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Status](https://img.shields.io/badge/status-Production-brightgreen.svg)

A powerful local developer assistant that scrapes official documentation, creates vector embeddings, and provides intelligent answers using local LLM inference via Ollama.

</div>

## 🌟 Features

- **Local RAG Pipeline**: Scrape, embed, and query documentation locally
- **Agent Mode**: Intelligent task planning and execution with tool orchestration  
- **Performance Monitoring**: Comprehensive metrics collection and optimization insights
- **Interactive UI**: Rich command-line interface with beautiful formatting
- **Safety Systems**: Error handling, rate limiting, input validation, and caching
- **Privacy-First**: All data stored locally, no paid APIs required
- **Production-Ready**: Comprehensive logging, configuration management, and deployment tools

## 🚀 Quick Start

### Prerequisites

- Python 3.11 or higher
- 8GB+ RAM recommended
- 2GB+ free disk space
- [Ollama](https://ollama.ai/) (optional but recommended)

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/pavanlost56/codeinsight-cli.git
   cd codeinsight-cli
   ```

2. **Run the installer:**
   ```bash
   python install.py
   ```

3. **Verify installation:**
   ```bash
   python cli.py --help
   ```

### Optional: Setup Ollama

For enhanced functionality, install Ollama:

1. Download from [ollama.ai](https://ollama.ai/)
2. Install and start the service
3. Pull a model: `ollama pull llama3.2`

## 📖 Usage

### Basic Commands

```bash
# Update documentation for a framework
python cli.py update react

# Query the documentation  
python cli.py query "How do I create a component?" --framework react

# Use interactive agent mode
python cli.py agent

# Monitor performance
python cli.py perf stats

# View command history
python cli.py history

# Manage cache
python cli.py cache stats
```

### Agent Mode

CodeInsight features an intelligent agent that can plan and execute complex development tasks:

```bash
python cli.py agent "Create a React component that fetches data from an API"
```

The agent can:
- Plan multi-step solutions
- Search documentation
- Execute web searches
- Provide code examples
- Suggest follow-up actions

### Performance Monitoring

Track and optimize your CodeInsight usage:

```bash
# View performance statistics
python cli.py perf stats --detailed

# Analyze bottlenecks
python cli.py perf analyze

# Monitor system metrics
python cli.py perf system-metrics

# Export performance data
python cli.py perf stats --export report.json
```

### Configuration Management

Customize CodeInsight behavior:

```bash
# View current configuration
python cli.py config show

# Update settings
python cli.py config set ollama.model llama3.2
python cli.py config set cache.ttl_hours 48

# Backup configuration
python cli.py config backup
```

## 🏗️ Architecture

### Core Components

- **CLI Interface** (`cli.py`): Command-line interface with rich formatting
- **Agent System** (`core/agent.py`): Task planning and tool orchestration
- **RAG Pipeline**: 
  - **Scraper** (`core/scraper.py`): Web scraping with robots.txt compliance
  - **Embedder** (`core/embedder.py`): Text chunking and vector creation
  - **Retriever** (`core/retriever.py`): Similarity search and context retrieval
  - **LLM Client** (`core/llm_client.py`): Ollama integration
- **Tools System** (`core/tools.py`): Extensible tool registry
- **Safety Systems**:
  - Error handling, rate limiting, input validation
  - Intelligent caching, configuration management
  - Comprehensive logging and performance monitoring

### Data Flow

1. **Documentation Scraping**: Fetch and clean web content
2. **Text Processing**: Chunk and embed documents
3. **Query Processing**: Vector similarity search
4. **Answer Generation**: LLM-powered responses with citations
5. **Agent Planning**: Multi-step task execution

## 🛠️ Development

### Project Structure

```
codeinsight-project/
├── cli.py                 # Main CLI entry point
├── core/                  # Core functionality modules
│   ├── agent.py          # Agent system
│   ├── embedder.py       # Text embedding
│   ├── retriever.py      # Vector search
│   ├── llm_client.py     # LLM integration
│   ├── scraper.py        # Web scraping
│   ├── tools.py          # Tool system
│   └── ...               # Safety and utility modules
├── data/                  # Local data storage
│   ├── docs/             # Scraped documentation
│   ├── db/               # Vector databases
│   ├── cache/            # Cache storage
│   └── performance/      # Performance metrics
├── configs/              # Configuration files
├── logs/                 # Application logs
└── tests/                # Test suite
```

### Running Tests

```bash
# Run all tests
python -m pytest tests/

# Run specific test module
python -m pytest tests/test_agent.py -v

# Run with coverage
python -m pytest tests/ --cov=core --cov-report=html
```

### Adding New Tools

Create tools by extending the base Tool class:

```python
from core.tools import Tool, ToolRegistry

class MyTool(Tool):
    def execute(self, **kwargs):
        # Tool implementation
        return {"result": "success"}

# Register the tool
registry = ToolRegistry()
registry.register_tool("my_tool", MyTool())
```

## 📊 Performance Features

CodeInsight includes comprehensive performance monitoring:

- **Real-time Metrics**: Track operation timing and success rates
- **Bottleneck Analysis**: Identify slow operations automatically
- **System Monitoring**: CPU, memory, and disk usage tracking
- **Performance Trends**: Historical analysis and optimization suggestions
- **Export Capabilities**: Generate performance reports in JSON format

## 🔧 Configuration

### Environment Variables

```bash
# Ollama configuration
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2

# Cache configuration  
CODEINSIGHT_CACHE_TTL=48
CODEINSIGHT_CACHE_SIZE=1000

# Logging configuration
CODEINSIGHT_LOG_LEVEL=INFO
CODEINSIGHT_LOG_FORMAT=structured
```

### Configuration File

Edit `configs/docs_sources.yaml` to add new documentation sources:

```yaml
sources:
  my_framework:
    name: "My Framework"
    url: "https://myframework.dev/"
    description: "My framework documentation"
```

## 🚦 Production Deployment

### Docker Deployment

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
RUN python install.py

EXPOSE 8000
CMD ["python", "cli.py", "agent", "--server"]
```

### System Service

Create a systemd service for Linux:

```ini
[Unit]
Description=CodeInsight Assistant
After=network.target

[Service]
Type=simple
User=codeinsight
WorkingDirectory=/opt/codeinsight
ExecStart=/usr/bin/python3 cli.py agent --daemon
Restart=always

[Install]
WantedBy=multi-user.target
```

### Health Checks

Monitor service health:

```bash
# Check system status
python cli.py perf system-metrics

# Verify core functionality
python cli.py query "test" --framework react

# Monitor performance
python cli.py perf stats
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make changes and add tests
4. Run tests: `python -m pytest`
5. Commit changes: `git commit -m 'Add amazing feature'`
6. Push to branch: `git push origin feature/amazing-feature`
7. Open a Pull Request

### Development Guidelines

- Follow PEP 8 style guidelines
- Add type hints to all functions
- Include docstrings for modules and functions
- Write tests for new functionality
- Update documentation as needed

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Ollama](https://ollama.ai/) for local LLM inference
- [Rich](https://github.com/Textualize/rich) for beautiful CLI formatting
- [LangChain](https://python.langchain.com/) for RAG pipeline inspiration
- [scikit-learn](https://scikit-learn.org/) for vector operations

## 📞 Support

- 📖 **Documentation**: Check this README and inline help (`--help`)
- 🐛 **Bug Reports**: Open an issue on GitHub
- 💡 **Feature Requests**: Discuss in GitHub Discussions
- 📧 **Contact**: [Your contact information]

---

<div align="center">

**CodeInsight** - Empowering developers with local AI assistance

[🏠 Home](https://github.com/pavanlost56/codeinsight-cli) • [📖 Docs](README.md) • [🐛 Issues](https://github.com/pavanlost56/codeinsight-cli/issues) • [💬 Discussions](https://github.com/pavanlost56/codeinsight-cli/discussions)

</div>