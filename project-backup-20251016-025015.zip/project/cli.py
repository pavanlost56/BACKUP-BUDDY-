#!/usr/bin/env python3
"""
CodeInsight - A local RAG-powered CLI developer assistant.

Scrapes official documentation, embeds it into a local vector database,
and provides answers via local LLM (Ollama).
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import tempfile
import shutil
from pathlib import Path

from core.scraper import fetch_and_save
from core.embedder import build_embeddings
from core.retriever import retrieve
from core.llm_client import answer_query
from core.utils import ensure_directories, get_framework_url, list_available_frameworks
from core.suggester import (
    format_response_with_rich,
    create_fallback_response,
    validate_citation_metadata,
    suggest_follow_up_actions
)
from core.agent import CodeInsightAgent
from core.tools import ToolRegistry
from core.dummy_tools import EchoTool, CalculatorTool
from core.rag_tools import RAGQueryTool, DocumentationScrapeTool, FrameworkListTool
from core.web_tools import WebSearchTool, URLFetchTool, GitHubTool
from core.interactive_ui import create_interactive_ui
from core.command_history import get_command_history
from core.error_handling import safe_operation, ErrorCategory
from core.input_validation import validate_input, sanitize_user_input, safe_path, get_validator
from core.caching import get_cache
from core.configuration import get_config_manager
from core.logging_system import get_logger, get_performance_logger, log_context
from core.performance_monitoring import get_performance_monitor, get_optimizer, profile_operation
import time
import atexit

console = Console()
ui = create_interactive_ui(console)
command_history = get_command_history()
validator = get_validator()
config_manager = get_config_manager()

# Initialize logging and performance monitoring
logger = get_logger("cli")
performance_logger = get_performance_logger("cli")
performance_monitor = get_performance_monitor()

# Ensure performance data is saved on exit
atexit.register(lambda: performance_monitor._save_data())


@safe_operation(category=ErrorCategory.USER_INPUT, operation="track_command")
def track_command(func):
    """Decorator to track command execution in history."""
    import functools
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        command_name = func.__name__
        
        # Log command start
        logger.info(f"Executing command: {command_name}", extra={
            'extra_data': {'command': command_name, 'args_count': len(args), 'kwargs_count': len(kwargs)}
        })
        
        # Get arguments for tracking (excluding context and other click internals)
        import inspect
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()
        
        # Extract meaningful arguments
        tracked_args = []
        for param_name, value in bound_args.arguments.items():
            if param_name not in ['ctx', 'show_plan', 'confirm_steps', 'interactive', 'force', 'dry_run', 'list_frameworks', 'welcome']:
                if value is not None and value != False:  # Skip default falsy values
                    tracked_args.append(f"{param_name}={value}" if not isinstance(value, str) or ' ' in str(value) else str(value))
        
        success = False
        error_msg = None
        
        try:
            result = func(*args, **kwargs)
            success = True
            return result
        except Exception as e:
            error_msg = str(e)
            success = False
            logger.error(f"Command {command_name} failed: {error_msg}", extra={
                'extra_data': {'command': command_name, 'error': error_msg}
            })
            raise
        finally:
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Log command completion
            logger.info(f"Command {command_name} completed", extra={
                'extra_data': {'command': command_name, 'success': success, 'args': tracked_args},
                'performance_metrics': {'duration_ms': duration_ms, 'success': success}
            })
            
            command_history.add_entry(
                command=command_name,
                args=tracked_args,
                success=success,
                duration_ms=duration_ms,
                error=error_msg
            )
    
    return wrapper


@click.group()
@click.version_option(version="1.0.0")
@click.option('--welcome', is_flag=True, help="Show welcome banner")
def cli(welcome):
    """CodeInsight - Local RAG-powered developer assistant."""
    ensure_directories()
    
    if welcome:
        ui.show_welcome_banner()


@cli.command()
@click.argument("framework", required=False)
@click.option("--force", is_flag=True, help="Force update even if recent")
@click.option("--dry-run", is_flag=True, help="Show what would be updated")
@click.option("--list-frameworks", is_flag=True, help="List available frameworks")
@track_command
@safe_operation(category=ErrorCategory.USER_INPUT, operation="cli_command")
def update(framework, force, dry_run, list_frameworks):
    """Update documentation for a framework."""
    
    if list_frameworks:
        frameworks = list_available_frameworks()
        table = Table(title="Available Frameworks")
        table.add_column("Framework", style="cyan")
        table.add_column("Description", style="green")
        
        for name, description in frameworks.items():
            table.add_row(name, description)
        
        console.print(table)
        return
    
    if not framework:
        console.print("[yellow]Please specify a framework or use --list-frameworks to see available options[/yellow]")
        return
    
    # Validate framework name
    framework_result = validate_input(framework, "filename")
    if not framework_result.is_valid:
        console.print(f"[red]Invalid framework name: {', '.join(framework_result.errors)}[/red]")
        return
    framework = framework_result.cleaned_value
    
    if dry_run:
        url = get_framework_url(framework)
        console.print(f"[yellow]DRY RUN: Would update {framework} documentation from {url}[/yellow]")
        
        # Check if we have existing data
        docs_file = Path("data/docs") / f"{framework}.md"
        db_dir = Path("data/db") / framework
        
        if docs_file.exists():
            console.print(f"[blue]Found existing documentation: {docs_file}[/blue]")
        if db_dir.exists():
            console.print(f"[blue]Found existing database: {db_dir}[/blue]")
        
        return
    
    console.print(f"[blue]Updating {framework} documentation...[/blue]")
    
    # Get URL from configuration
    url = get_framework_url(framework)
    
    try:
        # Atomic update process
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create temporary structure
            temp_docs_dir = temp_path / "docs"
            temp_db_dir = temp_path / "db" 
            temp_docs_dir.mkdir(parents=True)
            temp_db_dir.mkdir(parents=True)
            
            # Save original working directory
            original_cwd = Path.cwd()
            
            try:
                # Interactive progress tracking
                with ui.create_progress_tracker(4, f"Updating {framework}") as tracker:
                    
                    # Step 1: Setup
                    tracker.update_step("Setting up workspace", "Creating temporary directories")
                    
                    # Work in temp directory for atomic operations
                    temp_work_dir = temp_path / "work"
                    temp_work_dir.mkdir()
                    
                    # Create temp data structure
                    (temp_work_dir / "data" / "docs").mkdir(parents=True)
                    (temp_work_dir / "data" / "db").mkdir(parents=True)
                    
                    # Change to temp work directory
                    import os
                    os.chdir(temp_work_dir)
                    
                    # Step 2: Scraping
                    tracker.update_step("Scraping documentation", f"Fetching from {url}")
                    
                    # Scrape documentation to temp location
                    metadata = fetch_and_save(url, framework)
                    console.print(f"[green]OK Scraped documentation to {metadata['file_path']}[/green]")
                    
                    # Step 3: Building embeddings  
                    tracker.update_step("Building embeddings", "Processing content chunks")
                    
                    # Build embeddings in temp location
                    embedding_result = build_embeddings(framework)
                    console.print(f"[green]OK Built embeddings for {framework}[/green]")
                    
                    # Restore working directory
                    os.chdir(original_cwd)
                    
                    # Step 4: Finalizing
                    tracker.update_step("Finalizing update", "Moving files to final location")
                    
                    # Atomic move to final locations (only if everything succeeded)
                    final_docs_dir = Path("data/docs")
                    final_db_dir = Path("data/db")
                    final_docs_dir.mkdir(parents=True, exist_ok=True)
                    final_db_dir.mkdir(parents=True, exist_ok=True)
                    
                    # Move documentation file
                    temp_doc_file = temp_work_dir / "data" / "docs" / f"{framework}.md"
                    final_doc_file = final_docs_dir / f"{framework}.md"
                    if temp_doc_file.exists():
                        shutil.move(str(temp_doc_file), str(final_doc_file))
                    
                    # Move database directory
                    temp_framework_db = temp_work_dir / "data" / "db" / framework
                    final_framework_db = final_db_dir / framework
                    if temp_framework_db.exists():
                        # Remove existing database if it exists
                        if final_framework_db.exists():
                            shutil.rmtree(final_framework_db)
                        shutil.move(str(temp_framework_db), str(final_framework_db))
                    
                    tracker.complete("Update completed successfully")
                
                # Success message with metadata
                success_metadata = {
                    "framework": framework,
                    "file_path": str(final_doc_file),
                    "vectors_count": embedding_result.get('vectors_count', 'unknown'),
                    "source_url": url
                }
                ui.show_success_with_metadata(f"Updated {framework} documentation", success_metadata)
                
            except Exception as e:
                # Restore working directory on error
                os.chdir(original_cwd)
                raise e
                
    except Exception as e:
        console.print(f"[red]Error updating {framework}: {e}[/red]")
        raise click.ClickException(str(e))


@cli.command()
@click.argument("query")
@click.option("--framework", default="react", help="Framework to search (default: react)")
@click.option("--top-k", default=5, help="Number of context chunks to retrieve")
@track_command
@safe_operation(category=ErrorCategory.USER_INPUT, operation="cli_command")
def query(query, framework, top_k):
    """Query the documentation for answers."""
    
    # Validate and sanitize inputs
    query = sanitize_user_input(query, max_length=500)
    if not query or len(query.strip()) < 3:
        console.print("[red]Query must be at least 3 characters long[/red]")
        return
    
    framework_result = validate_input(framework, "filename")
    if not framework_result.is_valid:
        console.print(f"[red]Invalid framework name: {', '.join(framework_result.errors)}[/red]")
        return
    framework = framework_result.cleaned_value
    
    try:
        top_k = int(top_k)
        if top_k < 1 or top_k > 20:
            top_k = 5
    except (ValueError, TypeError):
        top_k = 5
    
    console.print(f"[blue]Searching {framework} documentation for: {query}[/blue]")
    
    try:
        # Retrieve relevant context
        context_chunks = retrieve(query, framework, top_k)
        
        # Validate citation metadata
        if not validate_citation_metadata(context_chunks):
            fallback_panel = create_fallback_response(
                query, framework, context_chunks,
                "Context chunks missing required metadata"
            )
            console.print(fallback_panel)
            return
        
        try:
            # Generate answer using LLM
            answer = answer_query(query, context_chunks)
            
            # Format with rich panels
            formatted_panel = format_response_with_rich(
                answer, context_chunks, query, framework
            )
            console.print(formatted_panel)
            
            # Show follow-up suggestions
            suggestions = suggest_follow_up_actions(query, framework, context_chunks)
            if suggestions:
                suggestions_text = "\n".join([f"• {s}" for s in suggestions])
                suggestions_panel = Panel(
                    suggestions_text,
                    title="Suggested Next Steps",
                    border_style="magenta",
                    padding=(0, 1)
                )
                console.print(suggestions_panel)
        
        except Exception as llm_error:
            # Use fallback response for LLM errors
            fallback_panel = create_fallback_response(
                query, framework, context_chunks,
                f"LLM Error: {str(llm_error)}"
            )
            console.print(fallback_panel)
        
    except Exception as e:
        console.print(f"[red]Error processing query: {e}[/red]")
        raise click.ClickException(str(e))


@cli.command()
@click.argument("task")
@click.option("--confirm-steps", is_flag=True, default=False, help="Confirm each step before execution")
@click.option("--show-plan", is_flag=True, default=True, help="Show execution plan before running")
@click.option("--interactive", is_flag=True, default=True, help="Use interactive UI features")
@track_command
def agent(task, confirm_steps, show_plan, interactive):
    """
    Run CodeInsight Agent to complete development tasks.
    
    Examples:
      codeinsight agent "how to create React hooks?"
      codeinsight agent "update vue documentation" 
      codeinsight agent "list available frameworks"
      codeinsight agent "find trending Python libraries"
    """
    
    if interactive:
        console.print(f"[blue]🤖 CodeInsight Agent starting...[/blue]")
        console.print(f"[dim]Task: {task}[/dim]\n")
    
    try:
        # Initialize tool registry with all tools
        registry = ToolRegistry()
        
        # RAG tools for documentation and framework management
        registry.register(RAGQueryTool())
        registry.register(DocumentationScrapeTool())
        registry.register(FrameworkListTool())
        
        # Web tools for real-time information
        registry.register(WebSearchTool())
        registry.register(URLFetchTool())
        registry.register(GitHubTool())
        
        # Keep dummy tools for testing/fallback
        registry.register(EchoTool())
        registry.register(CalculatorTool())
        
        # Create agent
        agent_instance = CodeInsightAgent(registry)
        
        # Accept task
        response = agent_instance.accept_task(task)
        if interactive:
            console.print(Panel(response, title="Task Accepted", border_style="green"))
        
        # Plan execution
        if interactive:
            console.print("[yellow]🧠 Planning execution...[/yellow]")
            
        steps = agent_instance.plan_execution()
        
        if not steps:
            if interactive:
                ui.show_error_with_suggestions(
                    "Failed to create execution plan",
                    [
                        "Try rephrasing your task",
                        "Be more specific about what you want",
                        "Check if the task requires available tools"
                    ]
                )
            else:
                console.print("[red]❌ Failed to create execution plan[/red]")
            return
        
        # Interactive plan approval
        if interactive and show_plan:
            # Convert steps to format expected by UI
            planned_steps = []
            for step in steps:
                planned_steps.append({
                    "tool_name": step.tool_name,
                    "action": "execute", 
                    "parameters": step.parameters
                })
            
            # Show plan and get approval
            if not ui.show_agent_planning(task, planned_steps):
                console.print("[yellow]⏹️ Execution cancelled by user[/yellow]")
                return
        
        elif show_plan and not interactive:
            # Non-interactive plan display
            plan_text = "\n".join([
                f"{i+1}. **{step.tool_name}**: {step.description}"
                for i, step in enumerate(steps)
            ])
            
            plan_panel = Panel(
                plan_text,
                title=f"Execution Plan ({len(steps)} steps)",
                border_style="blue"
            )
            console.print(plan_panel)
            
            if confirm_steps:
                from rich.prompt import Confirm
                if not Confirm.ask("Execute this plan?"):
                    console.print("[yellow]⏹️ Execution cancelled by user[/yellow]")
                    return
        
        # Execute plan with progress tracking
        if interactive:
            console.print("[green]⚡ Executing plan...[/green]")
            
            # Use progress tracker for step execution
            with ui.create_progress_tracker(len(steps), "Executing agent plan") as tracker:
                result = {"success": True, "results": [], "steps_completed": 0, "total_steps": len(steps)}
                
                for i, step in enumerate(steps):
                    tracker.update_step(f"Running {step.tool_name}", f"Parameters: {step.parameters}")
                    
                    # Execute individual step
                    step_result = agent_instance.execute_step(step)
                    result["results"].append(step_result)
                    result["steps_completed"] += 1
                    
                    if not step_result.get("success"):
                        result["success"] = False
                        break
                        
                    # Show intermediate result if interactive
                    if step_result.get("success") and "result" in step_result:
                        step_output = step_result["result"]
                        if step_output and isinstance(step_output, str) and len(step_output.strip()) > 0:
                            # Show preview during execution
                            preview = step_output[:150] + "..." if len(step_output) > 150 else step_output
                            console.print(f"[dim]Step {i+1} preview: {preview}[/dim]")
                
                tracker.complete("Plan execution completed")
        else:
            # Non-interactive execution
            console.print("[green]⚡ Executing plan...[/green]")
            result = agent_instance.execute_plan(confirm_steps=confirm_steps)
        
        # Show results with enhanced formatting
        if result["success"]:
            if interactive:
                success_metadata = {
                    "steps_completed": f"{result['steps_completed']}/{result['total_steps']}",
                    "task": task,
                    "tools_used": len(set(step.tool_name for step in steps))
                }
                ui.show_success_with_metadata("Task completed successfully!", success_metadata)
            else:
                console.print(f"[green]✅ Task completed successfully![/green]")
                console.print(f"[blue]Steps completed: {result['steps_completed']}/{result['total_steps']}[/blue]")
            
            # Show tool outputs if available
            if "results" in result:
                for i, step_result in enumerate(result["results"], 1):
                    if step_result.get("success") and "result" in step_result:
                        step_output = step_result["result"]
                        if step_output and isinstance(step_output, str) and len(step_output.strip()) > 0:
                            output_panel = Panel(
                                step_output,
                                title=f"Step {i} Output",
                                border_style="green"
                            )
                            console.print(output_panel)
        else:
            if interactive:
                # Enhanced error display with suggestions
                error_msg = f"Task failed at step {result['steps_completed']}/{result['total_steps']}"
                suggestions = [
                    "Check your internet connection for web tools",
                    "Verify the framework name is correct",
                    "Try breaking the task into smaller parts",
                    "Check if required documentation is available locally"
                ]
                ui.show_error_with_suggestions(error_msg, suggestions)
            else:
                console.print(f"[red]❌ Task failed[/red]")
                console.print(f"[blue]Steps completed: {result['steps_completed']}/{result['total_steps']}[/blue]")
            
            # Show error details if available
            if "results" in result:
                for i, step_result in enumerate(result["results"], 1):
                    if not step_result.get("success") and "error" in step_result:
                        error_panel = Panel(
                            step_result["error"],
                            title=f"Step {i} Error",
                            border_style="red"
                        )
                        console.print(error_panel)
        
        # Show agent status (always show this)
        status = agent_instance.get_status()
        status_panel = Panel(
            f"**State**: {status['state']}\n"
            f"**Task**: {status['current_task']}\n"
            f"**Plan Steps**: {status['plan_steps']}\n"
            f"**Completed**: {status['completed_steps']}",
            title="Agent Status",
            border_style="cyan"
        )
        console.print(status_panel)
        
    except Exception as e:
        console.print(f"[red]Agent error: {e}[/red]")
        raise click.ClickException(str(e))


@cli.command()
@click.option("--recent", "-r", default=10, help="Show N recent commands")
@click.option("--stats", is_flag=True, help="Show command usage statistics")
@click.option("--search", "-s", help="Search command history")
@click.option("--failed", is_flag=True, help="Show recent failed commands")
@click.option("--clear", is_flag=True, help="Clear command history")
def history(recent, stats, search, failed, clear):
    """View and manage command history."""
    
    if clear:
        from rich.prompt import Confirm
        if Confirm.ask("[red]Clear all command history?[/red]"):
            command_history.clear_history()
            ui.show_success_with_metadata("Command history cleared")
        return
    
    if stats:
        stats_data = command_history.get_command_stats()
        
        # Create stats table
        table = Table(title="Command Usage Statistics", show_header=True, header_style="bold cyan")
        table.add_column("Metric", style="yellow", width=20)
        table.add_column("Value", style="green")
        
        table.add_row("Total Commands", str(stats_data.get("total_commands", 0)))
        table.add_row("Successful", str(stats_data.get("successful_commands", 0)))
        table.add_row("Failed", str(stats_data.get("failed_commands", 0)))
        table.add_row("Success Rate", f"{stats_data.get('success_rate', 0):.1%}")
        table.add_row("Recent Activity (24h)", str(stats_data.get("recent_activity_24h", 0)))
        
        if stats_data.get("average_duration_ms"):
            table.add_row("Avg Duration", f"{stats_data['average_duration_ms']:.0f}ms")
        
        console.print(table)
        
        # Most used commands
        if stats_data.get("most_used_commands"):
            cmd_table = Table(title="Most Used Commands", show_header=True, header_style="bold magenta")
            cmd_table.add_column("Command", style="cyan")
            cmd_table.add_column("Usage Count", style="green")
            
            for cmd, count in stats_data["most_used_commands"]:
                cmd_table.add_row(cmd, str(count))
            
            console.print(cmd_table)
        return
    
    if search:
        entries = command_history.search_history(search, limit=20)
        title = f"Search Results for '{search}'"
    elif failed:
        entries = command_history.get_failed_commands(limit=recent)
        title = "Recent Failed Commands"
    else:
        entries = command_history.get_recent_commands(limit=recent)
        title = f"Recent Commands (last {len(entries)})"
    
    if not entries:
        console.print("[yellow]No commands found[/yellow]")
        return
    
    # Create history table
    table = Table(title=title, show_header=True, header_style="bold blue")
    table.add_column("Time", style="dim", width=19)
    table.add_column("Command", style="cyan", width=15)
    table.add_column("Arguments", style="white")
    table.add_column("Status", style="green", width=8)
    table.add_column("Duration", style="yellow", width=8)
    
    for entry in entries:
        # Format timestamp
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(entry.timestamp)
            time_str = dt.strftime("%m-%d %H:%M:%S")
        except:
            time_str = entry.timestamp[:16]
        
        # Format arguments
        args_str = " ".join(entry.args) if entry.args else ""
        if len(args_str) > 40:
            args_str = args_str[:37] + "..."
        
        # Status and duration
        status = "✅" if entry.success else "❌"
        duration = f"{entry.duration_ms}ms" if entry.duration_ms else "-"
        
        table.add_row(time_str, entry.command, args_str, status, duration)
    
    console.print(table)
    
    # Show error details for failed commands if requested
    if failed and any(not entry.success for entry in entries):
        console.print("\n[red]Error Details:[/red]")
        for i, entry in enumerate(entries):
            if not entry.success and entry.error:
                error_panel = Panel(
                    entry.error,
                    title=f"Error: {entry.command} {' '.join(entry.args)}",
                    border_style="red",
                    padding=(0, 1)
                )
                console.print(error_panel)


@cli.command()
@click.option("--list", "list_config", is_flag=True, help="List current configuration")
@click.option("--framework", help="Add or update framework configuration")
@click.option("--url", help="Framework documentation URL (use with --framework)")
@click.option("--description", help="Framework description (use with --framework)")
@click.option("--remove", help="Remove framework from configuration")
@click.option("--interactive", is_flag=True, default=True, help="Use interactive configuration")
def config(list_config, framework, url, description, remove, interactive):
    """Manage CodeInsight configuration and frameworks."""
    
    config_path = Path("configs/docs_sources.yaml")
    
    if list_config:
        # Show current configuration
        if config_path.exists():
            import yaml
            try:
                with open(config_path, 'r') as f:
                    config_data = yaml.safe_load(f)
                
                if config_data and "frameworks" in config_data:
                    table = Table(title="Configured Frameworks", show_header=True, header_style="bold cyan")
                    table.add_column("Name", style="green", width=15)
                    table.add_column("URL", style="blue")
                    table.add_column("Description", style="yellow")
                    
                    for name, info in config_data["frameworks"].items():
                        if isinstance(info, dict):
                            url_val = info.get("url", "N/A")
                            desc_val = info.get("description", "")
                        else:
                            url_val = str(info)
                            desc_val = ""
                        
                        # Truncate long URLs for display
                        display_url = url_val if len(url_val) <= 50 else url_val[:47] + "..."
                        table.add_row(name, display_url, desc_val)
                    
                    console.print(table)
                else:
                    console.print("[yellow]No frameworks configured[/yellow]")
            except Exception as e:
                ui.show_error_with_suggestions(f"Failed to read configuration: {e}")
        else:
            console.print("[yellow]Configuration file not found[/yellow]")
            console.print("[dim]Use 'codeinsight config --framework <name> --url <url>' to add frameworks[/dim]")
        return
    
    if remove:
        # Remove framework
        if not config_path.exists():
            ui.show_error_with_suggestions("Configuration file not found")
            return
        
        import yaml
        try:
            with open(config_path, 'r') as f:
                config_data = yaml.safe_load(f) or {}
            
            if "frameworks" not in config_data:
                config_data["frameworks"] = {}
            
            if remove in config_data["frameworks"]:
                del config_data["frameworks"][remove]
                
                with open(config_path, 'w') as f:
                    yaml.dump(config_data, f, default_flow_style=False)
                
                ui.show_success_with_metadata(f"Removed framework '{remove}' from configuration")
            else:
                ui.show_error_with_suggestions(f"Framework '{remove}' not found in configuration")
        
        except Exception as e:
            ui.show_error_with_suggestions(f"Failed to update configuration: {e}")
        return
    
    if framework:
        # Add or update framework
        if not url and interactive:
            from rich.prompt import Prompt
            url = Prompt.ask(f"[cyan]URL for {framework}[/cyan]")
            if not description:
                description = Prompt.ask(f"[cyan]Description for {framework}[/cyan] (optional)", default="")
        
        if not url:
            ui.show_error_with_suggestions("URL is required when adding a framework", 
                                         ["Use --url option", "Use --interactive for prompts"])
            return
        
        # Ensure config directory exists
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        import yaml
        
        # Load existing config or create new
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    config_data = yaml.safe_load(f) or {}
            except:
                config_data = {}
        else:
            config_data = {}
        
        if "frameworks" not in config_data:
            config_data["frameworks"] = {}
        
        # Update framework entry
        config_data["frameworks"][framework] = {
            "url": url,
            "description": description or f"{framework.title()} framework"
        }
        
        try:
            with open(config_path, 'w') as f:
                yaml.dump(config_data, f, default_flow_style=False)
            
            success_metadata = {
                "framework": framework,
                "url": url,
                "description": description or "",
                "config_file": str(config_path)
            }
            ui.show_success_with_metadata(f"Added/updated framework '{framework}'", success_metadata)
            
        except Exception as e:
            ui.show_error_with_suggestions(f"Failed to save configuration: {e}")
        
        return
    
    # Interactive configuration mode
    if interactive:
        console.print("[bold blue]🔧 Interactive Configuration[/bold blue]")
        console.print("[dim]Manage your CodeInsight frameworks and settings[/dim]\n")
        
        from rich.prompt import Prompt, Confirm
        
        while True:
            action = Prompt.ask(
                "[cyan]What would you like to do?[/cyan]",
                choices=["list", "add", "remove", "quit"],
                default="list"
            )
            
            if action == "quit":
                break
            elif action == "list":
                # Recursive call to show list
                config(list_config=True, framework=None, url=None, description=None, 
                      remove=None, interactive=False)
            elif action == "add":
                fw_name = Prompt.ask("[cyan]Framework name[/cyan]")
                fw_url = Prompt.ask(f"[cyan]URL for {fw_name}[/cyan]")
                fw_desc = Prompt.ask(f"[cyan]Description for {fw_name}[/cyan] (optional)", default="")
                
                # Recursive call to add framework
                config(list_config=False, framework=fw_name, url=fw_url, 
                      description=fw_desc, remove=None, interactive=False)
            elif action == "remove":
                fw_name = Prompt.ask("[cyan]Framework name to remove[/cyan]")
                if Confirm.ask(f"[red]Remove '{fw_name}' from configuration?[/red]"):
                    # Recursive call to remove framework  
                    config(list_config=False, framework=None, url=None, 
                          description=None, remove=fw_name, interactive=False)
            
            console.print()  # Add spacing
    else:
        # Show help if no options provided
        console.print("[yellow]No configuration action specified[/yellow]")
        console.print("[dim]Use --help to see available options[/dim]")


@cli.command()
@click.option("--show-stats", is_flag=True, help="Show cache statistics")
@click.option("--clear", type=str, help="Clear cache type (web_requests, embeddings, api_responses, all)")
@click.option("--size-limit", type=int, help="Show caches over size limit (MB)")
@track_command
@safe_operation(category=ErrorCategory.FILE_SYSTEM, operation="file_operation")
def cache(show_stats, clear, size_limit):
    """Manage CodeInsight cache system."""
    
    if clear:
        # Validate cache type
        cache_type = clear.lower().strip()
        valid_types = ["web_requests", "embeddings", "api_responses", "all"]
        
        if cache_type not in valid_types:
            console.print(f"[red]Invalid cache type. Must be one of: {', '.join(valid_types)}[/red]")
            return
        
        from rich.prompt import Confirm
        
        if cache_type == "all":
            if Confirm.ask("[red]Clear ALL cache data? This cannot be undone.[/red]"):
                for ct in ["web_requests", "embeddings", "api_responses", "default"]:
                    try:
                        cache_instance = get_cache(ct)
                        cache_instance.clear()
                        console.print(f"[green]Cleared {ct} cache[/green]")
                    except Exception as e:
                        console.print(f"[yellow]Warning: Could not clear {ct} cache: {e}[/yellow]")
        else:
            if Confirm.ask(f"[red]Clear {cache_type} cache?[/red]"):
                try:
                    cache_instance = get_cache(cache_type)
                    cache_instance.clear()
                    console.print(f"[green]Cleared {cache_type} cache[/green]")
                except Exception as e:
                    console.print(f"[red]Failed to clear {cache_type} cache: {e}[/red]")
        return
    
    # Show cache statistics
    cache_types = ["web_requests", "embeddings", "api_responses", "default"]
    
    if show_stats or not clear:
        table = Table(title="Cache Statistics")
        table.add_column("Cache Type", style="cyan")
        table.add_column("Hit Rate %", style="green", justify="right")
        table.add_column("Memory (MB)", style="yellow", justify="right")
        table.add_column("Disk (MB)", style="blue", justify="right")
        table.add_column("Entries", style="magenta", justify="right")
        table.add_column("Requests", style="white", justify="right")
        
        total_memory = 0
        total_disk = 0
        
        for cache_type in cache_types:
            try:
                cache_instance = get_cache(cache_type)
                stats = cache_instance.get_statistics()
                
                # Check size limit filter
                if size_limit:
                    total_size = stats["memory_usage_mb"] + stats["disk_usage_mb"]
                    if total_size < size_limit:
                        continue
                
                hit_rate = f"{stats['hit_rate'] * 100:.1f}"
                memory_mb = f"{stats['memory_usage_mb']:.2f}"
                disk_mb = f"{stats['disk_usage_mb']:.2f}"
                total_entries = stats['memory_entries'] + stats['disk_entries']
                
                total_memory += stats['memory_usage_mb']
                total_disk += stats['disk_usage_mb']
                
                table.add_row(
                    cache_type,
                    hit_rate,
                    memory_mb,
                    disk_mb,
                    str(total_entries),
                    str(stats['total_requests'])
                )
                
            except Exception as e:
                table.add_row(
                    cache_type,
                    "ERROR",
                    "0.00",
                    "0.00",
                    "0",
                    "0"
                )
        
        # Add totals row
        table.add_section()
        table.add_row(
            "[bold]TOTAL[/bold]",
            "",
            f"[bold]{total_memory:.2f}[/bold]",
            f"[bold]{total_disk:.2f}[/bold]",
            "",
            ""
        )
        
        console.print(table)
        
        # Show cache recommendations
        if total_memory + total_disk > 100:  # > 100MB
            console.print("\n[yellow]💡 Cache Recommendations:[/yellow]")
            console.print("• Consider clearing old cache data: [cyan]codeinsight cache --clear all[/cyan]")
            console.print("• Large cache improves performance but uses disk space")


@cli.group()
def config():
    """Configuration management commands."""
    pass


@config.command()
@click.option("--verbose", "-v", is_flag=True, help="Show detailed configuration info")
@track_command
@safe_operation(category=ErrorCategory.CONFIG, operation="config_command")
def info(verbose):
    """Show current configuration information."""
    try:
        config_info = config_manager.get_configuration_info()
        
        # Basic information table
        table = Table(title="Configuration Information")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Version", config_info["version"])
        table.add_row("Framework Count", str(config_info["framework_count"]))
        table.add_row("Config File", config_info["config_file"])
        
        if config_info["last_updated"]:
            from datetime import datetime
            try:
                last_updated = datetime.fromisoformat(config_info["last_updated"])
                table.add_row("Last Updated", last_updated.strftime("%Y-%m-%d %H:%M:%S"))
            except (ValueError, TypeError):
                table.add_row("Last Updated", str(config_info["last_updated"]))
        
        console.print(table)
        
        if verbose:
            # Cache status
            cache_table = Table(title="Configuration Cache Status")
            cache_table.add_column("Metric", style="cyan")
            cache_table.add_column("Value", style="yellow")
            
            cache_status = config_info["cache_status"]
            cache_table.add_row("Cached Configs", str(cache_status["cached_configs"]))
            cache_table.add_row("Cache Timestamps", str(cache_status["cache_timestamps"]))
            
            console.print("\n")
            console.print(cache_table)
            
            # Show current configuration
            console.print("\n[bold cyan]Current Configuration:[/bold cyan]")
            try:
                current_config = config_manager.load_config("docs_sources")
                frameworks = current_config.get("frameworks", {})
                
                framework_table = Table(title="Configured Frameworks")
                framework_table.add_column("Framework", style="cyan")
                framework_table.add_column("URL", style="blue")
                framework_table.add_column("Description", style="green")
                
                for name, config in frameworks.items():
                    url = config.get("url", "N/A")
                    description = config.get("description", "N/A")
                    # Truncate long URLs and descriptions
                    if len(url) > 50:
                        url = url[:47] + "..."
                    if len(description) > 40:
                        description = description[:37] + "..."
                    
                    framework_table.add_row(name, url, description)
                
                console.print("\n")
                console.print(framework_table)
                
            except Exception as e:
                console.print(f"[red]Error loading current configuration: {e}[/red]")
    
    except Exception as e:
        console.print(f"[red]Error retrieving configuration information: {e}[/red]")


@config.command()
@click.argument("name")
@click.argument("url")
@click.option("--description", "-d", help="Framework description")
@track_command
@safe_operation(category=ErrorCategory.CONFIG, operation="config_command")
def add_framework(name, url, description):
    """Add or update a framework configuration."""
    try:
        # Use provided description or generate default
        if not description:
            description = f"{name.title()} framework"
        
        success = config_manager.add_framework(name, url, description)
        
        if success:
            console.print(f"[green]✓ Framework '{name}' added successfully[/green]")
            console.print(f"  URL: {url}")
            console.print(f"  Description: {description}")
            
            # Suggest next steps
            console.print("\n[yellow]💡 Next steps:[/yellow]")
            console.print(f"• Update documentation: [cyan]codeinsight update {name}[/cyan]")
            console.print(f"• Query documentation: [cyan]codeinsight query '{name} getting started'[/cyan]")
        else:
            console.print(f"[red]✗ Failed to add framework '{name}'[/red]")
    
    except Exception as e:
        console.print(f"[red]Error adding framework: {e}[/red]")


@config.command()
@click.argument("name")
@click.option("--confirm", is_flag=True, help="Skip confirmation prompt")
@track_command
@safe_operation(category=ErrorCategory.CONFIG, operation="config_command")
def remove_framework(name, confirm):
    """Remove a framework configuration."""
    try:
        # Check if framework exists
        framework_config = config_manager.get_framework_config(name)
        if not framework_config:
            console.print(f"[yellow]Framework '{name}' not found in configuration[/yellow]")
            return
        
        # Confirm removal unless --confirm flag is used
        if not confirm:
            console.print(f"[yellow]About to remove framework '{name}':[/yellow]")
            console.print(f"  URL: {framework_config.get('url', 'N/A')}")
            console.print(f"  Description: {framework_config.get('description', 'N/A')}")
            
            if not click.confirm("\nAre you sure you want to remove this framework?"):
                console.print("[yellow]Operation cancelled[/yellow]")
                return
        
        success = config_manager.remove_framework(name)
        
        if success:
            console.print(f"[green]✓ Framework '{name}' removed successfully[/green]")
            
            # Check for associated data
            from pathlib import Path
            docs_file = Path("data/docs") / f"{name}.md"
            db_dir = Path("data/db") / name
            
            if docs_file.exists() or db_dir.exists():
                console.print("\n[yellow]⚠️  Associated data still exists:[/yellow]")
                if docs_file.exists():
                    console.print(f"  Documentation: {docs_file}")
                if db_dir.exists():
                    console.print(f"  Database: {db_dir}")
                console.print("Consider cleaning up manually if no longer needed.")
        else:
            console.print(f"[red]✗ Failed to remove framework '{name}'[/red]")
    
    except Exception as e:
        console.print(f"[red]Error removing framework: {e}[/red]")


@config.command()
@click.option("--validate-only", is_flag=True, help="Only validate, don't save")
@track_command
@safe_operation(category=ErrorCategory.CONFIG, operation="config_command")
def validate(validate_only):
    """Validate current configuration files."""
    try:
        console.print("[cyan]Validating configuration...[/cyan]")
        
        # Load and validate main config
        config_data = config_manager.load_config("docs_sources", force_reload=True)
        
        console.print("[green]✓ Configuration loaded and validated successfully[/green]")
        
        # Show validation details
        validation_table = Table(title="Validation Results")
        validation_table.add_column("Check", style="cyan")
        validation_table.add_column("Status", style="green")
        validation_table.add_column("Details", style="yellow")
        
        # Check metadata
        metadata = config_data.get("metadata", {})
        version = metadata.get("version", "unknown")
        validation_table.add_row("Version", "✓ Valid", version)
        
        # Check frameworks
        frameworks = config_data.get("frameworks", {})
        framework_count = len(frameworks)
        validation_table.add_row("Frameworks", "✓ Valid", f"{framework_count} configured")
        
        # Check settings
        settings = config_data.get("settings", {})
        if settings:
            validation_table.add_row("Settings", "✓ Valid", f"{len(settings)} settings configured")
        else:
            validation_table.add_row("Settings", "⚠ Default", "Using default settings")
        
        # Validate URLs
        url_errors = []
        for name, framework_config in frameworks.items():
            url = framework_config.get("url", "")
            url_result = validator.validate_by_type(url, "url")
            if not url_result.is_valid:
                url_errors.append(f"{name}: {', '.join(url_result.errors)}")
        
        if url_errors:
            validation_table.add_row("URLs", "✗ Errors", f"{len(url_errors)} invalid URLs")
        else:
            validation_table.add_row("URLs", "✓ Valid", f"{framework_count} URLs validated")
        
        console.print("\n")
        console.print(validation_table)
        
        # Show URL errors if any
        if url_errors:
            console.print("\n[red]URL Validation Errors:[/red]")
            for error in url_errors:
                console.print(f"  • {error}")
        
        # Show recommendations
        console.print("\n[yellow]💡 Configuration Recommendations:[/yellow]")
        
        if framework_count == 0:
            console.print("• Add frameworks: [cyan]codeinsight config add-framework react https://react.dev/[/cyan]")
        elif framework_count < 3:
            console.print("• Consider adding more frameworks for broader coverage")
        
        if not settings:
            console.print("• Default settings are being used - consider customizing cache and rate limits")
        
        if not validate_only:
            # Save validated configuration (this also creates backups)
            config_manager.save_config(config_data, "docs_sources")
            console.print("\n[green]✓ Configuration saved with validation[/green]")
    
    except Exception as e:
        console.print(f"[red]Configuration validation failed: {e}[/red]")


@config.command()
@click.option("--create-backup", is_flag=True, help="Create backup before reset")
@click.option("--confirm", is_flag=True, help="Skip confirmation prompt")
@track_command
@safe_operation(category=ErrorCategory.CONFIG, operation="config_command")
def reset(create_backup, confirm):
    """Reset configuration to defaults."""
    try:
        if not confirm:
            console.print("[yellow]⚠️  This will reset your configuration to defaults![/yellow]")
            console.print("All custom frameworks and settings will be lost.")
            
            if not click.confirm("\nAre you sure you want to continue?"):
                console.print("[yellow]Operation cancelled[/yellow]")
                return
        
        config_path = config_manager.config_dir / "docs_sources.yaml"
        
        # Create backup if requested and file exists
        if create_backup and config_path.exists():
            from datetime import datetime
            backup_path = config_path.with_suffix(f'.yaml.reset-backup.{int(datetime.now().timestamp())}')
            shutil.copy2(config_path, backup_path)
            console.print(f"[green]✓ Backup created: {backup_path}[/green]")
        
        # Remove existing config file to trigger default creation
        if config_path.exists():
            config_path.unlink()
        
        # Clear cache to force reload
        if "docs_sources" in config_manager._config_cache:
            del config_manager._config_cache["docs_sources"]
        
        # Load default config (this will create it)
        default_config = config_manager.load_config("docs_sources")
        
        console.print("[green]✓ Configuration reset to defaults[/green]")
        
        # Show what was created
        frameworks = default_config.get("frameworks", {})
        console.print(f"Default frameworks: {', '.join(frameworks.keys())}")
        
        console.print("\n[yellow]💡 Next steps:[/yellow]")
        console.print("• Add your frameworks: [cyan]codeinsight config add-framework <name> <url>[/cyan]")
        console.print("• View configuration: [cyan]codeinsight config info --verbose[/cyan]")
    
    except Exception as e:
        console.print(f"[red]Error resetting configuration: {e}[/red]")


@cli.group()
def logs():
    """Logging management commands."""
    pass


@logs.command()
@click.option("--level", type=click.Choice(['TRACE', 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']), 
              help="Set log level")
@click.option("--tail", "-n", type=int, help="Show last N log lines")
@click.option("--follow", "-f", is_flag=True, help="Follow log output")
@click.option("--format", "log_format", type=click.Choice(['human', 'structured', 'compact']), 
              help="Log format to display")
@track_command
@safe_operation(category=ErrorCategory.FILE_SYSTEM, operation="log_view")
def view(level, tail, follow, log_format):
    """View and manage log output."""
    from core.logging_system import get_logging_manager
    
    logging_manager = get_logging_manager()
    
    if level:
        logging_manager.set_level(level)
        console.print(f"[green]✓ Log level set to {level}[/green]")
        return
    
    # Show log files
    log_dir = logging_manager.log_dir
    log_files = list(log_dir.glob("*.log")) + list(log_dir.glob("*.jsonl"))
    
    if not log_files:
        console.print("[yellow]No log files found[/yellow]")
        return
    
    # Display log files table
    table = Table(title="Log Files")
    table.add_column("File", style="cyan")
    table.add_column("Size", style="green", justify="right")
    table.add_column("Modified", style="yellow")
    table.add_column("Type", style="blue")
    
    import os
    from datetime import datetime
    
    for log_file in sorted(log_files):
        stat = log_file.stat()
        size_mb = stat.st_size / (1024 * 1024)
        modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
        file_type = "Structured" if log_file.suffix == ".jsonl" else "Human"
        
        table.add_row(
            log_file.name,
            f"{size_mb:.2f} MB",
            modified,
            file_type
        )
    
    console.print(table)
    
    # Show recent log entries if requested
    if tail:
        main_log = log_dir / "codeinsight.log"
        if main_log.exists():
            console.print(f"\n[cyan]Last {tail} log entries:[/cyan]")
            try:
                with open(main_log, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    for line in lines[-tail:]:
                        console.print(line.rstrip())
            except Exception as e:
                console.print(f"[red]Error reading log file: {e}[/red]")


@logs.command()
@click.option("--structured", is_flag=True, help="Show structured log statistics")
@track_command
@safe_operation(category=ErrorCategory.FILE_SYSTEM, operation="log_stats")
def stats(structured):
    """Show logging statistics and metrics."""
    from core.logging_system import get_logging_manager
    import json
    
    logging_manager = get_logging_manager()
    log_dir = logging_manager.log_dir
    
    # Basic statistics
    stats_table = Table(title="Logging Statistics")
    stats_table.add_column("Metric", style="cyan")
    stats_table.add_column("Value", style="green")
    
    # Count log files and total size
    log_files = list(log_dir.glob("*.log")) + list(log_dir.glob("*.jsonl"))
    total_size = sum(f.stat().st_size for f in log_files)
    
    stats_table.add_row("Total Log Files", str(len(log_files)))
    stats_table.add_row("Total Size", f"{total_size / (1024*1024):.2f} MB")
    stats_table.add_row("Log Directory", str(log_dir))
    
    # Count entries in structured log
    structured_file = log_dir / "codeinsight-structured.jsonl"
    if structured_file.exists():
        try:
            with open(structured_file, 'r', encoding='utf-8') as f:
                line_count = sum(1 for _ in f)
            stats_table.add_row("Structured Entries", str(line_count))
        except Exception:
            stats_table.add_row("Structured Entries", "Error reading file")
    
    console.print(stats_table)
    
    # Show structured statistics if requested
    if structured and structured_file.exists():
        console.print("\n[cyan]Structured Log Analysis:[/cyan]")
        
        level_counts = {}
        logger_counts = {}
        error_count = 0
        
        try:
            with open(structured_file, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        level = entry.get('level', 'UNKNOWN')
                        logger = entry.get('logger', 'unknown')
                        
                        level_counts[level] = level_counts.get(level, 0) + 1
                        logger_counts[logger] = logger_counts.get(logger, 0) + 1
                        
                        if entry.get('exception_info'):
                            error_count += 1
                    except json.JSONDecodeError:
                        continue
            
            # Show level distribution
            if level_counts:
                level_table = Table(title="Log Level Distribution")
                level_table.add_column("Level", style="cyan")
                level_table.add_column("Count", style="green", justify="right")
                level_table.add_column("Percentage", style="yellow", justify="right")
                
                total_entries = sum(level_counts.values())
                for level, count in sorted(level_counts.items()):
                    percentage = (count / total_entries) * 100
                    level_table.add_row(level, str(count), f"{percentage:.1f}%")
                
                console.print("\n")
                console.print(level_table)
            
            # Show top loggers
            if logger_counts:
                logger_table = Table(title="Top Loggers")
                logger_table.add_column("Logger", style="cyan")
                logger_table.add_column("Entries", style="green", justify="right")
                
                sorted_loggers = sorted(logger_counts.items(), key=lambda x: x[1], reverse=True)[:10]
                for logger, count in sorted_loggers:
                    logger_table.add_row(logger, str(count))
                
                console.print("\n")
                console.print(logger_table)
        
        except Exception as e:
            console.print(f"[red]Error analyzing structured logs: {e}[/red]")


@logs.command()
@click.option("--keep-days", type=int, default=7, help="Days of logs to keep")
@click.option("--confirm", is_flag=True, help="Skip confirmation prompt")
@track_command
@safe_operation(category=ErrorCategory.FILE_SYSTEM, operation="log_cleanup")
def cleanup(keep_days, confirm):
    """Clean up old log files."""
    from core.logging_system import get_logging_manager
    from datetime import datetime, timedelta
    
    logging_manager = get_logging_manager()
    log_dir = logging_manager.log_dir
    
    # Find old log files
    cutoff_date = datetime.now() - timedelta(days=keep_days)
    old_files = []
    
    for log_file in log_dir.glob("*.log*"):
        if log_file.stat().st_mtime < cutoff_date.timestamp():
            old_files.append(log_file)
    
    if not old_files:
        console.print("[green]No old log files to clean up[/green]")
        return
    
    # Show files to be cleaned
    console.print(f"[yellow]Found {len(old_files)} log files older than {keep_days} days:[/yellow]")
    for file in old_files:
        size_mb = file.stat().st_size / (1024 * 1024)
        console.print(f"  • {file.name} ({size_mb:.2f} MB)")
    
    if not confirm:
        if not click.confirm(f"\nDelete these {len(old_files)} files?"):
            console.print("[yellow]Cleanup cancelled[/yellow]")
            return
    
    # Delete files
    deleted_count = 0
    total_size = 0
    
    for file in old_files:
        try:
            total_size += file.stat().st_size
            file.unlink()
            deleted_count += 1
        except Exception as e:
            console.print(f"[red]Error deleting {file.name}: {e}[/red]")
    
    console.print(f"[green]✓ Deleted {deleted_count} files, freed {total_size / (1024*1024):.2f} MB[/green]")


@logs.command()
@track_command
@safe_operation(category=ErrorCategory.INTERNAL, operation="system_info_log")
def system():
    """Log current system information for debugging."""
    from core.logging_system import get_logging_manager
    
    logging_manager = get_logging_manager()
    logging_manager.log_system_info()
    
    console.print("[green]✓ System information logged[/green]")
    console.print("Check logs for detailed system information:")
    console.print(f"  • Main log: {logging_manager.log_dir / 'codeinsight.log'}")
    console.print(f"  • Structured log: {logging_manager.log_dir / 'codeinsight-structured.jsonl'}")


@cli.group()
def perf():
    """Performance monitoring and optimization commands."""
    pass


@perf.command()
@click.option("--top", "-n", type=int, default=10, help="Show top N slowest operations")
@click.option("--detailed", is_flag=True, help="Show detailed performance metrics")
@click.option("--export", type=str, help="Export metrics to file")
@track_command
@safe_operation(category=ErrorCategory.INTERNAL, operation="perf_stats")
def stats(top, detailed, export):
    """Show performance statistics for all operations."""
    summaries = performance_monitor.get_all_summaries()
    
    if not summaries:
        console.print("[yellow]No performance data available[/yellow]")
        console.print("Performance data is collected as you use CodeInsight commands.")
        return
    
    # Show top slowest operations
    top_summaries = summaries[:top]
    
    table = Table(title=f"Top {len(top_summaries)} Slowest Operations")
    table.add_column("Operation", style="cyan")
    table.add_column("Avg Duration", style="red", justify="right")
    table.add_column("Calls", style="green", justify="right")
    table.add_column("Success Rate", style="yellow", justify="right")
    table.add_column("Performance", style="blue")
    table.add_column("Trend", style="magenta")
    
    for summary in top_summaries:
        # Color code performance level
        perf_color = {
            "excellent": "green",
            "good": "cyan", 
            "acceptable": "yellow",
            "slow": "red",
            "critical": "bright_red"
        }.get(summary.performance_level.value, "white")
        
        # Color code trend
        trend_color = {
            "improving": "green",
            "stable": "yellow",
            "degrading": "red"
        }.get(summary.trend, "white")
        
        table.add_row(
            summary.operation,
            f"{summary.avg_duration_ms:.1f}ms",
            str(summary.total_calls),
            f"{summary.success_rate * 100:.1f}%",
            f"[{perf_color}]{summary.performance_level.value}[/{perf_color}]",
            f"[{trend_color}]{summary.trend}[/{trend_color}]"
        )
    
    console.print(table)
    
    # Show detailed metrics if requested
    if detailed and top_summaries:
        console.print(f"\n[cyan]Detailed Metrics for Top {min(3, len(top_summaries))} Operations:[/cyan]")
        
        for i, summary in enumerate(top_summaries[:3]):
            detail_table = Table(title=f"{summary.operation} Details")
            detail_table.add_column("Metric", style="cyan")
            detail_table.add_column("Value", style="green")
            
            detail_table.add_row("Average Duration", f"{summary.avg_duration_ms:.2f}ms")
            detail_table.add_row("Min Duration", f"{summary.min_duration_ms:.2f}ms")
            detail_table.add_row("Max Duration", f"{summary.max_duration_ms:.2f}ms")
            detail_table.add_row("95th Percentile", f"{summary.p95_duration_ms:.2f}ms")
            detail_table.add_row("99th Percentile", f"{summary.p99_duration_ms:.2f}ms")
            detail_table.add_row("Total Calls", str(summary.total_calls))
            detail_table.add_row("Error Count", str(summary.error_count))
            detail_table.add_row("Last Called", summary.last_called.strftime("%Y-%m-%d %H:%M:%S"))
            
            console.print(f"\n")
            console.print(detail_table)
    
    # Export if requested
    if export:
        try:
            performance_monitor.export_metrics(export)
            console.print(f"\n[green]✓ Performance metrics exported to {export}[/green]")
        except Exception as e:
            console.print(f"\n[red]Error exporting metrics: {e}[/red]")


@perf.command()
@click.option("--auto-fix", is_flag=True, help="Show implementation suggestions")
@track_command
@safe_operation(category=ErrorCategory.INTERNAL, operation="perf_analyze")
def analyze(auto_fix):
    """Analyze performance and suggest optimizations."""
    optimizer = get_optimizer()
    
    # Get bottlenecks
    bottlenecks = optimizer.analyze_bottlenecks()
    
    if not bottlenecks:
        console.print("[green]✓ No significant performance bottlenecks detected![/green]")
        return
    
    console.print(f"[yellow]Found {len(bottlenecks)} performance issues:[/yellow]\n")
    
    for i, bottleneck in enumerate(bottlenecks[:5], 1):  # Show top 5
        operation = bottleneck['operation']
        issues = bottleneck['issues']
        
        console.print(f"[red]{i}. {operation}[/red]")
        
        for issue in issues:
            severity_color = {"high": "red", "medium": "yellow", "low": "blue"}.get(issue['severity'], "white")
            console.print(f"   • [{severity_color}]{issue['type'].upper()}[/{severity_color}]: {issue['description']}")
        
        console.print()
    
    # Get recommendations
    recommendations = optimizer.get_optimization_recommendations()
    
    if recommendations:
        console.print("[cyan]🔧 Optimization Recommendations:[/cyan]\n")
        
        for i, rec in enumerate(recommendations[:10], 1):  # Show top 10
            priority_color = {"high": "red", "medium": "yellow", "low": "blue"}.get(rec['priority'], "white")
            
            console.print(f"[{priority_color}]{i}. {rec['operation']} - {rec['type'].upper()}[/{priority_color}]")
            console.print(f"   Description: {rec['description']}")
            
            if 'implementation' in rec:
                console.print(f"   Implementation: [dim]{rec['implementation']}[/dim]")
            
            console.print()


@perf.command()
@click.option("--minutes", "-m", type=int, default=5, help="Minutes of system metrics to show")
@track_command
@safe_operation(category=ErrorCategory.INTERNAL, operation="perf_system")
def system_metrics(minutes):
    """Show current system performance metrics."""
    # Get current metrics
    current_metrics = performance_monitor.get_system_metrics()
    
    if 'error' in current_metrics:
        console.print(f"[red]Error collecting system metrics: {current_metrics['error']}[/red]")
        return
    
    # Current system state
    current_table = Table(title="Current System Metrics")
    current_table.add_column("Metric", style="cyan")
    current_table.add_column("Value", style="green")
    current_table.add_column("Status", style="yellow")
    
    def get_status(value, thresholds):
        """Get status based on thresholds [good, warning, critical]."""
        if value < thresholds[0]:
            return "[green]Good[/green]"
        elif value < thresholds[1]:
            return "[yellow]Warning[/yellow]"
        else:
            return "[red]Critical[/red]"
    
    # CPU
    cpu_percent = current_metrics.get('cpu_percent', 0)
    current_table.add_row("CPU Usage", f"{cpu_percent:.1f}%", get_status(cpu_percent, [50, 80]))
    
    # Memory
    memory_percent = current_metrics.get('memory_used_percent', 0)
    current_table.add_row("Memory Usage", f"{memory_percent:.1f}%", get_status(memory_percent, [70, 85]))
    
    # Disk
    disk_percent = current_metrics.get('disk_used_percent', 0)
    current_table.add_row("Disk Usage", f"{disk_percent:.1f}%", get_status(disk_percent, [80, 95]))
    
    # Process memory
    process_memory = current_metrics.get('process_memory_mb', 0)
    current_table.add_row("Process Memory", f"{process_memory:.1f} MB", get_status(process_memory, [100, 500]))
    
    # Python objects
    python_objects = current_metrics.get('python_objects', 0)
    current_table.add_row("Python Objects", f"{python_objects:,}", get_status(python_objects, [10000, 50000]))
    
    console.print(current_table)
    
    # Historical metrics
    recent_metrics = performance_monitor.get_recent_system_metrics(minutes)
    
    if recent_metrics and len(recent_metrics) > 1:
        console.print(f"\n[cyan]System Metrics Trend (Last {minutes} minutes):[/cyan]")
        
        import statistics
        
        # Calculate averages
        cpu_values = [m.get('cpu_percent', 0) for m in recent_metrics if 'cpu_percent' in m]
        memory_values = [m.get('memory_used_percent', 0) for m in recent_metrics if 'memory_used_percent' in m]
        
        if cpu_values and memory_values:
            trend_table = Table()
            trend_table.add_column("Metric", style="cyan")
            trend_table.add_column("Average", style="green")
            trend_table.add_column("Min", style="blue")
            trend_table.add_column("Max", style="red")
            
            trend_table.add_row(
                "CPU %",
                f"{statistics.mean(cpu_values):.1f}%",
                f"{min(cpu_values):.1f}%",
                f"{max(cpu_values):.1f}%"
            )
            
            trend_table.add_row(
                "Memory %", 
                f"{statistics.mean(memory_values):.1f}%",
                f"{min(memory_values):.1f}%",
                f"{max(memory_values):.1f}%"
            )
            
            console.print(trend_table)
    
    else:
        console.print(f"\n[yellow]Insufficient historical data (need {minutes} minutes of monitoring)[/yellow]")


@perf.command()
@click.option("--hours", type=int, default=24, help="Clear metrics older than N hours")
@click.option("--confirm", is_flag=True, help="Skip confirmation prompt")
@track_command
@safe_operation(category=ErrorCategory.INTERNAL, operation="perf_cleanup")
def cleanup(hours, confirm):
    """Clean up old performance metrics."""
    if not confirm:
        console.print(f"[yellow]This will clear performance metrics older than {hours} hours[/yellow]")
        if not click.confirm("Continue?"):
            console.print("[yellow]Cleanup cancelled[/yellow]")
            return
    
    # Count metrics before cleanup
    metrics_before = len(performance_monitor.metrics)
    operations_before = len(performance_monitor.operation_stats)
    
    # Clean up
    performance_monitor.clear_metrics(older_than_hours=hours)
    
    # Count after cleanup
    metrics_after = len(performance_monitor.metrics)
    operations_after = len(performance_monitor.operation_stats)
    
    console.print(f"[green]✓ Performance cleanup completed[/green]")
    console.print(f"  • Metrics: {metrics_before} → {metrics_after} ({metrics_before - metrics_after} removed)")
    console.print(f"  • Operations: {operations_before} → {operations_after} ({operations_before - operations_after} cleared)")


@perf.command()
@click.argument("operation", required=False)
@click.option("--duration", type=float, default=1.0, help="Duration to sleep (for testing)")
@track_command
@safe_operation(category=ErrorCategory.INTERNAL, operation="perf_test")
def test(operation, duration):
    """Test performance monitoring with a sample operation."""
    if not operation:
        operation = "test_operation"
    
    console.print(f"[cyan]Running test operation '{operation}' for {duration}s...[/cyan]")
    
    with profile_operation(operation) as profiler:
        profiler.add_context(test_duration=duration, test_mode=True)
        profiler.add_tag("test")
        time.sleep(duration)
    
    console.print(f"[green]✓ Test completed[/green]")
    
    # Show the recorded metric
    summary = performance_monitor.get_operation_summary(operation)
    if summary:
        console.print(f"  • Recorded duration: {summary.avg_duration_ms:.1f}ms")
        console.print(f"  • Performance level: {summary.performance_level.value}")


@cli.group()
def model():
    """Model management commands for Ollama integration."""
    pass


@model.command()
@click.option("--show-config", is_flag=True, help="Show current model configuration")
@track_command
@safe_operation(category=ErrorCategory.API, operation="model_list")
def list(show_config):
    """List available and configured models."""
    from core.llm_client import get_available_models, get_ollama_config
    
    if show_config:
        # Show current configuration
        config = get_ollama_config()
        
        config_table = Table(title="Current Model Configuration")
        config_table.add_column("Setting", style="cyan")
        config_table.add_column("Value", style="green")
        
        config_table.add_row("Default Model", config.get("default_model", "N/A"))
        config_table.add_row("Base URL", config.get("base_url", "N/A"))
        config_table.add_row("Temperature", str(config.get("temperature", "N/A")))
        config_table.add_row("Top P", str(config.get("top_p", "N/A")))
        config_table.add_row("Top K", str(config.get("top_k", "N/A")))
        
        console.print(config_table)
        console.print()
    
    # Get available models from Ollama
    console.print("[cyan]Checking available models...[/cyan]")
    available_models = get_available_models()
    config = get_ollama_config()
    
    if available_models:
        table = Table(title="Available Models")
        table.add_column("Model Name", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Default", style="yellow")
        
        default_model = config.get("default_model", "")
        
        for model in available_models:
            status = "✅ Available"
            is_default = "✅ Yes" if model == default_model else ""
            table.add_row(model, status, is_default)
        
        console.print(table)
        
        # Show configured models that aren't available
        configured_models = config.get("available_models", [])
        missing_models = [m for m in configured_models if m not in available_models]
        
        if missing_models:
            console.print("\n[yellow]⚠️  Configured models not available in Ollama:[/yellow]")
            for model in missing_models:
                console.print(f"  • {model} - Run: [cyan]ollama pull {model}[/cyan]")
    else:
        console.print("[yellow]⚠️  No models available in Ollama[/yellow]")
        console.print("Install models with: [cyan]ollama pull <model-name>[/cyan]")
        console.print("\nRecommended models:")
        console.print("  • [cyan]ollama pull llama3.2[/cyan] - Default model")
        console.print("  • [cyan]ollama pull mistral[/cyan] - Mistral model")
        console.print("  • [cyan]ollama pull codellama[/cyan] - Code generation")


@model.command()
@click.argument("model_name")
@click.option("--set-default", is_flag=True, help="Set as default model")
@track_command
@safe_operation(category=ErrorCategory.CONFIG, operation="model_set")
def set_default(model_name, set_default):
    """Set the default model for CodeInsight."""
    from core.llm_client import get_available_models, get_ollama_config
    
    # Check if model is available
    available_models = get_available_models()
    
    if model_name not in available_models:
        console.print(f"[red]❌ Model '{model_name}' is not available in Ollama[/red]")
        console.print(f"Install it with: [cyan]ollama pull {model_name}[/cyan]")
        
        if available_models:
            console.print("\nAvailable models:")
            for model in available_models:
                console.print(f"  • {model}")
        return
    
    # Update configuration
    try:
        config = config_manager.load_config("docs_sources")
        
        # Ensure settings and ollama sections exist
        if "settings" not in config:
            config["settings"] = {}
        if "ollama" not in config["settings"]:
            config["settings"]["ollama"] = {}
        
        # Update default model
        config["settings"]["ollama"]["default_model"] = model_name
        
        # Add to available models list if not present
        available_list = config["settings"]["ollama"].get("available_models", [])
        if model_name not in available_list:
            available_list.append(model_name)
            config["settings"]["ollama"]["available_models"] = available_list
        
        # Save configuration
        config_manager.save_config(config, "docs_sources")
        
        console.print(f"[green]✅ Default model set to '{model_name}'[/green]")
        
        # Test the model
        from core.llm_client import call_ollama_generate
        console.print(f"[cyan]Testing model '{model_name}'...[/cyan]")
        
        test_response = call_ollama_generate("Hello! Respond with just 'Model test successful.'", model=model_name)
        if test_response:
            console.print(f"[green]✅ Model test successful[/green]")
            console.print(f"Response: {test_response[:100]}...")
        else:
            console.print(f"[yellow]⚠️  Model responded but output was empty[/yellow]")
        
    except Exception as e:
        console.print(f"[red]❌ Failed to set default model: {e}[/red]")


@model.command()
@click.argument("prompt")
@click.option("--model", help="Specific model to use (overrides default)")
@click.option("--temperature", type=float, help="Temperature for generation (0.0-1.0)")
@track_command
@safe_operation(category=ErrorCategory.API, operation="model_test")
def test(prompt, model, temperature):
    """Test a model with a custom prompt."""
    from core.llm_client import call_ollama_generate, get_ollama_config, get_available_models
    
    # Validate model if specified
    if model:
        available_models = get_available_models()
        if model not in available_models:
            console.print(f"[red]❌ Model '{model}' is not available[/red]")
            return
    
    config = get_ollama_config()
    model_name = model or config.get("default_model", "mistral:7b-instruct")
    
    console.print(f"[cyan]Testing model '{model_name}' with prompt...[/cyan]")
    console.print(f"[dim]Prompt: {prompt}[/dim]\n")
    
    try:
        # Override temperature if provided
        if temperature is not None:
            # We need to temporarily modify config for this test
            original_temp = config.get("temperature", 0.1)
            config["temperature"] = temperature
        
        with console.status(f"[bold green]Generating response with {model_name}..."):
            response = call_ollama_generate(prompt, model=model_name)
        
        if response:
            response_panel = Panel(
                response,
                title=f"Response from {model_name}",
                border_style="green",
                padding=(1, 2)
            )
            console.print(response_panel)
            
            # Show model info
            console.print(f"\n[dim]Model: {model_name}[/dim]")
            if temperature is not None:
                console.print(f"[dim]Temperature: {temperature}[/dim]")
        else:
            console.print("[yellow]⚠️  Model responded but output was empty[/yellow]")
    
    except Exception as e:
        console.print(f"[red]❌ Model test failed: {e}[/red]")


@model.command()
@click.option("--show-details", is_flag=True, help="Show detailed connection information")
@track_command  
@safe_operation(category=ErrorCategory.API, operation="model_status")
def status(show_details):
    """Check Ollama server status and model availability."""
    from core.llm_client import check_ollama_server, get_available_models, get_ollama_config
    
    config = get_ollama_config()
    base_url = config.get("base_url", "http://localhost:11434")
    
    console.print(f"[cyan]Checking Ollama server at {base_url}...[/cyan]")
    
    # Check server status
    if check_ollama_server():
        console.print("[green]✅ Ollama server is running[/green]")
        
        # Get available models
        models = get_available_models()
        default_model = config.get("default_model", "mistral:7b-instruct")
        
        status_table = Table(title="Ollama Status")
        status_table.add_column("Component", style="cyan")
        status_table.add_column("Status", style="green")
        status_table.add_column("Details", style="yellow")
        
        status_table.add_row("Server", "✅ Running", base_url)
        status_table.add_row("Models Available", f"✅ {len(models)}", f"{len(models)} models installed")
        
        if default_model in models:
            status_table.add_row("Default Model", "✅ Available", default_model)
        else:
            status_table.add_row("Default Model", "❌ Missing", f"{default_model} not installed")
        
        console.print(status_table)
        
        if show_details and models:
            console.print("\n[cyan]Available Models:[/cyan]")
            for i, model in enumerate(models[:10], 1):  # Show first 10
                marker = "🔹" if model == default_model else "  "
                console.print(f"{marker} {model}")
            
            if len(models) > 10:
                console.print(f"... and {len(models) - 10} more models")
                
        elif not models:
            console.print("\n[yellow]⚠️  No models installed[/yellow]")
            console.print("Install models with:")
            console.print("  • [cyan]ollama pull llama3.2[/cyan]")
            console.print("  • [cyan]ollama pull mistral[/cyan]")
    else:
        console.print("[red]❌ Ollama server is not running or not accessible[/red]")
        console.print("\nTroubleshooting:")
        console.print("  1. Install Ollama: https://ollama.ai")
        console.print("  2. Start Ollama: [cyan]ollama serve[/cyan]")
        console.print(f"  3. Check if server is running at: {base_url}")
        
        if show_details:
            console.print("\n[yellow]Expected Ollama API endpoints:[/yellow]")
            console.print(f"  • Version: {base_url}/api/version")
            console.print(f"  • Models: {base_url}/api/tags")
            console.print(f"  • Generate: {base_url}/api/generate")


@cli.command()
@click.option("--framework", default="react", help="Framework to search (default: react)")
@click.option("--model", default=None, help="Specific Ollama model to use")
@track_command
@safe_operation(category=ErrorCategory.USER_INPUT, operation="cli_command")
def chat(framework, model):
    """Start an interactive chat session like Gemini CLI."""
    from rich.prompt import Prompt
    from core.llm_client import get_llm_client
    
    # Initialize
    llm_client = get_llm_client()
    if model:
        llm_client.ollama_config["default_model"] = model
    
    # Show banner
    ui.show_gemini_style_banner()
    console.print(f"\n[cyan]Framework:[/cyan] {framework}")
    console.print(f"[cyan]Model:[/cyan] {llm_client.ollama_config['default_model']}")
    console.print("[dim]Type 'exit', 'quit', or press Ctrl+C to end the session[/dim]")
    console.print("=" * 60)
    
    try:
        while True:
            # Get user input with Gemini-style prompt
            prompt_text = ui.get_gemini_style_prompt()
            try:
                user_input = Prompt.ask(prompt_text)
            except (KeyboardInterrupt, EOFError):
                console.print("\n[yellow]Chat session ended.[/yellow]")
                break
            
            # Check for exit commands
            if user_input.lower().strip() in ['exit', 'quit', 'bye', 'goodbye']:
                console.print("[green]Goodbye! 👋[/green]")
                break
            
            # Validate input
            user_input = sanitize_user_input(user_input, max_length=500)
            if not user_input or len(user_input.strip()) < 2:
                console.print("[yellow]Please ask a question (at least 2 characters)[/yellow]")
                continue
            
            # Show user input bubble
            ui.render_user_message(user_input)
            
            try:
                # Show thinking indicator
                with console.status("[cyan]Thinking...[/cyan]", spinner="dots"):
                    # Retrieve context
                    context_chunks = retrieve(user_input, framework, 5)
                    
                    # Generate response
                    answer = answer_query(user_input, context_chunks)
                
                # Show assistant response bubble
                ui.render_assistant_message(answer)
                
                # Add some spacing for readability
                console.print()
                
            except Exception as e:
                console.print(f"[red]Error: {str(e)}[/red]")
                console.print("[yellow]Please try rephrasing your question.[/yellow]")
                
    except KeyboardInterrupt:
        console.print("\n[yellow]Chat session ended.[/yellow]")


if __name__ == "__main__":
    cli()
