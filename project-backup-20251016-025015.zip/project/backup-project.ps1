<#
.SYNOPSIS
    Comprehensive Project Backup Script for Windows 11 Reinstall
    
.DESCRIPTION
    Creates a complete backup of the project including:
    - Project files (excluding common build artifacts)
    - Dependency manifests (requirements.txt, package.json, etc.)
    - Global tools inventory
    - Restore instructions
    
.NOTES
    Author: CodeInsight Backup Utility
    Date: 2025-10-16
    Usage: .\backup-project.ps1
#>

# Ensure script runs with proper error handling
$ErrorActionPreference = "Stop"

# Color output functions
function Write-Success { param($Message) Write-Host "✅ $Message" -ForegroundColor Green }
function Write-Info { param($Message) Write-Host "ℹ️  $Message" -ForegroundColor Cyan }
function Write-Warning { param($Message) Write-Host "⚠️  $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "❌ $Message" -ForegroundColor Red }

# Banner
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "  CodeInsight Project Backup Utility" -ForegroundColor Magenta
Write-Host "========================================`n" -ForegroundColor Magenta

# Get project information
$ProjectRoot = $PSScriptRoot
$ProjectName = Split-Path $ProjectRoot -Leaf
$ParentDir = Split-Path $ProjectRoot -Parent
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupName = "project-backup-$Timestamp"
$BackupZip = Join-Path $ParentDir "$BackupName.zip"
$TempBackupDir = Join-Path $env:TEMP $BackupName

Write-Info "Project: $ProjectName"
Write-Info "Location: $ProjectRoot"
Write-Info "Backup will be created at: $BackupZip`n"

# Create temporary backup directory
try {
    if (Test-Path $TempBackupDir) {
        Remove-Item $TempBackupDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $TempBackupDir -Force | Out-Null
    Write-Success "Created temporary backup directory"
} catch {
    Write-Error "Failed to create temp directory: $_"
    exit 1
}

# ==============================================
# STEP 1: Detect Project Type & Export Dependencies
# ==============================================
Write-Info "`n[STEP 1] Detecting project type and exporting dependencies..."

$ProjectTypes = @()
$DependencyFiles = @()

# Python Project Detection
if ((Test-Path "$ProjectRoot\requirements.txt") -or 
    (Test-Path "$ProjectRoot\setup.py") -or 
    (Test-Path "$ProjectRoot\pyproject.toml")) {
    
    $ProjectTypes += "Python"
    Write-Info "Detected: Python project"
    
    # Generate requirements.txt if pip is available
    try {
        $PipPath = Get-Command pip -ErrorAction SilentlyContinue
        if ($PipPath) {
            Write-Info "Generating requirements.txt from pip freeze..."
            pip freeze > "$TempBackupDir\requirements.txt"
            $DependencyFiles += "requirements.txt"
            Write-Success "Exported Python dependencies"
        }
    } catch {
        Write-Warning "Could not generate requirements.txt: $_"
    }
    
    # Copy existing dependency files
    @("requirements.txt", "dev-requirements.txt", "setup.py", "setup.cfg", 
      "pyproject.toml", "Pipfile", "Pipfile.lock", "poetry.lock") | ForEach-Object {
        if (Test-Path "$ProjectRoot\$_") {
            Copy-Item "$ProjectRoot\$_" $TempBackupDir
            $DependencyFiles += $_
        }
    }
}

# Node.js Project Detection
if (Test-Path "$ProjectRoot\package.json") {
    $ProjectTypes += "Node.js"
    Write-Info "Detected: Node.js project"
    
    @("package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml", 
      "bun.lockb", ".npmrc", ".nvmrc") | ForEach-Object {
        if (Test-Path "$ProjectRoot\$_") {
            Copy-Item "$ProjectRoot\$_" $TempBackupDir
            $DependencyFiles += $_
        }
    }
    Write-Success "Exported Node.js dependencies"
}

# Rust Project Detection
if (Test-Path "$ProjectRoot\Cargo.toml") {
    $ProjectTypes += "Rust"
    Write-Info "Detected: Rust project"
    
    @("Cargo.toml", "Cargo.lock", "rust-toolchain.toml") | ForEach-Object {
        if (Test-Path "$ProjectRoot\$_") {
            Copy-Item "$ProjectRoot\$_" $TempBackupDir
            $DependencyFiles += $_
        }
    }
    Write-Success "Exported Rust dependencies"
}

# Go Project Detection
if (Test-Path "$ProjectRoot\go.mod") {
    $ProjectTypes += "Go"
    Write-Info "Detected: Go project"
    
    # Run go mod tidy if go is available
    try {
        $GoPath = Get-Command go -ErrorAction SilentlyContinue
        if ($GoPath) {
            Push-Location $ProjectRoot
            go mod tidy
            Pop-Location
            Write-Info "Ran 'go mod tidy'"
        }
    } catch {
        Write-Warning "Could not run go mod tidy: $_"
    }
    
    @("go.mod", "go.sum") | ForEach-Object {
        if (Test-Path "$ProjectRoot\$_") {
            Copy-Item "$ProjectRoot\$_" $TempBackupDir
            $DependencyFiles += $_
        }
    }
    Write-Success "Exported Go dependencies"
}

# Docker Detection
if ((Test-Path "$ProjectRoot\Dockerfile") -or (Test-Path "$ProjectRoot\docker-compose.yml")) {
    $ProjectTypes += "Docker"
    Write-Info "Detected: Docker configuration"
    
    @("Dockerfile", "docker-compose.yml", "docker-compose.yaml", ".dockerignore") | ForEach-Object {
        if (Test-Path "$ProjectRoot\$_") {
            Copy-Item "$ProjectRoot\$_" $TempBackupDir
            $DependencyFiles += $_
        }
    }
}

if ($ProjectTypes.Count -eq 0) {
    $ProjectTypes += "Generic"
    Write-Warning "No specific project type detected"
}

# ==============================================
# STEP 2: Inventory Global Developer Tools
# ==============================================
Write-Info "`n[STEP 2] Inventorying globally installed developer tools..."

$GlobalTools = @()
$ToolsToCheck = @(
    @{Name="Python"; Command="python"; Args="--version"},
    @{Name="Pip"; Command="pip"; Args="--version"},
    @{Name="Node.js"; Command="node"; Args="--version"},
    @{Name="NPM"; Command="npm"; Args="--version"},
    @{Name="Bun"; Command="bun"; Args="--version"},
    @{Name="Yarn"; Command="yarn"; Args="--version"},
    @{Name="PNPM"; Command="pnpm"; Args="--version"},
    @{Name="Git"; Command="git"; Args="--version"},
    @{Name="Rust/Cargo"; Command="cargo"; Args="--version"},
    @{Name="Rustup"; Command="rustup"; Args="--version"},
    @{Name="Go"; Command="go"; Args="version"},
    @{Name="Docker"; Command="docker"; Args="--version"},
    @{Name="Docker Compose"; Command="docker-compose"; Args="--version"},
    @{Name="Ollama"; Command="ollama"; Args="--version"},
    @{Name="PowerShell"; Command="pwsh"; Args="--version"},
    @{Name="Nushell"; Command="nu"; Args="--version"},
    @{Name="Starship"; Command="starship"; Args="--version"},
    @{Name="VS Code"; Command="code"; Args="--version"},
    @{Name="Make"; Command="make"; Args="--version"},
    @{Name="CMake"; Command="cmake"; Args="--version"},
    @{Name="GCC"; Command="gcc"; Args="--version"},
    @{Name="Clang"; Command="clang"; Args="--version"}
)

foreach ($Tool in $ToolsToCheck) {
    try {
        $CmdPath = Get-Command $Tool.Command -ErrorAction SilentlyContinue
        if ($CmdPath) {
            $Version = & $Tool.Command $Tool.Args.Split() 2>&1 | Select-Object -First 1
            $GlobalTools += "$($Tool.Name): $Version (Path: $($CmdPath.Source))"
            Write-Host "  ✓ " -ForegroundColor Green -NoNewline
            Write-Host "$($Tool.Name)" -ForegroundColor White
        }
    } catch {
        # Tool not found, skip silently
    }
}

# Save global tools inventory
$GlobalToolsPath = Join-Path $TempBackupDir "global-tools.txt"
$GlobalTools | Out-File -FilePath $GlobalToolsPath -Encoding UTF8
Write-Success "Saved global tools inventory ($($GlobalTools.Count) tools detected)"

# ==============================================
# STEP 3: Create Restore Instructions
# ==============================================
Write-Info "`n[STEP 3] Creating restore instructions..."

$RestoreInstructions = @"
╔══════════════════════════════════════════════════════════════════╗
║           CODEINSIGHT PROJECT RESTORE INSTRUCTIONS               ║
╔══════════════════════════════════════════════════════════════════╗

📦 BACKUP INFORMATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Project Name:    $ProjectName
  Backup Date:     $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
  Project Type(s): $($ProjectTypes -join ", ")
  Original Path:   $ProjectRoot


🔧 STEP 1: INSTALL GLOBAL DEVELOPER TOOLS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Review the 'global-tools.txt' file and reinstall the tools you need.

Essential tools for this project:
  • Python 3.11+        : https://www.python.org/downloads/
  • Git                 : https://git-scm.com/downloads
  • Ollama              : https://ollama.ai/download
  • VS Code (optional)  : https://code.visualstudio.com/

Install Python packages globally:
  pip install --upgrade pip setuptools wheel


🗂️  STEP 2: EXTRACT PROJECT FILES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Extract this ZIP file to your desired location:
   Right-click → Extract All... → Choose destination

2. Recommended location:
   D:\codeinsight-project  (or your preferred drive)


📦 STEP 3: RESTORE PROJECT DEPENDENCIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"@

if ($ProjectTypes -contains "Python") {
    $RestoreInstructions += @"

For Python project:
  cd <project-directory>
  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  pip install -r dev-requirements.txt  # if exists

"@
}

if ($ProjectTypes -contains "Node.js") {
    $RestoreInstructions += @"

For Node.js project:
  cd <project-directory>
  npm install
  # or: yarn install
  # or: pnpm install
  # or: bun install

"@
}

if ($ProjectTypes -contains "Rust") {
    $RestoreInstructions += @"

For Rust project:
  cd <project-directory>
  cargo build

"@
}

if ($ProjectTypes -contains "Go") {
    $RestoreInstructions += @"

For Go project:
  cd <project-directory>
  go mod download
  go build

"@
}

$RestoreInstructions += @"

🚀 STEP 4: START THE PROJECT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
For CodeInsight specifically:

1. Start Ollama server:
   ollama serve

2. Pull the default model:
   ollama pull mistral:7b-instruct

3. Test the CLI:
   python cli.py --help
   python cli.py model status
   python cli.py query "What is React?" --framework react

4. Start interactive chat:
   python cli.py chat


📝 STEP 5: VERIFY INSTALLATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Run these commands to verify everything works:
  python cli.py model status --show-details
  python cli.py update react --dry-run
  python cli.py query "test query" --framework react


🔍 ADDITIONAL FILES IN THIS BACKUP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  • global-tools.txt         : List of globally installed dev tools
  • dependency-files/        : All dependency manifests
  • README-RESTORE.txt       : This file
  • project/                 : Complete project source code


⚠️  IMPORTANT NOTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ⚡ Virtual environments (venv/) are NOT backed up - recreate them
  ⚡ Node modules (node_modules/) are NOT backed up - run npm install
  ⚡ Build artifacts (__pycache__/, dist/) are NOT backed up
  ⚡ Large binary files may have been excluded
  ⚡ Git history (.git/) is backed up if present


📧 NEED HELP?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Check the project README.md for detailed documentation
  GitHub: https://github.com/pavanlost56/CodeInsight-CLI


═══════════════════════════════════════════════════════════════════
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
═══════════════════════════════════════════════════════════════════
"@

$ReadmePath = Join-Path $TempBackupDir "README-RESTORE.txt"
$RestoreInstructions | Out-File -FilePath $ReadmePath -Encoding UTF8
Write-Success "Created restore instructions"

# ==============================================
# STEP 4: Create Project Metadata
# ==============================================
$Metadata = @{
    ProjectName = $ProjectName
    BackupDate = Get-Date -Format "o"
    ProjectTypes = $ProjectTypes
    OriginalPath = $ProjectRoot
    DependencyFiles = $DependencyFiles
    GlobalToolsCount = $GlobalTools.Count
    BackupVersion = "1.0"
} | ConvertTo-Json -Depth 3

$MetadataPath = Join-Path $TempBackupDir "backup-metadata.json"
$Metadata | Out-File -FilePath $MetadataPath -Encoding UTF8
Write-Success "Created backup metadata"

# ==============================================
# STEP 5: Copy Project Files (with exclusions)
# ==============================================
Write-Info "`n[STEP 4] Copying project files..."

# Create project subdirectory in backup
$ProjectBackupDir = Join-Path $TempBackupDir "project"
New-Item -ItemType Directory -Path $ProjectBackupDir -Force | Out-Null

# Define exclusion patterns
$ExcludePatterns = @(
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    "venv",
    ".venv",
    "env",
    ".env",
    "*.pyc",
    "*.pyo",
    "*.pyd",
    ".git",
    ".vs",
    ".vscode",
    "dist",
    "build",
    "*.egg-info",
    "target",
    ".idea",
    "*.log",
    "*.tmp",
    ".DS_Store",
    "Thumbs.db"
)

Write-Info "Excluding: $($ExcludePatterns -join ', ')"

# Copy files with exclusions using robocopy for efficiency
$ExcludeDirs = $ExcludePatterns | Where-Object { $_ -notmatch '\*' }
$ExcludeFiles = $ExcludePatterns | Where-Object { $_ -match '\*' } | ForEach-Object { $_.Replace('*', '') }

$RobocopyArgs = @($ProjectRoot, $ProjectBackupDir, "/E", "/NP", "/NDL", "/NFL", "/NJH", "/NJS")

if ($ExcludeDirs) {
    $RobocopyArgs += "/XD"
    $RobocopyArgs += $ExcludeDirs
}

if ($ExcludeFiles) {
    $RobocopyArgs += "/XF"
    $RobocopyArgs += $ExcludeFiles
}

try {
    $RobocopyResult = & robocopy @RobocopyArgs 2>&1
    # Robocopy exit codes: 0-7 are success, 8+ are errors
    if ($LASTEXITCODE -ge 8) {
        Write-Warning "Robocopy reported issues (exit code: $LASTEXITCODE)"
    }
    Write-Success "Copied project files (excluding build artifacts)"
} catch {
    Write-Error "Failed to copy project files: $_"
    exit 1
}

# ==============================================
# STEP 6: Create ZIP Archive
# ==============================================
Write-Info "`n[STEP 5] Creating ZIP archive..."

try {
    # Remove existing backup if it exists
    if (Test-Path $BackupZip) {
        Remove-Item $BackupZip -Force
        Write-Info "Removed existing backup"
    }
    
    # Compress the backup directory
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($TempBackupDir, $BackupZip, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    
    $BackupSize = (Get-Item $BackupZip).Length / 1MB
    Write-Success "Created backup archive: $BackupZip"
    Write-Success "Backup size: $([math]::Round($BackupSize, 2)) MB"
    
} catch {
    Write-Error "Failed to create ZIP archive: $_"
    exit 1
}

# ==============================================
# STEP 7: Cleanup and Summary
# ==============================================
Write-Info "`n[STEP 6] Cleaning up..."

try {
    Remove-Item $TempBackupDir -Recurse -Force
    Write-Success "Removed temporary files"
} catch {
    Write-Warning "Could not remove temp directory: $_"
}

# Final Summary
Write-Host "`n╔══════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║           BACKUP COMPLETED SUCCESSFULLY              ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════════╝`n" -ForegroundColor Green

Write-Host "📦 Backup Information:" -ForegroundColor Cyan
Write-Host "  • Project Name:      $ProjectName"
Write-Host "  • Project Type(s):   $($ProjectTypes -join ', ')"
Write-Host "  • Backup Location:   $BackupZip" -ForegroundColor Yellow
Write-Host "  • Backup Size:       $([math]::Round($BackupSize, 2)) MB"
Write-Host "  • Dependency Files:  $($DependencyFiles.Count) files"
Write-Host "  • Global Tools:      $($GlobalTools.Count) detected"
Write-Host ""

Write-Host "✨ Next Steps:" -ForegroundColor Cyan
Write-Host "  1. Copy the backup ZIP to external storage or cloud"
Write-Host "  2. After Windows 11 reinstall, extract the ZIP"
Write-Host "  3. Follow instructions in README-RESTORE.txt"
Write-Host "  4. Reinstall tools listed in global-tools.txt"
Write-Host ""

Write-Host "🔒 Your project is safely backed up!" -ForegroundColor Green
Write-Host "   Path: " -NoNewline
Write-Host "$BackupZip`n" -ForegroundColor Yellow

# Open backup location in Explorer
try {
    explorer.exe "/select,$BackupZip"
} catch {
    Write-Info "Could not open Explorer automatically"
}
