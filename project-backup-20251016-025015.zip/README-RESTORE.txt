╔══════════════════════════════════════════════════════════════════╗
║           CODEINSIGHT PROJECT RESTORE INSTRUCTIONS               ║
╔══════════════════════════════════════════════════════════════════╗

📦 BACKUP INFORMATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Project Name:    codeinsight-project
  Backup Date:     2025-10-16 02:50:25
  Project Type(s): Python, Docker
  Original Path:   D:\codeinsight-project


🔧 STEP 1: INSTALL GLOBAL DEVELOPER TOOLS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Review the 'global-tools.txt' file and reinstall the tools you need.

Essential tools for this project:
  • Python 3.11+        : https://www.python.org/downloads/
  • Git                 : https://git-scm.com/downloads
  • Ollama              : https://ollama.ai/download
  • VS Code (optional)  : https://code.visualstudio.com/

Install Python packages globally:
  pip install --upgrade pip setuptools wheel


🗂️  STEP 2: EXTRACT PROJECT FILES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Extract this ZIP file to your desired location:
   Right-click → Extract All... → Choose destination

2. Recommended location:
   D:\codeinsight-project  (or your preferred drive)


📦 STEP 3: RESTORE PROJECT DEPENDENCIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
For Python project:
  cd <project-directory>
  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  pip install -r dev-requirements.txt  # if exists

🚀 STEP 4: START THE PROJECT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
For CodeInsight specifically:

1. Start Ollama server:
   ollama serve

2. Pull the default model:
   ollama pull mistral:7b-instruct

3. Test the CLI:
   python cli.py --help
   python cli.py model status
   python cli.py query "What is React?" --framework react

4. Start interactive chat:
   python cli.py chat


📝 STEP 5: VERIFY INSTALLATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Run these commands to verify everything works:
  python cli.py model status --show-details
  python cli.py update react --dry-run
  python cli.py query "test query" --framework react


🔍 ADDITIONAL FILES IN THIS BACKUP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  • global-tools.txt         : List of globally installed dev tools
  • dependency-files/        : All dependency manifests
  • README-RESTORE.txt       : This file
  • project/                 : Complete project source code


⚠️  IMPORTANT NOTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ⚡ Virtual environments (venv/) are NOT backed up - recreate them
  ⚡ Node modules (node_modules/) are NOT backed up - run npm install
  ⚡ Build artifacts (__pycache__/, dist/) are NOT backed up
  ⚡ Large binary files may have been excluded
  ⚡ Git history (.git/) is backed up if present


📧 NEED HELP?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Check the project README.md for detailed documentation
  GitHub: https://github.com/pavanlost56/CodeInsight-CLI


═══════════════════════════════════════════════════════════════════
Generated: 2025-10-16 02:50:25
═══════════════════════════════════════════════════════════════════
